# Módulo de método

Aplicar únicamente dentro de los límites del controlador SKILL.md del owner.

# Analizar progreso AMI

## Principios obligatorios

- Separar siempre `dato`, `autopercepción`, `interpretación` y `recomendación`.
- Basar toda confrontación en evidencia visible del archivo. No inventar datos, intenciones ni causas.
- No diagnosticar condiciones psicológicas ni inferir DISC u otra personalidad no evaluada.
- Comparar al agente primero contra su propia meta y conducta declarada. Usar medianas del equipo solo como contexto secundario.
- Proteger la confidencialidad: no incluir respuestas identificables de otros agentes en el reporte individual.
- Escribir el reporte del agente como Michael hablándole directamente, no como un analista externo.

## Flujo

### 1. Inspeccionar el archivo

1. Confirmar formato, hojas, filas, encabezados, fechas y posibles duplicados.
2. Usar la skill de Spreadsheets para leer y verificar el workbook. No modificar el archivo fuente.
3. Ejecutar `scripts/profile_responses.py` cuando el archivo sea XLSX o CSV para generar una extracción normalizada y auditable.
4. Leer `references/form-schema.md` para mapear las preguntas vigentes. Tratar los encabezados reales del archivo como autoridad si el formulario cambió.
5. Detenerse y pedir aclaración cuando falten nombre/email, existan columnas ambiguas o no pueda determinarse qué respuesta pertenece a qué agente.

Comando recomendado:

```bash
python3 scripts/profile_responses.py RESPUESTAS.xlsx --out-dir PERFIL_SALIDA
```

### 2. Validar calidad de datos

- Reportar filas vacías, respuestas duplicadas, encabezados sin mapear y métricas no numéricas.
- Conservar todas las respuestas históricas. Para el reporte actual, usar la respuesta más reciente por email; si no hay email, usar nombre normalizado y declararlo.
- No convertir blancos en cero. Mantener `no disponible` separado de `0`.
- Revisar manualmente al menos dos agentes y reconciliar sus valores contra el Excel.

### 3. Calcular sin sobreinterpretar

Leer `references/scoring-rubric.md` y calcular solo cuando existan los campos requeridos:

- avance de la meta anual;
- proyección de cierres al ritmo actual;
- brecha restante y cierres mensuales necesarios;
- citas, acuerdos, pendientes y prospectos activos;
- conversaciones, seguimientos y días de prospección;
- crecimiento de base de datos;
- ratios de conversión con denominadores claramente etiquetados;
- diferencia entre actividad actual y compromiso de 90 días.

No aplicar benchmarks universales ni una puntuación psicológica. Si el usuario no proporciona estándares del equipo, usar estado `En ritmo`, `En riesgo`, `Fuera de ritmo` o `Datos insuficientes` según la matemática de su meta.

### 4. Analizar cada agente

Para cada agente, identificar:

1. resultado y progreso contra meta;
2. salud del pipeline;
3. volumen y consistencia de actividad;
4. sistema de CRM y seguimiento;
5. generación de leads, contenido y activos;
6. farming, sellers y FSBO cuando aplique;
7. propuesta de valor y claridad de nicho;
8. contradicciones demostrables entre meta, calendario y conducta;
9. cuello de botella principal;
10. ventaja o activo que debe protegerse;
11. plan de 90 días y mecanismo de responsabilidad.

No confundir falta de resultados con falta de esfuerzo sin revisar primero actividad, conversión, tiempo de maduración y calidad del pipeline.

### 5. Crear el reporte ejecutivo para Michael

Leer `references/report-templates.md`. Generar un documento profesional con:

- resumen ejecutivo;
- calidad y cobertura de datos;
- distribución de metas y progreso;
- producción, pipeline y conversiones;
- hábitos y sistemas comunes;
- marketing, base de datos, farming y sellers;
- principales patrones y riesgos;
- segmentación de agentes por intervención requerida;
- tabla individual con meta, ritmo, cuello de botella y próxima decisión;
- prioridades de coaching de 30, 60 y 90 días;
- preguntas recomendadas para las sesiones 1-1.

Usar nombres en este reporte porque es privado para Michael. Distinguir hallazgos del equipo de casos individuales.

### 6. Crear un reporte para cada agente

Leer `references/michael-voice.md` y `references/report-templates.md`.

- Dirigirse al agente por su nombre.
- Hablar en primera persona como Michael: `revisé`, `veo`, `quiero que trabajemos`.
- Abrir con la conclusión principal, no con agradecimientos genéricos.
- Mostrar números y evidencia antes de interpretar.
- Confrontar contradicciones con claridad y respeto.
- Limitar el plan a una meta principal, tres KPIs, una actividad no negociable y una conducta que debe detenerse o limitarse.
- Cerrar con un compromiso verificable para los próximos 7 días y la preparación de la sesión 1-1.
- Redactar en español por defecto. Usar inglés si las respuestas del agente están principalmente en inglés o el usuario lo solicita.

### 7. Producir archivos y verificar

- Usar la skill de Documents para crear DOCX profesionales y realizar renderizado visual completo.
- Entregar por defecto:
  - `Reporte-Ejecutivo-AMI-Team.docx`
  - un `Reporte-1-1-<Nombre>.docx` por agente.
- Crear PDF solo si el usuario lo solicita o si pide una versión lista para presentar/enviar.
- Si hay muchos agentes, empaquetar los reportes individuales en una carpeta o ZIP únicamente cuando el usuario lo pida.
- Verificar que cifras, nombres, pronombres, metas y acciones correspondan al agente correcto.
- Confirmar que ninguna respuesta confidencial se haya filtrado a otro reporte.

## Controles finales

- Reconciliar totales y medianas con el archivo fuente.
- Escanear errores de fórmulas, campos vacíos tratados como cero y divisiones por cero.
- Revisar cada reporte visualmente.
- Marcar inferencias como inferencias.
- No afirmar que se creó un reporte para un agente si sus datos son insuficientes; crear una nota de datos faltantes y preguntas para completar.
