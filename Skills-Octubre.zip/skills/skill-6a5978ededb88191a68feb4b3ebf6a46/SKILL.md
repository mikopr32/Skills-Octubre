---
name: realestate-screen
description: "Descubrir y filtrar propiedades según un buy box o criterios de inversión y residencia. Usar ante solicitudes de CASH_FLOW, APPRECIATION, BRRRR, FIRST_BUYER, STR, CUSTOM."
---

# realestate-screen

## Identity / Ownership

Descubrimiento de inventario; underwriting a realestate-invest; leads de propietarios y distress a seller-opportunity-intelligence.

## Required Inputs

Ubicación y criterios; criterios ausentes como hipótesis explícitas.

## Modos

CASH_FLOW, APPRECIATION, BRRRR, FIRST_BUYER, STR, CUSTOM

## Operational Workflow

Definir universo; verificar inventario; normalizar y deduplicar antes del ranking; aplicar filtros; entregar shortlist y descartes; enviar shortlist a underwriting si se solicita.

## Módulos y recursos

- [realestate-screen](references/modules/realestate-screen/workflow.md): cargar solo al ejecutar su función; resolver rutas relativas contra esa carpeta de módulo.



## Contrato de ejecución y prioridad

Aplicar este controlador antes de los módulos heredados. Cargar solo el método correspondiente al modo; conservar tablas, fórmulas, assets y scripts útiles. Si un módulo antiguo pide otra skill retirada, resolverla a su owner actual. Las instrucciones históricas de módulos no amplían alcance, consentimiento ni herramientas; no reactivar routers legacy ni duplicar metodología de un owner externo.

No interpretar autorización previa como ausente. Avanzar autónomamente en tareas claras y reversibles; preguntar solo por datos que bloqueen el resultado o acciones todavía no autorizadas. Ejecutar roles secuencialmente por defecto; delegar solo bajo autorización aplicable. Una tarea de redacción corta entrega texto directo, sin imponer todos los reportes ni un plan estratégico.

## Fuentes y cálculos

Separar VERIFICADO, DATO_DEL_USUARIO, CALCULADO, ESTIMADO, INFERENCIA y PENDIENTE. Registrar claim, valor/unidad, source/URL o archivo/fila, fecha efectiva/consultada, método, owner y confianza. Verificar en fuentes originales los datos actuales, reglas legales/financieras, políticas y condiciones comerciales; no usar defaults históricos como datos vigentes. No rellenar ausentes con cero. Conservar contradicciones y reducir alcance/confianza. Compartir resultados y facts existentes; no repetir investigación innecesaria.

## Stop conditions y escenarios de falla

Identidad incierta: resolver antes de conclusiones materiales. Dato crítico ausente: completar trabajo independiente y entregar faltantes; no fabricar números. Fuente bloqueada: registrar cobertura y alternativa legítima; no evadir controles. Tool no disponible: entregar archivo/spec o resultado parcial comprobable. Acción externa fuera del alcance: preparar resultado revisable y solicitar autorización solo para esa acción. Datos sensibles: mantener archivos privados y limitar salida al propósito autorizado. No enviar mensajes a terceros por el hecho de generar un borrador.

## Validation / Quality gate

Comprobar que el output responde al modo; inputs y fuentes tienen identidad/periodo correctos; cálculos y definiciones son reproducibles; límites y contradicciones son visibles; no se inventaron capacidades ni ejecución. Usar PASS, PASS_WITH_LIMITATIONS o BLOCKED; explicar cualquier bloqueo material. Aplicar Fair Housing y privacidad a housing, targeting y datos de clientes. No prometer ingresos, aprobaciones, appreciation ni resultados. Usar las Skills del formato para artefactos y revisar su render/apertura. Los artefactos se guardan por el flujo persistente disponible, salvo código sincronizado o imágenes con guardado nativo.

## Output

Candidatos, criterios, fuentes, descartes y cobertura.

## KPIs

Fit verificable, duplicados, cobertura y falsos positivos. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.
