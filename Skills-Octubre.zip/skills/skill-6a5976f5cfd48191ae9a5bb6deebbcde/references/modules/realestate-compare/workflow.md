# Comparación objetiva de propiedades

Aplicar dentro del contrato realestate-analyze. Comparar dos o más propiedades con criterios equivalentes, datos trazables y una conclusión condicionada al objetivo del usuario. No producir una nota compuesta ni elegir ganadores mediante escuelas, crimen o demografía.

## Inputs y comparabilidad

Identificar cada dirección o parcela, propósito, presupuesto, estrategia, horizonte, financiación y prioridades cuando existan. Para casos ficticios, señalar que los inputs son del ejercicio y respetar la prohibición de navegar.

Confirmar identidad, tipo, superficie, unidad, moneda y periodo antes de comparar. Si las propiedades difieren en tipo o mercado, describir qué métricas son comparables y cuáles requieren contexto. No normalizar silenciosamente una dirección ambigua.

## Evidencia y especialistas

Reunir un perfil por propiedad y un registro común de fuentes. Usar solo herramientas y Skills disponibles. Si un orquestador aporta módulos mediante su deployment-map.json, comprobar que existan y describir su ejecución como módulos, no como instalaciones independientes. Este paquete no incluye ese mapa; si falta un especialista, conservar la limitación.

Reutilizar las salidas de valoración, renta/inversión, comunidad, mercado y financiación cuando sean pertinentes. Definir productores y dependencias; no duplicar investigación. Ejecutar secuencialmente por defecto y delegar únicamente con autorización aplicable.

## Ocho grupos de comparación

1. Precio y valor: asking price, precio por sqft, comparables y market value, distinguiendo cada definición. Una mediana general o assessed value no acredita valor de mercado.
2. Características: beds/baths, sqft, lote, tipo, año, garaje y condición documentada. Más tamaño, dormitorios o antigüedad menor no implica superioridad sin una prioridad del usuario.
3. Renta y operación: renta respaldada, vacancy, gastos, NOI y cash flow con inputs equivalentes.
4. Comunidad y uso: HOA/CDD, restricciones públicas y privadas, accesibilidad, servicios, amenidades y desplazamientos indicados por el usuario.
5. Estrategia de inversión: hold, BRRRR, flip o STR solo cuando existan inputs y uso aplicable confirmados; incluir sensibilidad y salidas.
6. Costo de propiedad: taxes, seguro, cuotas, assessments, mantenimiento y financiación, sin doble conteo.
7. Mercado: inventario, DOM, absorción y tendencias del mismo periodo y geografía comparable. Una tendencia histórica no garantiza appreciation.
8. Riesgos: flood map, condición, inspecciones, zonificación, seguro, reglas y exposición operativa. No deducir costo de seguro o pérdida de valor solo por una zona flood.

## Reglas de cálculo

Mostrar fórmulas, inputs, denominadores, método y fecha. No imponer tasa, down payment, vacancy, refinance LTV, appreciation, rehab o closing costs como datos reales. Un escenario hipotético debe estar etiquetado y no convertirse en garantía.

No inventar renta mediante la regla del 1%. Purchase Price no determina deuda ni equity. No sustituir datos faltantes por cero ni confundir ausencia con NO. Si una propiedad tiene información crítica incompleta, mantener la diferencia pendiente y explicar su efecto.

## Matriz y recomendación

Usar una tabla:

| Criterio del usuario | Propiedad A | Propiedad B | Evidencia / confianza | Trade-off o pendiente |
|---|---|---|---|---|

Mostrar ventajas y riesgos sustentados por propiedad. No fijar pesos ni umbrales universales. Si el usuario pide una ponderación, usar sus preferencias explícitas y criterios objetivos, conservar límites y no presentar el resultado como valoración o predicción profesional.

No puntuar ni recomendar mediante school ratings, criminalidad, ingresos de residentes, composición demográfica o clases protegidas. No asociar propiedades con perfiles familiares o edades. La asignación escolar, si se solicita, se verifica por dirección y se mantiene separada del valor y la recomendación.

Concluir qué opción responde mejor a las prioridades declaradas solo cuando la evidencia sea comparable y suficiente. Si existen trade-offs o incógnitas materiales, entregar una conclusión condicionada o mantener la selección pendiente. No declarar un ganador global por una mezcla arbitraria de métricas.

## Salida y verificación

Adaptar extensión al pedido; crear archivo solo si el entregable lo requiere. Incluir identidad, objetivo, fecha, matriz, costos/cálculos pertinentes, riesgos, fuentes y próximo paso.

Clasificar VERIFICADO, DATO_DEL_USUARIO, CALCULADO, ESTIMADO, INFERENCIA y PENDIENTE. Conservar contradicciones y no promediar cifras incompatibles. No prometer returns, valor, appreciation, préstamo ni fechas.

No enviar, contactar, agendar, ofertar, publicar, gastar ni modificar cuentas sin autorización aplicable. Respetar permisos y controles de la plataforma. Informar PASS, PASS_WITH_LIMITATIONS o BLOCKED según el trabajo realmente realizado.
