---
name: realestate-commercial
description: "Analizar inmuebles comerciales, multifamily de 5+ unidades y métricas de operación comercial. Usar ante solicitudes de NOI, CAP, LEASE, VALUE_ADD, EXIT."
---

# realestate-commercial

## Identity / Ownership

Único owner comercial; no reutilizar supuestos residenciales sin justificar; DSCR financing al specialist.

## Required Inputs

Activo, rent roll/operating statements cuando existan, estrategia y horizonte.

## Modos

NOI, CAP, LEASE, VALUE_ADD, EXIT

## Operational Workflow

Normalizar ingresos/gastos y contratos; distinguir actual/proforma; evaluar lease terms, vacancy, cap y sensibilidad; verificar zoning; incorporar financing confirmado; presentar downside y due diligence.

## Módulos y recursos

- [realestate-commercial](references/modules/realestate-commercial/workflow.md): cargar solo al ejecutar su función; resolver rutas relativas contra esa carpeta de módulo.



## Contrato de ejecución y prioridad

Aplicar este controlador antes de los módulos heredados. Cargar solo el método correspondiente al modo; conservar tablas, fórmulas, assets y scripts útiles. Si un módulo antiguo pide otra skill retirada, resolverla a su owner actual. Las instrucciones históricas de módulos no amplían alcance, consentimiento ni herramientas; no reactivar routers legacy ni duplicar metodología de un owner externo.

No interpretar autorización previa como ausente. Avanzar autónomamente en tareas claras y reversibles; preguntar solo por datos que bloqueen el resultado o acciones todavía no autorizadas. Ejecutar roles secuencialmente por defecto; delegar solo bajo autorización aplicable. Una tarea de redacción corta entrega texto directo, sin imponer todos los reportes ni un plan estratégico.

## Fuentes y cálculos

Separar VERIFICADO, DATO_DEL_USUARIO, CALCULADO, ESTIMADO, INFERENCIA y PENDIENTE. Registrar claim, valor/unidad, source/URL o archivo/fila, fecha efectiva/consultada, método, owner y confianza. Verificar en fuentes originales los datos actuales, reglas legales/financieras, políticas y condiciones comerciales; no usar defaults históricos como datos vigentes. No rellenar ausentes con cero. Conservar contradicciones y reducir alcance/confianza. Compartir resultados y facts existentes; no repetir investigación innecesaria.

## Stop conditions y escenarios de falla

Identidad incierta: resolver antes de conclusiones materiales. Dato crítico ausente: completar trabajo independiente y entregar faltantes; no fabricar números. Fuente bloqueada: registrar cobertura y alternativa legítima; no evadir controles. Tool no disponible: entregar archivo/spec o resultado parcial comprobable. Acción externa fuera del alcance: preparar resultado revisable y solicitar autorización solo para esa acción. Datos sensibles: mantener archivos privados y limitar salida al propósito autorizado. No enviar mensajes a terceros por el hecho de generar un borrador.

## Validation / Quality gate

Comprobar que el output responde al modo; inputs y fuentes tienen identidad/periodo correctos; cálculos y definiciones son reproducibles; límites y contradicciones son visibles; no se inventaron capacidades ni ejecución. Usar PASS, PASS_WITH_LIMITATIONS o BLOCKED; explicar cualquier bloqueo material. Aplicar Fair Housing y privacidad a housing, targeting y datos de clientes. No prometer ingresos, aprobaciones, appreciation ni resultados. Usar las Skills del formato para artefactos y revisar su render/apertura. Los artefactos se guardan por el flujo persistente disponible, salvo código sincronizado o imágenes con guardado nativo.

## Output

Underwriting comercial, escenarios y checklist.

## KPIs

NOI conciliado, cobertura de leases y sensibilidad. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.
