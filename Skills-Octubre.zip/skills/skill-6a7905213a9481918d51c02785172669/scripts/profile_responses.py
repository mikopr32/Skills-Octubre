#!/usr/bin/env python3
"""Normalize AMI Google Forms exports and produce auditable JSON profiles."""

from __future__ import annotations

import argparse
import csv
import json
import math
import re
import statistics
import unicodedata
from collections import Counter, defaultdict
from datetime import date, datetime
from pathlib import Path
from typing import Any


FIELD_PATTERNS = [
    ("timestamp", [r"timestamp", r"marca temporal"]),
    ("agent_name", [r"nombre completo", r"full name"]),
    ("email", [r"correo electronico", r"email address"]),
    ("annual_goal_transactions", [r"propusiste cerrar.*2026", r"closing goal.*2026"]),
    ("closed_2026_period", [r"transacciones.*cerrad.*2026", r"transactions.*closed.*2026"]),
    ("closed_2025", [r"transacciones.*cerrad.*2025", r"transactions.*closed.*2025"]),
    ("new_clients_90d", [r"clientes nuevos reales.*90 dias", r"actual new clients.*90 days"]),
    ("appointments_90d", [r"citas de comprador o vendedor.*90 dias", r"buyer or seller appointments.*90 days"]),
    ("agreements_90d", [r"acuerdos de representacion.*90 dias", r"representation agreements.*90 days"]),
    ("pending_transactions", [r"transacciones.*pendientes o bajo contrato", r"transactions.*pending or under contract"]),
    ("qualified_pipeline", [r"prospectos activos y calificados", r"active and qualified prospects"]),
    ("new_contacts_90d", [r"contactos nuevos.*base de datos.*90 dias", r"new contacts.*database.*90 days"]),
    ("weekly_conversations_current", [r"ultimas cuatro semanas.*conversaciones", r"last four weeks.*business conversations"]),
    ("weekly_followups_current", [r"ultimas cuatro semanas.*seguimientos", r"last four weeks.*follow-ups"]),
    ("prospecting_days_week", [r"cuantos dias por semana.*prospeccion", r"how many days per week.*prospecting"]),
    ("crm_update_frequency", [r"frecuencia actualizas el crm", r"frequently do you update your crm"]),
    ("database_size", [r"cuantos contactos tienes actualmente", r"how many contacts do you currently have"]),
    ("workday_description", [r"describe un dia tipico", r"describe a typical workday"]),
    ("call_time", [r"que hora del dia.*llamadas", r"what time of day.*calls"]),
    ("followup_process", [r"describe detalladamente.*proceso.*seguimiento", r"describe your current follow-up process"]),
    ("active_prospect_contact_frequency", [r"frecuencia te comunicas.*prospectos activos", r"frequently do you communicate.*active prospects"]),
    ("crm_campaigns", [r"campanas de nutricion.*alertas", r"nurturing campaigns.*property alerts"]),
    ("cta_types", [r"llamadas a la accion", r"calls to action"]),
    ("lead_magnets", [r"cuantos lead magnets", r"how many lead magnets"]),
    ("social_post_frequency", [r"frecuencia publicas.*redes", r"frequently do you post.*social"]),
    ("daily_lead_generation", [r"actividades de generacion de leads.*diariamente", r"lead-generation activities.*daily"]),
    ("top_lead_sources", [r"tres principales fuentes", r"three primary sources"]),
    ("newsletter", [r"newsletter.*base de datos", r"newsletter.*database"]),
    ("weekly_special", [r"especial de la semana", r"weekly special"]),
    ("farm_area", [r"cual es tu farm area", r"what is your primary farm area"]),
    ("farm_neighborhoods", [r"cuantos vecindarios.*farm area", r"how many neighborhoods.*farm area"]),
    ("farm_activities", [r"actividades realizas.*farm area", r"activities.*farm area"]),
    ("seller_strategies", [r"estrategias.*atraer y convertir propietarios", r"strategies.*attract and convert homeowners"]),
    ("fsbo_activity", [r"actividad especifica.*for sale by owner", r"specific activities.*for sale by owner"]),
    ("fsbo_process", [r"si prospectas fsbo", r"if you prospect fsbos"]),
    ("focus_score", [r"que tan enfocado estas", r"how focused are you"]),
    ("focus_explanation", [r"^explica tu respuesta"]),
    ("willingness_score", [r"que tan dispuesto estas", r"how willing are you"]),
    ("consistency_score", [r"soy consistente", r"i remain consistent"]),
    ("accountability_score", [r"asumo responsabilidad", r"i take responsibility"]),
    ("clarity_plan", [r"mi negocio funciona.*claridad", r"my business operates.*clarity"]),
    ("feelings_results", [r"como te sientes.*resultados", r"how do you feel.*results"]),
    ("missing_factors", [r"que consideras que te falto", r"what do you believe was missing"]),
    ("value_proposition", [r"propuesta de valor", r"value proposition"]),
    ("changes_90d", [r"que cambios.*proximos 90 dias", r"what changes.*next 90 days"]),
    ("personal_focus_90d", [r"area de tu desarrollo personal", r"area of your personal development"]),
    ("professional_focus_90d", [r"area de tu negocio o desarrollo profesional", r"area of your business or professional"]),
    ("goal_transactions_90d", [r"meta de transacciones.*proximos 90 dias", r"target number of transactions.*next 90 days"]),
    ("weekly_conversations_goal", [r"meta semanal de conversaciones", r"weekly target.*conversations"]),
    ("nonnegotiable_activity", [r"unica actividad no negociable", r"one activity no negociable", r"one non-negotiable activity"]),
    ("stop_delegate_limit", [r"dejar de hacer, delegar o limitar", r"stop doing, delegate, or limit"]),
    ("obstacle_response", [r"obstaculo mas probable", r"most likely obstacle"]),
    ("niche_90d", [r"nicho o segmento.*90 dias", r"niche or market segment.*90 days"]),
    ("niche_activities", [r"actividades especificas.*diaria y semanal", r"specific daily and weekly activities"]),
    ("missing_to_start", [r"comenzar este plan manana", r"begin this plan tomorrow"]),
]

NUMERIC_FIELDS = {
    "annual_goal_transactions", "closed_2026_period", "closed_2025",
    "new_clients_90d", "appointments_90d", "agreements_90d",
    "pending_transactions", "qualified_pipeline", "new_contacts_90d",
    "weekly_conversations_current", "weekly_followups_current",
    "prospecting_days_week", "database_size", "focus_score",
    "willingness_score", "consistency_score", "accountability_score",
    "feelings_results", "goal_transactions_90d", "weekly_conversations_goal",
}


def normalize(value: Any) -> str:
    text = "" if value is None else str(value)
    text = unicodedata.normalize("NFKD", text)
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    text = text.lower().replace("’", "'").replace("–", "-").replace("—", "-")
    return re.sub(r"\s+", " ", text).strip()


def canonical_header(header: str) -> str | None:
    text = normalize(header)
    for key, patterns in FIELD_PATTERNS:
        if any(re.search(pattern, text) for pattern in patterns):
            return key
    return None


def parse_number(value: Any) -> float | None:
    if value is None or value == "":
        return None
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return float(value) if math.isfinite(float(value)) else None
    text = normalize(value).replace(",", "")
    match = re.search(r"-?\d+(?:\.\d+)?", text)
    return float(match.group()) if match else None


def json_safe(value: Any) -> Any:
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if isinstance(value, float) and not math.isfinite(value):
        return None
    return value


def timestamp_key(value: Any, fallback: int) -> tuple[int, float, int]:
    """Return a sortable key while preserving source order for unknown formats."""
    if isinstance(value, datetime):
        return (1, value.timestamp(), fallback)
    if isinstance(value, date):
        return (1, datetime.combine(value, datetime.min.time()).timestamp(), fallback)
    text = str(value or "").strip()
    if text:
        candidates = [text, text.replace("Z", "+00:00")]
        for candidate in candidates:
            try:
                return (1, datetime.fromisoformat(candidate).timestamp(), fallback)
            except (ValueError, OverflowError):
                pass
        for fmt in ("%m/%d/%Y %H:%M:%S", "%m/%d/%Y %H:%M", "%d/%m/%Y %H:%M:%S", "%d/%m/%Y %H:%M"):
            try:
                return (1, datetime.strptime(text, fmt).timestamp(), fallback)
            except ValueError:
                pass
    return (0, 0.0, fallback)


def load_rows(path: Path, sheet_name: str | None) -> tuple[str, list[str], list[dict[str, Any]]]:
    if path.suffix.lower() == ".csv":
        with path.open("r", encoding="utf-8-sig", newline="") as stream:
            reader = csv.DictReader(stream)
            headers = reader.fieldnames or []
            return "CSV", headers, [dict(row) for row in reader]
    if path.suffix.lower() not in {".xlsx", ".xlsm"}:
        raise ValueError("Supported formats: .xlsx, .xlsm, .csv")
    from openpyxl import load_workbook
    workbook = load_workbook(path, read_only=True, data_only=True)
    selected = sheet_name or workbook.sheetnames[0]
    if selected not in workbook.sheetnames:
        raise ValueError(f"Sheet not found: {selected}")
    sheet = workbook[selected]
    iterator = sheet.iter_rows(values_only=True)
    try:
        headers = [str(v).strip() if v is not None else "" for v in next(iterator)]
    except StopIteration:
        return selected, [], []
    rows = []
    for values in iterator:
        if not any(v not in (None, "") for v in values):
            continue
        rows.append({headers[i]: values[i] if i < len(values) else None for i in range(len(headers))})
    return selected, headers, rows


def period_months(headers: list[str]) -> int | None:
    for header in headers:
        key = canonical_header(header)
        if key == "closed_2026_period":
            match = re.search(r"(?:ultimos|last)\s+(\d+)\s+(?:meses|months)", normalize(header))
            if match:
                return int(match.group(1))
    return None


def summarize(values: list[float]) -> dict[str, Any]:
    return {
        "count": len(values),
        "mean": round(statistics.fmean(values), 2),
        "median": round(statistics.median(values), 2),
        "min": min(values),
        "max": max(values),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("--out-dir", required=True)
    parser.add_argument("--sheet")
    args = parser.parse_args()

    source = Path(args.input).resolve()
    out_dir = Path(args.out_dir).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    sheet, headers, raw_rows = load_rows(source, args.sheet)

    header_map: dict[str, str] = {}
    canonical_seen: dict[str, list[str]] = defaultdict(list)
    for header in headers:
        key = canonical_header(header)
        if key:
            header_map[header] = key
            canonical_seen[key].append(header)

    ambiguous = {k: v for k, v in canonical_seen.items() if len(v) > 1}
    unmapped = [h for h in headers if h and h not in header_map]
    months = period_months(headers)

    normalized_rows = []
    invalid_numeric = []
    for row_number, raw in enumerate(raw_rows, start=2):
        canonical: dict[str, Any] = {}
        for header, value in raw.items():
            key = header_map.get(header)
            if key and key not in canonical:
                canonical[key] = json_safe(value)
        numeric: dict[str, float | None] = {}
        for key in NUMERIC_FIELDS:
            if key in canonical:
                parsed = parse_number(canonical[key])
                numeric[key] = parsed
                if canonical[key] not in (None, "") and parsed is None:
                    invalid_numeric.append({"row": row_number, "field": key, "value": canonical[key]})

        derived: dict[str, Any] = {}
        goal = numeric.get("annual_goal_transactions")
        closed = numeric.get("closed_2026_period")
        if goal and goal > 0 and closed is not None:
            derived["goal_progress_pct"] = round(closed / goal * 100, 1)
            derived["gap_to_goal"] = max(goal - closed, 0)
            if months and 0 < months <= 12:
                projection = closed / months * 12
                derived["projected_annual_closings"] = round(projection, 1)
                remaining = 12 - months
                derived["required_closings_per_remaining_month"] = (
                    round(max(goal - closed, 0) / remaining, 2) if remaining else None
                )
                if closed >= goal:
                    derived["goal_pace_status"] = "Meta lograda"
                elif projection >= goal:
                    derived["goal_pace_status"] = "En ritmo"
                elif projection >= goal * 0.8:
                    derived["goal_pace_status"] = "En riesgo"
                else:
                    derived["goal_pace_status"] = "Fuera de ritmo"
        if "goal_pace_status" not in derived:
            derived["goal_pace_status"] = "Datos insuficientes"

        appointments = numeric.get("appointments_90d")
        agreements = numeric.get("agreements_90d")
        clients = numeric.get("new_clients_90d")
        if appointments is not None and clients and clients > 0:
            derived["appointments_per_new_client"] = round(appointments / clients, 2)
        if agreements is not None and appointments and appointments > 0:
            derived["agreements_per_appointment_pct"] = round(agreements / appointments * 100, 1)
        new_contacts = numeric.get("new_contacts_90d")
        if new_contacts is not None:
            derived["new_contacts_per_week"] = round(new_contacts / 13, 2)

        normalized_rows.append({
            "source_row": row_number,
            "agent_name": canonical.get("agent_name"),
            "email": canonical.get("email"),
            "responses": canonical,
            "numeric": numeric,
            "derived": derived,
            "unmapped_responses": {h: json_safe(v) for h, v in raw.items() if h not in header_map and v not in (None, "")},
        })

    identities: dict[str, list[int]] = defaultdict(list)
    for idx, row in enumerate(normalized_rows):
        identity = normalize(row.get("email") or row.get("agent_name") or f"row-{row['source_row']}")
        identities[identity].append(idx)
    duplicate_groups = [
        {"identity": key, "source_rows": [normalized_rows[i]["source_row"] for i in indices]}
        for key, indices in identities.items() if len(indices) > 1
    ]

    latest_rows = []
    for indices in identities.values():
        latest_index = max(
            indices,
            key=lambda idx: timestamp_key(
                normalized_rows[idx]["responses"].get("timestamp"),
                normalized_rows[idx]["source_row"],
            ),
        )
        latest_rows.append(normalized_rows[latest_index])
    metrics: dict[str, dict[str, Any]] = {}
    for field in sorted(NUMERIC_FIELDS):
        values = [row["numeric"].get(field) for row in latest_rows]
        clean = [float(v) for v in values if v is not None]
        if clean:
            metrics[field] = summarize(clean)

    pace_counts = Counter(row["derived"].get("goal_pace_status", "Datos insuficientes") for row in latest_rows)
    manifest = {
        "source_file": str(source),
        "sheet": sheet,
        "response_rows": len(normalized_rows),
        "unique_agents": len(latest_rows),
        "period_months_detected": months,
        "headers": headers,
        "header_mapping": header_map,
        "unmapped_headers": unmapped,
        "ambiguous_canonical_fields": ambiguous,
        "invalid_numeric_values": invalid_numeric,
        "duplicate_groups": duplicate_groups,
    }
    team_summary = {
        "unique_agents": len(latest_rows),
        "metric_summaries": metrics,
        "goal_pace_distribution": dict(pace_counts),
    }

    (out_dir / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    (out_dir / "team_summary.json").write_text(json.dumps(team_summary, ensure_ascii=False, indent=2), encoding="utf-8")
    agents_dir = out_dir / "agents"
    agents_dir.mkdir(exist_ok=True)
    used_slugs: Counter[str] = Counter()
    for pos, row in enumerate(latest_rows, start=1):
        slug = re.sub(r"[^a-z0-9]+", "-", normalize(row.get("agent_name") or row.get("email") or f"agent-{pos}")).strip("-")
        slug = slug or f"agent-{pos}"
        used_slugs[slug] += 1
        if used_slugs[slug] > 1:
            slug = f"{slug}-{used_slugs[slug]}"
        history_indices = identities[normalize(row.get("email") or row.get("agent_name") or f"row-{row['source_row']}")]
        history_indices = sorted(
            history_indices,
            key=lambda idx: timestamp_key(
                normalized_rows[idx]["responses"].get("timestamp"),
                normalized_rows[idx]["source_row"],
            ),
        )
        payload = dict(row)
        payload["history"] = [normalized_rows[i] for i in history_indices]
        (agents_dir / f"{slug}.json").write_text(
            json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
        )

    print(json.dumps({"manifest": str(out_dir / "manifest.json"), "team_summary": str(out_dir / "team_summary.json"), "agents": len(latest_rows)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
