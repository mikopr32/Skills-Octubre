# Plantillas de reportes

## Reporte ejecutivo para Michael

1. **Conclusión ejecutiva**
   - tres hallazgos prioritarios;
   - riesgo principal del equipo;
   - oportunidad más rápida.
2. **Alcance y calidad de datos**
   - agentes, respuestas, duplicados y campos faltantes.
3. **Metas y ritmo de producción**
   - distribución de metas, avance, proyección y brecha.
4. **Pipeline y conversión**
   - clientes, citas, acuerdos, pendientes y prospectos.
5. **Actividad y sistemas**
   - conversaciones, follow-up, días de prospección, CRM y nurturing.
6. **Marketing y posicionamiento**
   - fuentes, contenido, lead magnets, CTA, newsletter y propuesta de valor.
7. **Farming, sellers y FSBO**
   - adopción, profundidad y oportunidades.
8. **Patrones y contradicciones**
   - hallazgos comunes con evidencia agregada.
9. **Mapa de intervención**
   - agente, estado, cuello principal, acción inmediata y pregunta 1-1.
10. **Plan de coaching 30-60-90**
    - prioridades, sesiones, recursos y KPIs del sistema.

Incluir tablas solo para comparaciones repetidas. No llenar el reporte con una ficha extensa por agente; usar la tabla de intervención y remitir a los reportes individuales.

## Reporte individual para el agente

1. **Mensaje directo de Michael**
2. **Tu resultado actual en números**
3. **Lo que estás haciendo bien**
4. **El cuello de botella que debemos resolver**
5. **La evidencia y la contradicción principal**
6. **Tu foco de 90 días**
7. **Tu scorecard**
   - meta de 90 días;
   - conversaciones semanales;
   - citas;
   - acuerdos/contratos;
   - una métrica de sistema según el cuello de botella.
8. **Actividad no negociable**
9. **Qué vas a detener, delegar o limitar**
10. **Plan de contingencia**
11. **Compromiso de los próximos 7 días**
12. **Preguntas para nuestra sesión 1-1**

Mantener el reporte accionable. Evitar repetir todas las respuestas del formulario. Citar solo las respuestas que cambian la decisión.
