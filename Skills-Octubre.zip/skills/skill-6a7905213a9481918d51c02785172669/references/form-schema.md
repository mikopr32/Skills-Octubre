# Esquema del formulario AMI

Usar este esquema para reconocer encabezados del Excel. Los encabezados reales son la autoridad. Las palabras clave ayudan a tolerar cambios menores de redacción.

| Clave canónica | Contenido | Uso analítico |
|---|---|---|
| `timestamp` | Marca temporal | ordenar respuestas |
| `agent_name` | Nombre completo | identidad |
| `email` | Correo electrónico | deduplicación |
| `annual_goal_transactions` | Meta de transacciones 2026 | meta anual |
| `closed_2026_period` | Transacciones cerradas en 2026 / últimos 7 meses | progreso |
| `closed_2025` | Transacciones cerradas en 2025 | contexto histórico |
| `new_clients_90d` | Clientes nuevos en 90 días | pipeline |
| `appointments_90d` | Citas en 90 días | conversión |
| `agreements_90d` | Acuerdos/listings firmados | conversión |
| `pending_transactions` | Pendientes/bajo contrato | resultado próximo |
| `qualified_pipeline` | Prospectos activos calificados | cobertura futura |
| `new_contacts_90d` | Contactos añadidos | crecimiento de base |
| `weekly_conversations_current` | Conversaciones semanales actuales | actividad líder |
| `weekly_followups_current` | Seguimientos semanales actuales | actividad líder |
| `prospecting_days_week` | Días con bloque de prospección | consistencia |
| `crm_update_frequency` | Frecuencia de actualización CRM | sistema |
| `database_size` | Contactos totales | activo comercial |
| `workday_description` | Día típico | auditoría de calendario |
| `call_time` | Horario de llamadas | ejecución |
| `followup_process` | Proceso de seguimiento | sistema |
| `active_prospect_contact_frequency` | Frecuencia de contacto | cadencia |
| `crm_campaigns` | Nurture/property alerts | automatización |
| `cta_types` | CTA de campañas | conversión de marketing |
| `lead_magnets` | Cantidad/canales | activos de captación |
| `social_post_frequency` | Frecuencia de contenido | visibilidad |
| `daily_lead_generation` | Actividades diarias | fuentes/ejecución |
| `top_lead_sources` | Tres fuentes principales | concentración/diversificación |
| `newsletter` | Newsletter/frecuencia | nurture |
| `weekly_special` | Especial semanal | reactivación |
| `farm_area` | Mercado geográfico | foco |
| `farm_neighborhoods` | Comunidades trabajadas | profundidad |
| `farm_activities` | Actividades de farming | autoridad |
| `seller_strategies` | Estrategias para sellers | captación |
| `fsbo_activity` | Prospección FSBO | canal |
| `fsbo_process` | Proceso FSBO | madurez del canal |
| `focus_score` | Enfoque | autopercepción |
| `focus_explanation` | Explicación de enfoque | evidencia narrativa |
| `willingness_score` | Disposición al cambio | autopercepción |
| `consistency_score` | Consistencia | autopercepción |
| `accountability_score` | Responsabilidad | autopercepción |
| `clarity_plan` | Claridad/plan de acción | sistema |
| `feelings_results` | Sentimiento sobre resultados | reflexión |
| `missing_factors` | Qué faltó | hipótesis del agente |
| `value_proposition` | Propuesta de valor | posicionamiento |
| `changes_90d` | Cambios dispuestos | compromiso |
| `personal_focus_90d` | Área personal | desarrollo |
| `professional_focus_90d` | Área profesional | negocio |
| `goal_transactions_90d` | Meta de cierres/contratos | meta próxima |
| `weekly_conversations_goal` | Meta semanal conversaciones | actividad comprometida |
| `nonnegotiable_activity` | Actividad no negociable | ejecución |
| `stop_delegate_limit` | Qué detener/delegar/limitar | protección de foco |
| `obstacle_response` | Obstáculo y respuesta | prevención |
| `niche_90d` | Nicho seleccionado | foco comercial |
| `niche_activities` | Actividades del nicho | plan |
| `missing_to_start` | Recurso/apoyo faltante | desbloqueo |

## Reglas de mapeo

- Normalizar mayúsculas, acentos, saltos de línea y espacios antes de comparar.
- Priorizar coincidencia exacta; luego palabras clave únicas.
- No mapear una columna a dos claves.
- No aceptar coincidencias débiles en campos financieros o metas.
- Conservar el encabezado original junto a la clave canónica para auditoría.
