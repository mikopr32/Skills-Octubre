# Rúbrica de análisis

## 1. Ritmo de meta

Calcular cuando existan meta anual, cierres acumulados y meses cubiertos:

- `avance = cierres acumulados / meta anual`
- `proyección anual = cierres acumulados / meses cubiertos * 12`
- `brecha = max(meta anual - cierres acumulados, 0)`
- `cierres mensuales requeridos = brecha / meses restantes`

Estados iniciales:

- `En ritmo`: proyección anual igual o mayor que la meta.
- `En riesgo`: proyección entre 80% y 99% de la meta.
- `Fuera de ritmo`: proyección menor que 80% de la meta.
- `Meta lograda`: cierres acumulados iguales o mayores que la meta.
- `Datos insuficientes`: falta un componente o la meta es cero.

No confundir esta clasificación con desempeño absoluto ni usarla para comparar públicamente.

## 2. Ratios observables

Calcular solo con denominador mayor que cero y etiquetar claramente el período:

- `citas por cliente nuevo = citas 90d / clientes nuevos 90d`
- `acuerdos por cita = acuerdos 90d / citas 90d`
- `pendientes por acuerdo = pendientes actuales / acuerdos 90d` (solo indicador aproximado; los períodos no son idénticos)
- `contactos nuevos por semana = contactos nuevos 90d / 13`

No llamar a estos ratios tasas de conversión definitiva cuando los períodos o cohortes no coinciden.

## 3. Matemática del plan de 90 días

Comparar:

- meta de transacciones de 90 días;
- conversaciones semanales comprometidas;
- actividad no negociable;
- actividades del nicho;
- calendario actual y días de prospección.

Señalar `La matemática no cuadra` únicamente cuando el volumen declarado sea objetivamente insuficiente para la meta usando su propia conversión histórica o una conversión suministrada por Michael. Sin tasa disponible, presentar escenarios, no una sentencia.

## 4. Señales operativas

Clasificar cada área como `Fortaleza`, `En desarrollo`, `Brecha` o `Sin datos`:

- CRM y próximos pasos;
- frecuencia y estructura de follow-up;
- nurturing y property alerts;
- newsletter y campañas;
- lead magnets y CTA;
- fuentes de leads;
- farming;
- sellers/FSBO;
- propuesta de valor;
- nicho y plan de 90 días.

Fundamentar cada clasificación con una respuesta concreta.

## 5. Cuello de botella

Seleccionar uno principal entre:

- actividad insuficiente;
- inconsistencia;
- baja conversión;
- pipeline débil;
- seguimiento deficiente;
- base de datos pequeña o desaprovechada;
- mensaje/propuesta de valor genérica;
- falta de nicho o foco geográfico;
- ausencia de sistema;
- brecha de habilidad/conocimiento;
- falta de información para decidir.

No seleccionar más de un cuello principal. Registrar hasta dos factores secundarios.

## 6. Priorización del equipo

Segmentar para fines de coaching privado:

- `Escalar`: en ritmo, sistemas consistentes y pipeline saludable.
- `Convertir`: actividad suficiente, pero baja progresión a citas/acuerdos.
- `Construir pipeline`: actividad o prospectos insuficientes.
- `Instalar sistema`: oportunidades presentes, seguimiento/CRM débiles.
- `Reenfocar`: demasiadas fuentes, nichos o actividades sin profundidad.
- `Intervención inmediata`: meta en riesgo y ausencia de ejecución verificable.

La etiqueta debe ir acompañada por evidencia y una acción concreta.
