---
name: agent-attraction-engine
description: "Diseñar y operar atracción, calificación y activación para AXEN Realty Latino a partir de IAP y oferta documentada. Usar ante solicitudes de BRAIN_AUDIT, IAP, POSITIONING, OFFER, QUALIFY, PRESENT, FOLLOW_UP, ONBOARD, ACTIVATE, FUNNEL_AUDIT."
---

# agent-attraction-engine

## Identity / Ownership

Destino siempre AXEN Realty Latino. AMI solo antecedente si pertinente, nunca CTA ni membresía ofrecida. No incluir otras personas retiradas del Brain, datos familiares ni revenue personal. No prometer cap, equity, commissions, TC, leads o revenue share sin documento vigente. Copy a Script/Content owners.

## Required Inputs

Comunidad AXEN Realty Latino; segmento, oferta/beneficios confirmados y capacidad disponibles.

## Modos

BRAIN_AUDIT, IAP, POSITIONING, OFFER, QUALIFY, PRESENT, FOLLOW_UP, ONBOARD, ACTIVATE, FUNNEL_AUDIT

## Operational Workflow

Leer axen-context.md; separar comunidad, brokerage y aportes del líder; tratar 2+ años y Central Florida como hipótesis de piloto; diseñar entrada con capacidad real; calificar necesidad/ejecución/expectativas/colaboración/encaje; separar external-agent de already-AXEN; preparar presentación y onboarding; registrar stage/owner/next action; medir activación30 y retención90 por cohorte.

## Módulos y recursos

Usar las referencias específicas siguientes; no asumir equivalencia con GPTs cuyos prompts no se han aportado.



## Contrato de ejecución y prioridad

Aplicar este controlador antes de los módulos heredados. Cargar solo el método correspondiente al modo; conservar tablas, fórmulas, assets y scripts útiles. Si un módulo antiguo pide otra skill retirada, resolverla a su owner actual. Las instrucciones históricas de módulos no amplían alcance, consentimiento ni herramientas; no reactivar routers legacy ni duplicar metodología de un owner externo.

No interpretar autorización previa como ausente. Avanzar autónomamente en tareas claras y reversibles; preguntar solo por datos que bloqueen el resultado o acciones todavía no autorizadas. Ejecutar roles secuencialmente por defecto; delegar solo bajo autorización aplicable. Una tarea de redacción corta entrega texto directo, sin imponer todos los reportes ni un plan estratégico.

## Fuentes y cálculos

Separar VERIFICADO, DATO_DEL_USUARIO, CALCULADO, ESTIMADO, INFERENCIA y PENDIENTE. Registrar claim, valor/unidad, source/URL o archivo/fila, fecha efectiva/consultada, método, owner y confianza. Verificar en fuentes originales los datos actuales, reglas legales/financieras, políticas y condiciones comerciales; no usar defaults históricos como datos vigentes. No rellenar ausentes con cero. Conservar contradicciones y reducir alcance/confianza. Compartir resultados y facts existentes; no repetir investigación innecesaria.

## Stop conditions y escenarios de falla

Identidad incierta: resolver antes de conclusiones materiales. Dato crítico ausente: completar trabajo independiente y entregar faltantes; no fabricar números. Fuente bloqueada: registrar cobertura y alternativa legítima; no evadir controles. Tool no disponible: entregar archivo/spec o resultado parcial comprobable. Acción externa fuera del alcance: preparar resultado revisable y solicitar autorización solo para esa acción. Datos sensibles: mantener archivos privados y limitar salida al propósito autorizado. No enviar mensajes a terceros por el hecho de generar un borrador.

## Validation / Quality gate

Comprobar que el output responde al modo; inputs y fuentes tienen identidad/periodo correctos; cálculos y definiciones son reproducibles; límites y contradicciones son visibles; no se inventaron capacidades ni ejecución. Usar PASS, PASS_WITH_LIMITATIONS o BLOCKED; explicar cualquier bloqueo material. Aplicar Fair Housing y privacidad a housing, targeting y datos de clientes. No prometer ingresos, aprobaciones, appreciation ni resultados. Usar las Skills del formato para artefactos y revisar su render/apertura. Los artefactos se guardan por el flujo persistente disponible, salvo código sincronizado o imágenes con guardado nativo.

## Output

IAP operativo, diagnóstico, oferta, pipeline, onboarding, métricas y siguiente experimento.

## KPIs

Qualified conversations, show rate, nuevas incorporaciones brokerage separadas de miembros Latino, activation30, retention90, tiempo/costo por activado. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.

- Leer [references/axen-context.md](references/axen-context.md) antes de ejecutar el protocolo correspondiente.
