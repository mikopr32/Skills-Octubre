# Contexto operativo AXEN Realty Latino

## Fuentes internas revisadas

AI_Brain_Michael_Cruz_Agent_Attraction.md, v1.2, 1 octubre 2026, e Ideal_Agent_Profile_AXEN_Realty_Latino.md, v1.0, misma fecha. Consultados 3 octubre 2026. Son contexto e hipótesis, no auditoría externa. Recuperar la versión actual por título si el usuario actualiza la oferta. No publicar ni copiar íntegramente archivos privados.

## Límites confirmados

Toda atracción conduce a AXEN Realty Latino. AMI Coaching/AMI Team son antecedentes, no oferta o requisito de incorporación. Mantener separadas la comunidad, las condiciones del brokerage AXEN Realty y la experiencia personal de Michael. No atribuir automáticamente patrocinio personal, acceso a todos los recursos ni acompañamiento ilimitado. No incorporar personas retiradas del Brain.

## IAP como hipótesis

Pilotear agentes activos con experiencia y disposición a ejecutar; 2+ años y Central Florida son recomendaciones exploratorias, no requisitos de la comunidad. Usar campañas separadas para productores, líderes y nuevos agentes si hay capacidad. No definir encaje por edad, nacionalidad, género, familia o acento. Miedos y motivaciones requieren entrevistas, no son hechos universales.

## Oferta y capacidad

Diagnóstico de Crecimiento de 20–30 minutos es una propuesta, no un servicio confirmado ni necesariamente gratuito. Verificar responsable, acceso, costo y disponibilidad antes de ofrecerlo. Usar una actividad elegible y realmente existente como alternativa. Confirmar beneficios, calendario, costos, condiciones del brokerage y pruebas de resultados antes de claims públicos.

## Calificación propuesta 0–10

Puntuar 0/1/2 por: necesidad atendible, compromiso de ejecución, expectativas realistas, colaboración observada y encaje operativo. Ausencia de evidencia exige aclaración, no juicio negativo. 8–10: conversación prioritaria; 5–7: aclarar y experimentar; 0–4: otra ruta o nurture. Es encaje preliminar, no probabilidad de conversión; no usarlo para afirmar intención de cambiar de brokerage.

## Dos rutas

Externo: interés → diagnóstico/calificación → experiencia elegible → comunidad y condiciones documentadas de brokerage → decisión → incorporación → activación.
Already AXEN: interés → requisitos de comunidad → bienvenida → participación → activación. No contar esta ruta como nueva incorporación al brokerage.

Guardar contact/source/piece/market/experience/need/expectations/stage/owner/next action/date de forma privada. Respetar preferencias de seguimiento. Activación30 propuesta: diagnóstico, plan, participación en actividad y primera acción documentada. Validar definición real antes de reportarla como KPI oficial.

## Aprendizaje

Proponer entrevistas exploratorias a 12 agentes repartidos entre activos, poco activos e interesados que no avanzaron, sin afirmar representatividad estadística. Preguntar qué esperaban, qué generó confianza, qué faltó y qué pesó en su decisión. Medir por segmento/ruta y cohorte madura; revisar activation30/retention90 y capacidad, además de citas. No escalar tráfico si la entrega no sostiene activación.
