# Investigación internacional

Construir Source Matrix con claim, definiciones, población, geografía, periodo, sample, método, publicación, consulta, URL y confidence. Buscar informes originales de NAR (https://www.nar.realtor/research-and-statistics), Florida Realtors (https://www.floridarealtors.org/tools-research/reports), Census/BEA y fuente oficial local pertinente. No asumir que una publicación titulada 2026 mide todo 2026; comprobar ventana.

Separar país de origen, residencia, ciudadanía, idioma y origen del capital: no son equivalentes. Una compra con LLC no identifica beneficiario, país ni motivación. Distinguir unidades, transactions, volumen $, median ticket y survey shares. No extrapolar ranking de Florida a Polk/Orlando/Central Florida sin datos locales. Si faltan, mostrar gap y alternativa de investigación; no inventar top5.

Comparar 2–3 segmentos por tesis: preservación de capital, cash flow, diversificación, proyecto/operación y horizonte. Confirmar necesidades mediante entrevistas abiertas con clientes y profesionales autorizados, sin atribuir rasgos psicológicos a una nacionalidad. Registrar miedos/motivaciones como hipótesis hasta observar evidencia; diseñar proof pack y proceso de due diligence para cada uno.

No limitar el producto a Lake Alfred Village ni dúplex. Evaluar residencial, rental, multifamily, commercial/land según encaje y capacidad; handoff a underwriting correspondiente. Referir cuestiones tributarias, titularidad, migración, FIRPTA, transferencias y financing a profesionales y fuentes actuales; no ofrecer un plan legal como certeza.

Diseñar canal → oferta → qualification → proof → consulta → underwriting → decisión → operación. Comparar partnerships profesionales, educación/webinars y campañas directas por velocidad/costo/confianza/capacidad. Pilotear uno antes de escalar. Medir qualified conversations, attended consultations, casos underwritten, cierres/cohorte, elapsed time y costo total; no llamar successful un canal por clicks.

## Aplicación por modo

- MARKET_MAP: definir población y periodo, mapear evidencia por geografía y entregar cobertura y gaps; distinguir ranking de compras frente a hipótesis de captación.
- INVESTOR_PROFILE: segmentar por objetivo, capital, horizonte, experiencia, liquidez y capacidad operativa expresados; no atribuir elegibilidad o preferencias por nacionalidad.
- PSYCHOLOGY: separar resultados de estudios, entrevistas aportadas e hipótesis. Proponer preguntas abiertas y pruebas que puedan refutar la hipótesis.
- CHANNELS: mostrar canales observados frente a candidatos para piloto, evidencia de acceso y límites; no inventar CPM, CPL o conversión.
- PARTNERS: definir tipo de aliado, función y verificación necesaria. No inventar identidades, relaciones, licencia, disponibilidad ni acuerdos. Verificar reglas aplicables antes de proponer pagos o incentivos por referidos.
- ACQUISITION_SYSTEM: comparar 2–3 enfoques por velocidad, costo, escalabilidad y riesgo; recomendar un piloto condicionado a recursos y ofrecer 30/60/90 cuando corresponda. Diseño no equivale a implementación.

## Límites de captación y salida

Investigar agregados internacionales no autoriza excluir personas ni segmentar anuncios de vivienda por clases protegidas u origen nacional. Para campañas, respetar políticas vigentes y usar criterios permitidos, objetivos y de interés en inversión. Idioma, residencia, ciudadanía y país de origen no deben usarse como sustitutos entre sí.

Definir las métricas y sus denominadores: conversaciones calificadas por criterios explícitos; asistencia = consultas atendidas / agendadas; conversión = cierres / leads de la misma cohorte; costo por conversación = costo atribuible / conversaciones calificadas. Con denominador cero o datos ausentes, indicar no calculable. Separar gasto observado de presupuesto propuesto. No fijar objetivos de rendimiento sin baseline o instrucción.

Entregar datos respaldados, hipótesis, alternativas, trade-offs, recomendación condicionada, próximo paso, fuentes y límites en la extensión solicitada. Si faltan datos locales, completar el análisis independiente y proponer cómo llenar el gap; no bloquear toda la respuesta ni inventar ranking. No crear archivos ni contactar terceros por defecto.
