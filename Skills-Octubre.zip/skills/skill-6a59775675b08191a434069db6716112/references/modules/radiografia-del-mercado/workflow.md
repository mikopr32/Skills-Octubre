# Módulo de método

Aplicar únicamente dentro de los límites del controlador SKILL.md del owner.

# Radiografía del Mercado

Producir análisis hiperlocales actuales, verificables y accionables. Separar hechos, inferencias y vacíos; nunca inventar acceso a fuentes cerradas ni completar cifras faltantes con supuestos silenciosos.

## Seleccionar modalidad

- **A — Radiografía del comprador:** usar cuando el usuario quiere saber quién compra, por qué, qué busca, cómo decide, dónde investiga y cómo captarlo en una ciudad o condado.
- **B — Estudio de comunidad:** usar cuando solicita analizar un vecindario, comunidad, subdivisión, condominio o desarrollo específico.
- **Combinada:** ejecutar A y B cuando el usuario pide tanto demanda/comprador como inventario/comunidad. Evitar duplicar contexto y reconciliar los hallazgos en una sola estrategia.

## Reunir entradas sin fricción

No volver a preguntar datos ya proporcionados. Solicitar en un solo turno únicamente lo indispensable.

### Modalidad A

Requerir:

1. Ciudad o condado y estado; asumir Florida solo si el contexto lo confirma.
2. Periodo del análisis: mes y año, rango o “actual”. Si dice “actual”, usar el mes vigente e indicar la fecha de corte.

Aceptar opcionalmente rango de precio, tipo de propiedad, comprador objetivo, idioma y propósito comercial.

### Modalidad B

Requerir:

1. Ciudad y estado.
2. Nombre exacto de la comunidad, vecindario o subdivisión legal.
3. Propiedades: solo unifamiliares o incluir condos/townhomes.
4. Alcance: activos solamente o activos más ventas recientes.

Solicitar aclaración solo si una ambigüedad cambia materialmente el universo, por ejemplo dos comunidades con el mismo nombre. Si existe una definición geográfica pública clara, declararla y continuar.

## Investigar

Leer [references/source-and-evidence-policy.md](references/source-and-evidence-policy.md) antes de investigar. Navegar la web porque los datos de mercado son temporales. Priorizar fuentes primarias y oficiales; usar portales como evidencia secundaria y contrastar cifras importantes.

1. Definir geografía, periodo, tipos de propiedad y fecha/hora de corte.
2. Crear una matriz interna de preguntas, métricas y fuentes antes de redactar.
3. Recoger datos actuales y comparables. Registrar fecha del dato, fecha de publicación y unidad geográfica.
4. Normalizar moneda, periodos, estatus, tipos de propiedad y días en mercado. No combinar ciudad, ZIP, Census place, condado y MSA sin advertirlo.
5. Distinguir:
   - **Hecho verificado:** respaldado directamente por una fuente.
   - **Cálculo:** derivado de datos mostrados; explicar fórmula o base.
   - **Inferencia:** interpretación razonable de varios hechos; etiquetarla.
   - **No disponible:** dato que no pudo verificarse.
6. Resolver discrepancias con la fuente más directa, reciente y geográficamente equivalente. Si persisten, mostrar el rango y explicar la diferencia.
7. Citar cada tabla y las afirmaciones materiales con enlaces directos. No citar páginas de resultados de búsqueda.

## Modalidad A — Radiografía real del comprador

Responder estas siete áreas:

1. **Quién está comprando:** composición observable de la demanda, etapa de compra, origen geográfico agregado, first-time/repeat cuando haya evidencia, ocupación principal/inversión y capacidad financiera mediante indicadores verificables.
2. **Por qué compra:** detonantes, presión de renta, reubicación, empleo, familia, inversión, incentivos, nueva construcción o cambios de estilo de vida respaldados por datos.
3. **Qué busca:** precio, pago, tipología, habitaciones, antigüedad, ubicación, amenities, HOA/CDD, incentivos y concesiones.
4. **Qué valora del agente:** necesidades de representación, educación, negociación, financiamiento, seguimiento, bilingüismo o conocimiento local cuando exista evidencia.
5. **Dónde está digitalmente:** consultas de búsqueda, plataformas, formatos y temas observables. No afirmar acceso a Meta Audience Insights ni datos privados si no existe.
6. **Cómo se comporta:** duración, orden de decisiones, objeciones, fuentes consultadas, visitas y puntos de abandono.
7. **Oportunidades de captación:** segmentos conductuales, ofertas, canales, mensajes, lead magnets, alianzas y follow-up.

Incluir:

- Resumen ejecutivo con 5–8 hallazgos.
- Indicadores clave del mercado y la demanda en tabla.
- Dos o tres perfiles conductuales basados en evidencia, no buyer personas ficticios.
- Señales fuertes, señales débiles y datos ausentes.
- Plan comercial priorizado: oportunidad, evidencia, mensaje, canal, CTA, velocidad/costo/riesgo.
- KPIs: CPL, tasa lead→cita, show rate, cita→cliente, cliente→contrato, tiempo de conversión y costo por contrato.
- Tres pruebas de 30 días con hipótesis, audiencia permitida, activo, KPI y criterio de éxito.

## Modalidad B — Estudio de comunidad

Leer [references/community-report-schema.md](references/community-report-schema.md) antes de redactar. Entregar:

1. **Definición y alcance:** límites utilizados, tipos de propiedad, ventana temporal y fecha de corte.
2. **Inventario residencial:** total de unidades y distribución por tipo. Si no existe conteo oficial, usar un proxy claramente rotulado o declarar “no verificado”.
3. **Mercado activo:** total y tabla de dirección, tipo, precio, camas/baños, área, precio por pie², DOM, estatus y fuente. No mostrar campos no verificables.
4. **Ventas recientes:** cuando se soliciten, tabla equivalente con precio de cierre y fecha. No presentar pendientes como cerradas.
5. **Valores y liquidez:** promedio, mediana, mínimo, máximo, precio por pie², DOM y relación venta/listado cuando la muestra lo permita. Mostrar `n` y advertir cuando `n < 5`.
6. **Tendencia 6–12 meses:** solo con series comparables; si no están disponibles, describir señales observadas sin fabricar tendencia.
7. **Costos y restricciones:** HOA, CDD, impuestos, seguros, flood zone, alquileres, edad/restricciones y evaluaciones especiales únicamente cuando se verifiquen.
8. **Calidad de vida:** seguridad, escuelas, transporte, servicios y comunidad/ambiente con indicadores objetivos, limitaciones y enlaces.
9. **Conclusión:** perfil en una frase, fortalezas, riesgos, comprador compatible en términos de necesidades y preguntas de debida diligencia.

## Cumplimiento y lenguaje

- Cumplir Fair Housing. No recomendar, excluir ni perfilar por raza, color, religión, sexo, discapacidad, estado familiar, origen nacional u otra clase protegida.
- Describir compatibilidad por presupuesto, desplazamiento, tipo de vivienda, mantenimiento, amenities y objetivos de compra; no por identidad personal.
- No usar “seguro/inseguro”, “buenas/malas escuelas”, “ideal para familias” ni equivalentes como conclusiones subjetivas. Presentar métricas, periodos, jurisdicción y fuentes para que el comprador evalúe.
- No inferir intención individual desde datos agregados ni sugerir segmentación publicitaria prohibida.
- Identificar contenido patrocinado, datos del vendedor o builder y posibles conflictos.

## Formato de salida

Usar presentación ejecutiva en español salvo que el usuario pida otro idioma. Emplear tablas para cifras y texto breve para interpretación. Encabezar con:

- **Mercado:** geografía exacta
- **Periodo analizado:** rango
- **Fecha de corte:** fecha y zona horaria
- **Alcance:** tipos de propiedad y estatus
- **Nivel de confianza:** alto, medio o bajo con una frase de justificación

Cerrar con:

1. Recomendación priorizada y justificación.
2. Riesgos o escenarios de falla.
3. Próximos pasos concretos.
4. Nota metodológica y limitaciones.
5. Fuentes enlazadas junto a cada afirmación; no crear una lista redundante si ya están bien citadas.

Si el usuario pide PDF, completar primero la investigación y después usar la capacidad de PDF para maquetar y verificar el documento. No convertir una respuesta incompleta en PDF.
