# Política de fuentes y evidencia

## Jerarquía recomendada

1. **Fuentes públicas primarias:** Census/ACS, HUD, FHFA, BLS, BEA, FEMA, FDOT, gobiernos locales, property appraiser, clerk/comptroller, school districts, policía o FDLE, planificación y GIS.
2. **Fuentes sectoriales directas:** Florida Realtors, NAR, asociaciones MLS cuando exista acceso autorizado, reportes oficiales de builders o administraciones de comunidades.
3. **Portales y datasets secundarios:** Realtor.com, Zillow, Redfin y otros portales públicos. Usarlos para triangulación, no como sustituto silencioso del MLS.
4. **Señales de comportamiento:** Google Trends, anuncios públicos, contenido de plataformas y tendencias de búsqueda. Tratar como señales relativas, no conteos exactos de compradores.
5. **Fuentes editoriales:** prensa local y reportes de terceros; emplear para contexto y verificar sus datos subyacentes.

## Reglas de actualidad

- Usar el periodo pedido por el usuario y declarar fecha de corte.
- Priorizar el dato más reciente disponible, aunque la publicación sea posterior al periodo medido.
- Permitir datos históricos anteriores al periodo solo para comparar; etiquetarlos y evitar que dominen el perfil actual.
- No mezclar periodos mensuales, trimestrales y anuales sin normalización explícita.

## Fuentes cerradas o no disponibles

- No afirmar acceso a MLS, Meta Audience Insights, plataformas sociales privadas, NAR restringido ni datasets de pago sin acceso real.
- Si una fuente clave no está disponible, usar una alternativa pública, reducir el nivel de confianza y explicar el impacto.
- No estimar conteos de listings a partir de una página parcial o paginada sin verificar cobertura.

## Cálculos

- Mostrar tamaño de muestra (`n`).
- Calcular promedio como suma/n y mediana sobre observaciones ordenadas.
- No calcular tendencia con universos geográficos o filtros diferentes.
- Distinguir precio de listado de precio de cierre.
- No deduplicar propiedades solo por dirección abreviada; confirmar parcela o dirección normalizada cuando sea posible.

## Calidad mínima

Antes de entregar, comprobar:

- Cada número material tiene fuente, periodo y geografía.
- Las tablas no contienen filas inventadas ni campos vacíos presentados como cero.
- Las inferencias están etiquetadas.
- Las discrepancias y limitaciones son visibles.
- Los enlaces abren la página que respalda la afirmación.
- El análisis distingue demanda observada de recomendaciones de marketing.
