# Esquema del reporte de comunidad

## Tabla de inventario

| Tipo | Unidades verificadas | Participación | Fuente/fecha | Confianza |
|---|---:|---:|---|---|

## Tabla de propiedades activas

| Dirección | Tipo | Precio | Beds/Baths | Área ft² | $/ft² | DOM | Estatus | Fuente |
|---|---|---:|---|---:|---:|---:|---|---|

## Tabla de ventas recientes

| Dirección | Tipo | Cierre | Fecha | Beds/Baths | Área ft² | $/ft² | DOM | Fuente |
|---|---|---:|---|---|---:|---:|---:|---|

## Resumen estadístico

| Métrica | Activos | Vendidos | Periodo | n |
|---|---:|---:|---|---:|
| Promedio | | | | |
| Mediana | | | | |
| Mínimo–máximo | | | | |
| Precio por ft² mediano | | | | |
| DOM mediano | | | | |
| Venta/listado | N/A | | | |

Omitir columnas o tablas que no correspondan al alcance. No rellenar con `0` un dato desconocido.

## Calidad de vida comparable

Para cada categoría incluir: indicador, periodo, geografía, interpretación neutral, limitación y enlace.

| Categoría | Evidencia útil | Precaución |
|---|---|---|
| Seguridad | Incidentes/tasa oficial, jurisdicción y periodo | No convertir una métrica parcial en garantía de seguridad |
| Escuelas | Asignación escolar y resultados oficiales | Verificar zonificación; puede cambiar |
| Transporte | Tiempos/rutas, acceso vial, tránsito y obras | Diferenciar hora pico y distancia lineal |
| Servicios | Distancias verificables a salud, compras y recreación | No confundir proximidad con calidad |
| Comunidad y ambiente | Amenities, HOA/CDD, uso de suelo, flood zone, ruido | Separar hechos, preferencias y obligaciones legales |

## Cierre de debida diligencia

Incluir preguntas pendientes para comprador/agente: HOA y estoppel, CDD, assessments, restricciones de alquiler, seguros, flood/elevation, permisos, zonificación escolar, obras planificadas y condición de la propiedad.
