# Noticias, regulación y selección editorial de Florida

Aplicar dentro del controlador florida-market-intelligence. Investigar y verificar historias; entregar un Fact Pack reutilizable. La producción de artículos, newsletters, carruseles, Reels y campañas pertenece a real-estate-content-engine. Si falta ese owner, entregar el brief y declarar la limitación. No publicar ni programar por preparar un borrador.

## Alcance

Definir geografía, tema, audiencia, decisión, periodo y profundidad. Distinguir state, region, metro, county, city, ZIP, community y building. Si solo se indica Florida, usar alcance estatal, últimos siete días y hasta tres historias diversas, con ejemplos locales etiquetados. Son defaults editoriales, nunca cifras del mercado.

Usar NEWS para scans de 24–72 horas o newsroom semanal; REGULATION para cambios legales; CONTENT_BRIEF para convertir investigación existente en evidencia para contenido. Para infraestructura y pipeline, cargar monitor-crecimiento-florida. Una historia no exige longlist ni todos los reportes. Aceptar ejercicios ficticios y respetar no consultar internet: sus inputs son DATO_DEL_USUARIO.

## Fuentes y discovery

Leer references/florida-source-map.md. Buscar fuentes originales para claims materiales; periodismo para contexto; redes, foros y snippets solo para discovery. Registrar canales y consultas realmente accesibles. No afirmar cobertura de plataformas no revisadas ni evadir paywalls o autenticación. No llamar oficial a un medio.

Explorar categorías pertinentes: vivienda, costos, seguros, HOA/CDD, condos, regulación, financiación, desarrollos, infraestructura, empleadores y servicios objetivos. realestate-market produce análisis de oferta/demanda y clasificación del mercado; reutilizar sus resultados. No inferir protected-class fit.

Separar event date, data period, publication date, consulted date y effective date. No llamar tendencia a una observación aislada ni convertir statewide data en información hiperlocal.

## Selección

Para newsroom amplio, reunir hasta 8–15 candidatos cuando existan fuentes suficientes. Registrar CANONICAL_STORY_ID, categoría, geografía, audiencia, fechas, fuentes primaria/secundaria, claim, impacto, acción, incertidumbre y confianza. Para un tema específico, investigar solo ese tema. Deduplicar historias y claims; compartir una fila maestra por CLAIM_ID.

Ejecutar discovery, verificación, reconciliación y síntesis secuencialmente por defecto. Delegar solo bajo autorización aplicable y herramientas disponibles; no simular agentes.

Usar scripts/rank_stories.py cuando resulte útil: decisión 20, impacto 20, especificidad local 15, verificabilidad 15, frescura 10, acción 10, potencial visual 5 y originalidad 5. Documentar los ocho componentes; el script rechaza ausentes y números no finitos. El score ordena atención editorial; no verifica hechos ni predice valor o retorno.

Seleccionar hasta tres historias diversas y respaldadas. Revisar la selección del script; no incluir claims sin respaldo por su score. Producir menos si faltan temas verificables. Si el usuario pidió elegir, mostrar 3–5 opciones con ID, fuentes, geografía, confianza y estado; esperar elección solo para esa producción. Si ya eligió, avanzar.

## Fact Pack y Claim Ledger

Registrar claim, valor/unidad, geografía, periodo, source/URL o archivo/fila, clase de fuente, emisor, fechas, método, supuestos, confianza, conflicto y wording respaldado. Separar VERIFICADO, DATO_DEL_USUARIO, CALCULADO, ESTIMADO, INFERENCIA y PENDIENTE. No completar ausentes con cero.

Comprobar average/median, mensual/anual, preliminary/final, listed/closed y YoY/MoM. Conservar cifras incompatibles y explicar diferencias de alcance, fecha, muestra o definición. Mostrar señales mixtas; no seleccionar solo datos favorables a vender.

Para regulación, distinguir propuesta, aprobación, vigencia, texto legal, interpretación e implicación práctica. Verificar jurisdicción y fuente original. No prometer rates, premiums, incentives, developments, appreciation, permisos ni approvals.

## Brief y handoff

Entregar pregunta central, cambio, evidencia, alcance local, contexto omitido, consecuencias, trade-offs, incertidumbres y acción práctica. Incluir wording permitido, claims aún pendientes, fuentes, fecha de revisión y trigger de actualización.

Para formato largo, leer references/seo-aeo-geo-editorial.md como especificación para el owner de contenido: intención, respuesta inicial, estructura, keywords naturales, geografía sustentada y fuentes. No inventar enlaces ni recursos descargables. No producir campañas completas desde este módulo.

Investigar tendencias creativas solo cuando lo requiera el brief. Registrar muestra, fecha, región y límites; no afirmar top 1% ni resultados comerciales sin evidencia. Respetar copyright y no copiar branding o scripts.

## Salida y control

Adaptar extensión al pedido. Incluir alcance, fechas, fuentes revisadas, hallazgos, selección cuando aplique, Fact Pack, limitaciones y siguiente acción. No imponer calendarios, archivos ni campañas a consultas breves.

Revisar geografía, fechas, definiciones, fuentes primarias, contradicciones, derechos, Fair Housing y claims legales/financieros. No publicar, contactar, gastar o modificar cuentas sin autorización aplicable. Respetar controles de plataforma. Informar PASS, PASS_WITH_LIMITATIONS o BLOCKED según ejecución real. Medir cobertura de claims con periodo y denominador; no inventar metas de publicación o conversión.
