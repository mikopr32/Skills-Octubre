# Módulo de método

Aplicar únicamente dentro de los límites del controlador SKILL.md del owner.

# AMI Distress Radar

## Objetivo

Convertir un único input —el condado— en un radar verificable de oportunidades residenciales distressed. Investigar con fuentes públicas gratuitas, coordinar subagentes por función y entregar candidatos priorizados para revisión profesional.

Tratar cada señal como hipótesis hasta verificarla. No afirmar que una persona está en distress, que una propiedad requiere short sale o que existe equity negativo sin evidencia suficiente.

## Input mínimo

Aceptar solamente `Condado: {nombre}`. Asumir Florida si el usuario no indica estado. Si el nombre corresponde inequívocamente a un condado de Florida, no formular preguntas adicionales. Preguntar el estado únicamente cuando el condado sea ambiguo o no exista en Florida.

No pedir al usuario CSV, MLS, documentos, credenciales, APIs, listas ni suscripciones. Si una fuente exige login, CAPTCHA, pago o acceso restringido, omitirla, registrar la limitación y continuar.

## Reglas no negociables

- Usar fuentes públicas gratuitas, sitios oficiales y búsquedas web permitidas.
- No evadir autenticación, CAPTCHA, robots, paywalls ni términos de servicio.
- No usar skip tracing, datos comprados ni inferencias sobre clases protegidas.
- No generar cold SMS, robocalls, voicemail drops ni campañas automáticas.
- No presentar asesoría legal, fiscal, crediticia o de foreclosure.
- Separar hechos, cálculos, inferencias, supuestos y desconocidos.
- Incluir URL, fuente, fecha efectiva, fecha de consulta y confianza para cada señal material.
- No usar un AVM o saldo hipotecario estimado como prueba de short sale.
- No llamar oportunidad a un filing sin analizar valor, deuda conocida, liens, condición, plazo y salida.
- Evitar duplicar puntos cuando varias fuentes describen el mismo evento.

## Roles de investigación

Coordinar las fases secuencialmente por defecto. Delegar investigación a subagentes solo con autorización aplicable y herramientas disponibles. Leer `references/agent-roles.md` antes de delegar. Ejecutar en paralelo los trabajos independientes cuando la plataforma lo permita.

Mantener estas responsabilidades separadas:

1. **Source Mapper:** localizar fuentes oficiales y públicas del condado.
2. **Court & Foreclosure Researcher:** revisar casos civiles, lis pendens, judgments, foreclosure sales y cancelaciones.
3. **Tax & Municipal Researcher:** revisar tax delinquencies, tax deeds, liens, code enforcement, permits y señales municipales.
4. **Market Signal Researcher:** buscar short sales públicos, REO, auctions, listings fallidos, DOM y reducciones visibles legalmente.
5. **Normalization Agent:** normalizar direcciones, parcel IDs, entidades y fechas; deduplicar.
6. **Verification Agent:** contrastar candidatos prioritarios y resolver conflictos.
7. **Ranking Owner:** calcular centralmente los scores y rutas; ningún recolector asigna el score final.

Cuando no puedan ejecutarse subagentes, conservar la separación de roles y ejecutar secuencialmente.

## Workflow

### 1. Crear el Source Registry

Localizar primero:

- Clerk of Court: civil cases, foreclosure filings, dockets y sale calendar.
- Official Records/Recorder: lis pendens, mortgages, releases, liens, judgments y deeds.
- Tax Collector: delinquent taxes, tax certificates y tax deed applications.
- Property Appraiser: parcel, assessed data, last sale y legal owner cuando sea público.
- County/municipal code enforcement: open violations, unsafe structures y nuisance cases.
- Building permits: roof, storm, fire, demolition o unresolved permits.
- Sheriff, clerk o authorized auction calendar.
- Portales públicos de listings o auctions únicamente cuando su acceso y términos lo permitan.

Registrar cobertura, método de acceso, campos disponibles, actualización y bloqueos. Leer `references/source-strategy.md`.

### 2. Construir el universo inicial

Buscar eventos dentro de una ventana predeterminada de 180 días. Ampliar a 365 días cuando se encuentren menos de 25 registros candidatos antes de deduplicar. Capturar solo los campos necesarios del esquema canónico de `references/data-contract.md`.

No declarar cobertura total del condado si alguna fuente no ofrece búsqueda masiva o exportación.

### 3. Detectar señales

Clasificar cada señal:

- **Confirmada:** filing, recorded document, court order, auction date, tax delinquency o listing que declara short sale.
- **Corroborada:** aparece en dos fuentes independientes compatibles.
- **Predictiva:** combinación de datos que sugiere riesgo, sin evento legal confirmado.
- **Débil:** lenguaje ambiguo, DOM, condición visual o dato no actualizado.

Buscar foreclosure complaint o lis pendens; final judgment y auction date; auction cancelada, pospuesta o completed; REO o certificate of title; tax delinquency o tax deed; HOA/condominium lien o foreclosure; múltiples liens; short sale o third-party approval; expired, canceled, withdrawn, back on market, reducciones y DOM anómalo; code cases, unsafe structures y reparaciones materiales; valor conservador frente a deuda y liens conocidos. Considerar DOM anómalo únicamente cuando sea al menos 90 días y supere dos veces la mediana verificable del mismo segmento; si no existe mediana, describir solo el DOM observado sin asignar la señal.

### 4. Normalizar y deduplicar

Usar parcel ID como llave primaria cuando exista. En su ausencia, usar dirección normalizada. Conservar variantes y fuentes. Resolver unit numbers, direcciones postales versus físicas, cambios de propietario, releases, dismissals, satisfactions, cancelaciones y múltiples casos por propiedad.

### 5. Verificar el shortlist

Verificar todo candidato que pueda entrar en prioridad alta. Exigir un documento o evento oficial primario, o dos fuentes independientes con al menos una oficial. Buscar activamente eventos que invaliden la señal: dismissal, release, satisfaction, sale completed, certificate of title, transferencia reciente o listing cerrado.

### 6. Calcular scores

Leer `references/scoring.md`. Mantener separados:

- **Distress Score:** intensidad y proximidad verificable del evento.
- **Opportunity Viability Score:** probabilidad de que exista una estrategia inmobiliaria ejecutable.

Usar `scripts/score_candidates.py` cuando exista un CSV canónico. El Ranking Owner puede calcular manualmente aplicando exactamente la misma rúbrica.

No entrenar un modelo predictivo sin outcomes históricos suficientes. Usar reglas transparentes y ajustarlas solo con resultados documentados.

### 7. Asignar ruta

Asignar una sola ruta principal:

- **Urgent legal-stage review:** auction o judgment próximo.
- **Short-sale assessment:** posible déficit, plazo disponible y evidencia suficiente; requiere payoff y title.
- **Traditional-sale possibility:** distress confirmado pero equity aparentemente suficiente.
- **Investor/due-diligence candidate:** condición o precio potencialmente viable.
- **Priority conditioned:** distress relevante con datos críticos todavía pendientes.
- **Watchlist:** señales tempranas sin confirmación suficiente.
- **Low priority:** score insuficiente para dedicar verificación adicional.
- **Exclude:** resuelto, vendido, duplicado, fuera de ventana, incorrecto o margen inviable.

La ruta describe la próxima revisión, no una recomendación de inversión ni una afirmación sobre el propietario.

### 8. Generar entregables

Seguir `references/output-contract.md` y crear:

1. `DISTRESS-RADAR-{COUNTY}-{DATE}.md`
2. `PRIORITY-CANDIDATES-{COUNTY}-{DATE}.csv`
3. `WATCHLIST-{COUNTY}-{DATE}.csv`
4. `SOURCE-REGISTRY-{COUNTY}-{DATE}.csv`
5. `EXCLUDED-{COUNTY}-{DATE}.csv`
6. Un dossier Markdown por candidato de prioridad alta.

## Quality gate

Antes de entregar, confirmar:

- Condado, periodo y cobertura están claros.
- Cada candidato tiene identidad verificable y los duplicados están consolidados.
- Filings resueltos o cancelados fueron descartados o actualizados.
- Auction dates incluyen fecha de consulta y estado.
- Hechos, inferencias y estimaciones están separados.
- Short sale nunca se afirmó sin confirmación o déficit sustentado.
- El score fue calculado centralmente.
- Descartes, bloqueos y gaps de cobertura están revelados.
- No se presenta contacto personal como verificado cuando no lo está.
- No se generó outreach automatizado.

Finalizar la ejecución cuando se hayan revisado todas las fuentes `bulk` accesibles, se hayan usado las fuentes `verification_only` para el shortlist, no quede ningún candidato de posible prioridad alta sin estado explícito y todos los bloqueos estén documentados. La imposibilidad de acceder a una fuente no impide finalizar con cobertura parcial declarada.

## Límites de la detección temprana

Explicar que un sistema gratuito basado en fuentes públicas normalmente detecta distress después de una señal pública. Puede anticipar algunos casos mediante tax, liens, listings y code enforcement, pero no puede conocer pagos hipotecarios atrasados no publicados, balances actuales, hardship, loss mitigation ni intención del propietario sin consentimiento.

## Mejora continua

Si existen ejecuciones anteriores, comparar cambios y medir precisión, false-positive rate, tiempo desde filing hasta detección, candidatos nuevos/resueltos/escalados, rutas ejecutables y rendimiento por fuente. No modificar pesos por una sola ejecución; recalibrar después de al menos 30 resultados verificados.
