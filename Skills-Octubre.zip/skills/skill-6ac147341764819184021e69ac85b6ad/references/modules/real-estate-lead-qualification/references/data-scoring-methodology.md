# Calidad y prioridad operativa de leads

El script conserva filas, normaliza contactos y marca duplicados. No calcula deuda ni equity: sus columnas financieras permanecen vacías y el método indica PENDING_VERIFIED_FINANCIAL_INPUTS. Campos Source_* son datos importados, no confirmación de payoff.

Un score operativo combina señales disponibles y contactabilidad conforme a su rúbrica; no es ranking de equity, probabilidad de venta, appraisal o crédito. El ranking patrimonial pertenece al protocolo equity-farming del owner; no excluir oportunidades por carecer de teléfono.

No usar defaults de apreciación, LTV, tasa o plazo ni amortización histórica para inventar balances. Para escenario hipotético solicitado, separar inputs, método y límites de la lista de propietarios.

Dirección postal distinta es una señal por verificar, no prueba de ocupación, distress o motivación. Preservar unidades. Conservar ausentes y contradicciones; no usar clases protegidas o proxies discriminatorios. Aplicar opt-outs/supresión antes de cualquier acción comercial. Contactabilidad sintáctica no autoriza contacto. Mantener exports privados y proteger CSV de fórmulas.
