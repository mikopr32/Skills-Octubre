# Rúbrica de scoring

Calcular dos scores; usar topes para evitar doble conteo. Los scores priorizan investigación, no predicen motivación, aprobación o cierre.

## Distress Score 0–100

- Etapa legal, máximo 35: auction 35; final judgment 30; complaint/lis pendens 25; tax deed 22; HOA foreclosure 20; REO 18; dismissed/released 0.
- Presión financiera, máximo 25: tax delinquent 10; tax deed 12; HOA lien 8; otros liens hasta 8; equity negativo estimado 7.
- Mercado, máximo 20: confirmed short sale 15; third-party approval 12; REO 12; expired/canceled/withdrawn 6; back on market 5; tres reducciones 5; DOM anómalo 4.
- Propiedad/municipal, máximo 10: unsafe 8; code 5; permit 4; condition 3.
- Evidencia, máximo 10: evento oficial vigente más corroboración 10; una fuente oficial 8; secundaria 3; conflicto 0.

Usar solo el evento legal activo de mayor puntuación. DOM es anómalo únicamente si es al menos 90 días y supera 2× la mediana del mismo segmento; si falta mediana, no puntuar DOM.

## Deal Viability Score 0–100

- Identidad y status verificables: 20.
- Valor sustentado con rango: 20.
- Deuda/liens suficientemente conocidos: 20.
- Plazo ejecutable: 15.
- Ruta plausible: 15.
- Condición/title manejables: 10.

Penalizar: auction en 14 días o menos -20; title conflict -15; valor débil -15; deuda crítica desconocida -15. Excluir vendido, transferido o evento principal resuelto sin señal activa.

## Confianza

- Alta: fuente oficial, corroboración y datos críticos suficientes.
- Media: evento oficial con faltantes materiales.
- Baja: señal predictiva/secundaria, conflicto o cobertura parcial.

## Prioridad

- Distress ≥75 y Viability ≥50: alta.
- Distress 60–74 y Viability ≥45: condicionada.
- Distress 40–59: watchlist.
- Distress <40: baja.
- Auction ≤14 días: `urgent_legal_stage_review`, independientemente del score.

## Routing auxiliar

- Aplicar primero, en este orden: `exclude`; urgencia; intención directa del propietario; REO; umbrales de prioridad.
- No elevar una señal con Distress <60 a ruta activa solo porque parezca tener equity o sea comercialmente vendible. Mantener `low_priority` o `watchlist` y registrar la ruta comercial como alternativa.
- Dentro de prioridad alta o condicionada, equity base positivo y status ejecutable: `traditional_sale_possibility`.
- Dentro de prioridad alta o condicionada, déficit corroborado, tiempo y datos suficientes: `short_sale_assessment`.
- Margen as-is plausible, condición o velocidad relevante: `investor_due_diligence`.
- Retention intent revelado por propietario: `home_retention_resource_review`.
- REO o sale process: `reo_or_auction_buyer_review`.
- Datos críticos faltantes: `priority_conditioned`.

La señal de equity negativo requiere deuda actual y liens verificados, junto con valor sustentado y sus límites. Sin esos inputs, mantener PENDIENTE y no activar la señal ni inferir short sale. Los scripts puntúan señales ya verificadas; no las verifican por sí mismos.
