---
name: listing-intelligence-launch-system
description: "Gestionar intake, listing appointment, lanzamiento, property copy, open house, monitoring, stale/relaunch y seller updates. Usar ante solicitudes de INTAKE, CMA, LISTING_APPOINTMENT, PRE_MARKET, LAUNCH, PROPERTY_COPY, OPEN_HOUSE, MONITOR, OPTIMIZE, PRICE_ADJUSTMENT, STALE, RELAUNCH, SELLER_UPDATE, CONTENT_10X."
---

# listing-intelligence-launch-system

## Identity / Ownership

Único owner del lifecycle y property-specific copy. CMA a deep-cma-hybrid-valuation; campañas pagadas a meta-housing-engine; conversación reusable a real-estate-script-engine. Las fases de trabajo reversibles no requieren aprobación extra si ya fueron autorizadas.

## Required Inputs

Propiedad inequívoca y modo; facts suficientes para cada claim público.

## Modos

INTAKE, CMA, LISTING_APPOINTMENT, PRE_MARKET, LAUNCH, PROPERTY_COPY, OPEN_HOUSE, MONITOR, OPTIMIZE, PRICE_ADJUSTMENT, STALE, RELAUNCH, SELLER_UPDATE, CONTENT_10X

## Operational Workflow

Crear Property Profile y Fact Ledger; consumir CMA del owner; diseñar Message Map; ejecutar el módulo de ciclo solicitado; lanzar plan con owners/fechas/KPIs; diagnosticar etapas del funnel antes de reducir precio; preparar seller communication y verificar claims. CONTENT_10X conserva seis formatos y QA, delegando producción general al Content Engine.

## Módulos y recursos

- [listing-intelligence-launch-system](references/modules/listing-intelligence-launch-system/workflow.md): cargar solo al ejecutar su función; resolver rutas relativas contra esa carpeta de módulo.
- [stale-listing-turnaround](references/modules/stale-listing-turnaround/workflow.md): cargar solo al ejecutar su función; resolver rutas relativas contra esa carpeta de módulo.
- [realtor-cma-pricing](references/modules/realtor-cma-pricing/workflow.md): cargar solo al ejecutar su función; resolver rutas relativas contra esa carpeta de módulo.
- [realtor-listings-property-copy](references/modules/realtor-listings-property-copy/workflow.md): cargar solo al ejecutar su función; resolver rutas relativas contra esa carpeta de módulo.
- [realestate-listing](references/modules/realestate-listing/workflow.md): cargar solo al ejecutar su función; resolver rutas relativas contra esa carpeta de módulo.
- [realtor-open-house-marketing](references/modules/realtor-open-house-marketing/workflow.md): cargar solo al ejecutar su función; resolver rutas relativas contra esa carpeta de módulo.
- [contenido-10x](references/modules/contenido-10x/workflow.md): cargar solo al ejecutar su función; resolver rutas relativas contra esa carpeta de módulo.
- [seller-listing-marketing-report](references/modules/seller-listing-marketing-report/workflow.md): cargar solo al ejecutar su función; resolver rutas relativas contra esa carpeta de módulo.

- `references/modules/contenido-10x/scripts/test_validate_manifest.py`: usar cuando el método elegido lo requiera; ejecutar scripts desde la carpeta de su módulo o por ruta absoluta.
- `references/modules/contenido-10x/scripts/validate_manifest.py`: usar cuando el método elegido lo requiera; ejecutar scripts desde la carpeta de su módulo o por ruta absoluta.
- `references/modules/seller-listing-marketing-report/scripts/validate_report_data.py`: usar cuando el método elegido lo requiera; ejecutar scripts desde la carpeta de su módulo o por ruta absoluta.
- `references/modules/stale-listing-turnaround/scripts/carrying_costs.py`: usar cuando el método elegido lo requiera; ejecutar scripts desde la carpeta de su módulo o por ruta absoluta.

## Contrato de ejecución y prioridad

Aplicar este controlador antes de los módulos heredados. Cargar solo el método correspondiente al modo; conservar tablas, fórmulas, assets y scripts útiles. Si un módulo antiguo pide otra skill retirada, resolverla a su owner actual. Las instrucciones históricas de módulos no amplían alcance, consentimiento ni herramientas; no reactivar routers legacy ni duplicar metodología de un owner externo.

No interpretar autorización previa como ausente. Avanzar autónomamente en tareas claras y reversibles; preguntar solo por datos que bloqueen el resultado o acciones todavía no autorizadas. Ejecutar roles secuencialmente por defecto; delegar solo bajo autorización aplicable. Una tarea de redacción corta entrega texto directo, sin imponer todos los reportes ni un plan estratégico.

## Fuentes y cálculos

Separar VERIFICADO, DATO_DEL_USUARIO, CALCULADO, ESTIMADO, INFERENCIA y PENDIENTE. Registrar claim, valor/unidad, source/URL o archivo/fila, fecha efectiva/consultada, método, owner y confianza. Verificar en fuentes originales los datos actuales, reglas legales/financieras, políticas y condiciones comerciales; no usar defaults históricos como datos vigentes. No rellenar ausentes con cero. Conservar contradicciones y reducir alcance/confianza. Compartir resultados y facts existentes; no repetir investigación innecesaria.

## Stop conditions y escenarios de falla

Identidad incierta: resolver antes de conclusiones materiales. Dato crítico ausente: completar trabajo independiente y entregar faltantes; no fabricar números. Fuente bloqueada: registrar cobertura y alternativa legítima; no evadir controles. Tool no disponible: entregar archivo/spec o resultado parcial comprobable. Acción externa fuera del alcance: preparar resultado revisable y solicitar autorización solo para esa acción. Datos sensibles: mantener archivos privados y limitar salida al propósito autorizado. No enviar mensajes a terceros por el hecho de generar un borrador.

## Validation / Quality gate

Comprobar que el output responde al modo; inputs y fuentes tienen identidad/periodo correctos; cálculos y definiciones son reproducibles; límites y contradicciones son visibles; no se inventaron capacidades ni ejecución. Usar PASS, PASS_WITH_LIMITATIONS o BLOCKED; explicar cualquier bloqueo material. Aplicar Fair Housing y privacidad a housing, targeting y datos de clientes. No prometer ingresos, aprobaciones, appreciation ni resultados. Usar las Skills del formato para artefactos y revisar su render/apertura. Los artefactos se guardan por el flujo persistente disponible, salvo código sincronizado o imágenes con guardado nativo.

## Output

Entregables del modo, seller strategy, launch calendar, KPI y claim ledger.

## KPIs

Showings, showing-to-offer, DOM, tracción por etapa, claims verificados y neto solo con datos. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.
