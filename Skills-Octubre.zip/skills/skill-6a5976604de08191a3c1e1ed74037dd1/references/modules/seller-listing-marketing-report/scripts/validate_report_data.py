#!/usr/bin/env python3
"""Validate and summarize seller listing marketing report data."""

from __future__ import annotations

import json
import sys
from pathlib import Path


METRICS = ("views", "saves", "favorites", "likes", "shares", "inquiries", "leads")
CHANNEL_METRICS = ("impressions", "reach", "clicks", "video_views", "engagements", "leads", "spend")
SCOPES = {"reporting_period", "cumulative", "rolling_window", "unknown"}
ACCESS = {"public", "authorized_dashboard", "user_provided"}


def is_nonempty(value: object) -> bool:
    return isinstance(value, str) and bool(value.strip())


def rate(numerator: int | float | None, denominator: int | float | None) -> float | None:
    if numerator is None or denominator in (None, 0):
        return None
    return round(numerator / denominator * 100, 2)


def validate(data: object) -> tuple[list[str], list[str], dict]:
    errors: list[str] = []
    warnings: list[str] = []
    summary: dict = {"portals": [], "channels": [], "offline_rates": {}}

    if not isinstance(data, dict):
        return ["JSON root must be an object."], warnings, summary

    report = data.get("report")
    if not isinstance(report, dict):
        errors.append("report must be an object.")
        report = {}
    for field in ("property_address", "report_start", "report_end", "generated_at"):
        if not is_nonempty(report.get(field)):
            errors.append(f"report.{field} is required.")
    if report.get("authorization_confirmed") is not True:
        errors.append("report.authorization_confirmed must be true.")

    listing = data.get("listing")
    if not isinstance(listing, dict):
        errors.append("listing must be an object.")
        listing = {}
    for field in ("status", "source_url", "verified_at"):
        if not is_nonempty(listing.get(field)):
            errors.append(f"listing.{field} is required.")

    portals = data.get("portals")
    if not isinstance(portals, list) or not portals:
        errors.append("portals must be a non-empty list.")
        portals = []

    for index, portal in enumerate(portals):
        label = f"portals[{index}]"
        if not isinstance(portal, dict):
            errors.append(f"{label} must be an object.")
            continue
        for field in ("name", "observed_at"):
            if not is_nonempty(portal.get(field)):
                errors.append(f"{label}.{field} is required.")
        if portal.get("metric_scope") not in SCOPES:
            errors.append(f"{label}.metric_scope must be one of {sorted(SCOPES)}.")
        if portal.get("access") not in ACCESS:
            errors.append(f"{label}.access must be one of {sorted(ACCESS)}.")

        metrics = portal.get("metrics")
        if not isinstance(metrics, dict):
            errors.append(f"{label}.metrics must be an object.")
            continue

        nonnull = 0
        for metric in METRICS:
            value = metrics.get(metric)
            if value is not None:
                nonnull += 1
                if isinstance(value, bool) or not isinstance(value, (int, float)) or value < 0:
                    errors.append(f"{label}.metrics.{metric} must be null or a non-negative number.")

        evidence = portal.get("evidence")
        if nonnull and (not isinstance(evidence, list) or not evidence):
            errors.append(f"{label}.evidence is required when metrics are reported.")
        if metrics.get("saves") is not None and metrics.get("favorites") is not None:
            warnings.append(f"{label} reports saves and favorites; do not combine them without proof they are distinct.")
        if portal.get("metric_scope") == "unknown" and nonnull:
            warnings.append(f"{label} has metrics with an unknown reporting scope.")

        views = metrics.get("views")
        consideration = metrics.get("saves")
        if consideration is None:
            consideration = metrics.get("favorites")
        contacts = metrics.get("inquiries")
        if contacts is None:
            contacts = metrics.get("leads")
        summary["portals"].append(
            {
                "name": portal.get("name"),
                "save_or_favorite_rate": rate(consideration, views),
                "inquiry_or_lead_rate": rate(contacts, views),
            }
        )

    channels = data.get("channels", [])
    if not isinstance(channels, list):
        errors.append("channels must be a list.")
        channels = []
    for index, channel in enumerate(channels):
        label = f"channels[{index}]"
        if not isinstance(channel, dict):
            errors.append(f"{label} must be an object.")
            continue
        for field in ("name", "observed_at"):
            if not is_nonempty(channel.get(field)):
                errors.append(f"{label}.{field} is required.")
        if channel.get("metric_scope") not in SCOPES:
            errors.append(f"{label}.metric_scope must be one of {sorted(SCOPES)}.")
        if channel.get("access") not in ACCESS:
            errors.append(f"{label}.access must be one of {sorted(ACCESS)}.")
        metrics = channel.get("metrics")
        if not isinstance(metrics, dict):
            errors.append(f"{label}.metrics must be an object.")
            continue
        nonnull = 0
        for metric in CHANNEL_METRICS:
            value = metrics.get(metric)
            if value is not None:
                nonnull += 1
                if isinstance(value, bool) or not isinstance(value, (int, float)) or value < 0:
                    errors.append(f"{label}.metrics.{metric} must be null or a non-negative number.")
        evidence = channel.get("evidence")
        if nonnull and (not isinstance(evidence, list) or not evidence):
            errors.append(f"{label}.evidence is required when metrics are reported.")
        if channel.get("metric_scope") == "unknown" and nonnull:
            warnings.append(f"{label} has metrics with an unknown reporting scope.")
        summary["channels"].append(
            {
                "name": channel.get("name"),
                "click_through_rate": rate(metrics.get("clicks"), metrics.get("impressions")),
                "click_to_reach_rate": rate(metrics.get("clicks"), metrics.get("reach")),
            }
        )

    actions = data.get("marketing_actions")
    if not isinstance(actions, list):
        errors.append("marketing_actions must be a list.")
    else:
        for index, action in enumerate(actions):
            label = f"marketing_actions[{index}]"
            if not isinstance(action, dict):
                errors.append(f"{label} must be an object.")
                continue
            for field in ("channel", "action", "date", "evidence"):
                if not is_nonempty(action.get(field)):
                    errors.append(f"{label}.{field} is required for a completed action.")

    offline = data.get("offline", {})
    if not isinstance(offline, dict):
        errors.append("offline must be an object.")
        offline = {}
    for field in ("qualified_leads", "showings", "feedback_count", "open_house_visitors", "offers"):
        value = offline.get(field)
        if value is not None and (
            isinstance(value, bool) or not isinstance(value, (int, float)) or value < 0
        ):
            errors.append(f"offline.{field} must be null or a non-negative number.")
    summary["offline_rates"] = {
        "lead_to_showing_rate": rate(offline.get("showings"), offline.get("qualified_leads")),
        "feedback_response_rate": rate(offline.get("feedback_count"), offline.get("showings")),
        "showing_to_offer_rate": rate(offline.get("offers"), offline.get("showings")),
    }

    return errors, warnings, summary


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: validate_report_data.py <report-data.json>", file=sys.stderr)
        return 2

    path = Path(sys.argv[1])
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2

    errors, warnings, summary = validate(data)
    if errors:
        print("INVALID REPORT DATA")
        for error in errors:
            print(f"- ERROR: {error}")
        for warning in warnings:
            print(f"- WARNING: {warning}")
        return 1

    print("VALID REPORT DATA")
    for warning in warnings:
        print(f"- WARNING: {warning}")
    print(json.dumps(summary, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
