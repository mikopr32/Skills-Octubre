# Módulo de método

Aplicar únicamente dentro de los límites del controlador SKILL.md del owner.

# Seller Listing Marketing Report

Produce an evidence-backed seller update that demonstrates distribution, marketing execution, buyer engagement, and the next decision. Never confuse activity with outcome or manufacture unavailable portal metrics.

## Select the operating mode

Choose one:

1. **Public visibility audit:** verify public listing presence, presentation, status, syndication, links, and publicly displayed metrics.
2. **Authorized performance report:** collect metrics from agent, owner, MLS, advertising, CRM, or portal dashboards through authorized access.
3. **Evidence-assisted report:** extract metrics from user-provided screenshots, PDFs, CSVs, emails, or dashboard exports.
4. **Periodic update:** compare the current reporting window with a prior verified window.
5. **Quality audit:** evaluate an existing seller report for evidence, clarity, and decision value.

Combine modes when useful. Default to public visibility plus evidence-assisted reporting. Do not log into any account without explicit authorization.

## Establish scope

Confirm or infer:

- property address and optional MLS number;
- that the user or their brokerage represents the listing;
- reporting period and report date;
- language and desired output format;
- portal URLs or known syndication targets;
- available MLS, dashboard, advertising, CRM, showing, and open-house evidence;
- prior report or baseline, if trend analysis is requested;
- agent, brokerage, and seller-facing branding details.

Ask one grouped question only when missing information prevents correct property resolution, access, or reporting-period comparisons. A property address or verified listing URL is the minimum input.

## Build the evidence ledger

Read [references/evidence-and-research.md](references/evidence-and-research.md).

For every source record:

- source or portal;
- exact URL, dashboard, export, or supplied artifact;
- public, authorized dashboard, or user-provided access class;
- observation timestamp;
- metric scope: reporting period, cumulative, rolling window, or unknown;
- exact metric label and value;
- evidence location;
- limitation or access failure.

Use `null` or **Not available** when a metric is unavailable. Use zero only when the source explicitly reports zero. Do not infer views, saves, leads, or distribution from search snippets alone.

## Resolve and audit the listing

Verify that each result refers to the same property and active listing. Compare:

- address and unit;
- MLS number and source;
- listing status;
- current and original price;
- list date and days on market;
- beds, baths, square footage, property type;
- listing agent and brokerage;
- photo count and ordering;
- description, headline, features, virtual tour, video, floor plan, 3D tour;
- open-house information;
- price/status history;
- duplicate, stale, off-market, or conflicting records.

Do not count an off-market property page, duplicate record, old MLS entry, or scraped summary as active syndication.

## Collect portal metrics correctly

Read [references/portal-metrics-and-access.md](references/portal-metrics-and-access.md).

Collect only metrics displayed by the source or supplied in evidence. Common examples include:

- Zillow: views and saves when visible;
- Realtor.com: listing views and inquiries through seller/performance reporting;
- Redfin: views and favorites through an eligible owner or agent dashboard;
- Homes.com: views, engagement, favorites/saves, and leads when available in the applicable analytics product;
- MLS: client views, favorites, rejects, reverse-prospecting, syndication, or activity when the local MLS exposes them;
- paid/social/owned channels: impressions, reach, clicks, video views, landing sessions, leads, email delivery/opens, and direct inquiries.

Treat portal labels as source-specific. Do not rename favorites as likes unless the report explains the mapping. Never add cross-portal views into a “unique buyers” total.

## Inventory marketing execution

Separate **verified completed actions**, **scheduled actions**, and **recommended actions**.

Audit, when relevant:

- MLS activation and syndication;
- professional photography, drone, twilight, floor plan, 3D or video;
- single-property or brokerage page;
- portal enhancements or boosts;
- social organic posts and video;
- paid advertising;
- database email and agent-to-agent outreach;
- reverse prospecting or broker network distribution;
- open house, broker open, signage, print, and neighbor outreach;
- lead response, showing follow-up, and feedback collection.

Require evidence for completed-action claims. A plan is not proof of execution.

## Normalize and calculate

Store the evidence in the structure defined by [assets/report-input-template.json](assets/report-input-template.json). Run:

```bash
python3 scripts/validate_report_data.py <report-data.json>
```

Read [references/metrics-and-diagnostics.md](references/metrics-and-diagnostics.md) before calculating or interpreting:

- views per day;
- save/favorite rate;
- inquiry rate;
- lead-to-showing rate;
- showing-to-offer rate;
- period-over-period change;
- portal coverage ratio;
- evidence coverage ratio.

Calculate a rate only when numerator, denominator, scope, and period are compatible. Keep cumulative metrics separate from reporting-period metrics.

## Diagnose the response funnel

Use this sequence:

`distribution → listing views → saves/favorites → inquiries/leads → showings → offers`

Distinguish:

- **Exposure:** where and how often the listing is seen.
- **Engagement:** saves, favorites, clicks, shares, inquiries.
- **Intent:** qualified inquiries, showing requests, repeat interest.
- **Conversion:** showings, second showings, offers.
- **Market feedback:** repeated objections involving price, condition, presentation, location, terms, or competition.

Do not claim causation from correlation. High views with weak showings may indicate message, price, presentation, qualification, or market-fit friction; state the evidence needed to discriminate among them.

## Produce the seller-facing report

Read [references/seller-report-spec.md](references/seller-report-spec.md) and use [assets/seller-report-template.md](assets/seller-report-template.md).

Include:

1. executive summary;
2. property and reporting period;
3. verified distribution map;
4. portal performance table;
5. marketing completed;
6. engagement and conversion funnel;
7. trend versus prior period, when comparable;
8. buyer/showing feedback themes;
9. what the data means;
10. actions for the next reporting window;
11. evidence notes and limitations.

Lead with what was done, what buyers did, and what decision follows. Use calm, accountable language. Do not hide weak performance or blame the seller.

When requested, create a polished DOCX and/or PDF using the available document capability. Keep the editable source and render the final file for visual verification. Use separate English and Spanish editions unless the user explicitly requests a bilingual report.

## Recommend the next action

Give no more than five prioritized actions. For each include:

- action;
- evidence or hypothesis;
- owner;
- deadline;
- KPI;
- decision rule.

Route a full relaunch, pricing strategy, CMA, or content rebuild to the most specific available capability. Do not expand this report into an unsupported valuation.

## Quality gate

Read [references/quality-and-compliance.md](references/quality-and-compliance.md). Do not deliver below 90/100.

Critical failures:

- wrong property or stale listing;
- fabricated or unsourced metrics;
- public and private metrics presented as equivalent;
- cumulative and period metrics mixed;
- views represented as unique buyers;
- duplicated portal traffic summed without warning;
- marketing claimed without evidence;
- seller-identifying or lead data exposed unnecessarily;
- recommendation disconnected from the observed funnel;
- polished report with missing limitations.
