# Reporte de marketing de la propiedad

**Propiedad:** [DIRECCIÓN]  
**MLS:** [MLS]  
**Periodo:** [FECHA INICIO] – [FECHA FIN]  
**Preparado para:** [SELLER]  
**Preparado por:** [AGENTE · BROKERAGE]  

## Resumen ejecutivo

[QUÉ SE VERIFICÓ]

[QUÉ HICIERON LOS COMPRADORES]

[PRÓXIMA DECISIÓN RECOMENDADA]

## Estado del listing

| Campo | Resultado |
|---|---|
| Status | [STATUS] |
| Precio actual | [PRECIO] |
| Precio original | [PRECIO ORIGINAL] |
| Days on market | [DOM] |
| Fecha de verificación | [TIMESTAMP] |

## Distribución y visibilidad

| Portal/canal | Presencia | Presentación | URL | Verificado |
|---|---|---|---|---|
| [PORTAL] | [ESTADO] | [RESULTADO] | [URL] | [FECHA] |

## Actividad digital verificada

| Fuente | Alcance temporal | Views | Saves/Favorites | Inquiries/Leads | Evidencia |
|---|---|---:|---:|---:|---|
| [FUENTE] | [PERIODO] | [VALOR] | [VALOR] | [VALOR] | [ESTADO] |

> Las métricas pertenecen a cada fuente y pueden incluir visitas repetidas. No representan compradores únicos ni deben sumarse entre portales sin una metodología de deduplicación.

## Rendimiento de campañas y canales propios

| Canal | Periodo | Impressions/Reach | Clicks/Video views | Leads | Evidencia |
|---|---|---:|---:|---:|---|
| [CANAL] | [PERIODO] | [VALOR] | [VALOR] | [VALOR] | [ESTADO] |

## Marketing completado

- [ACCIÓN + FECHA + EVIDENCIA]

## Respuesta del mercado

| Etapa | Resultado |
|---|---:|
| Views | [POR FUENTE] |
| Saves/Favorites | [POR FUENTE] |
| Inquiries/Leads | [VALOR] |
| Showings | [VALOR] |
| Offers | [VALOR] |

## Tendencia

[COMPARACIÓN COMPATIBLE CON PERIODO ANTERIOR O “SIN BASELINE COMPARABLE”]

## Feedback recibido

- [TEMA VERIFICADO]

## Interpretación

**Señal más fuerte:** [SEÑAL]  
**Bottleneck principal:** [BOTTLENECK]  
**Confianza:** [ALTA/MEDIA/BAJA + RAZÓN]  

## Próximos pasos

| Prioridad | Acción | Owner | Fecha | KPI | Regla de decisión |
|---:|---|---|---|---|---|
| 1 | [ACCIÓN] | [OWNER] | [FECHA] | [KPI] | [REGLA] |

## Evidencia y limitaciones

- [FUENTE, TIMESTAMP Y LIMITACIÓN]
