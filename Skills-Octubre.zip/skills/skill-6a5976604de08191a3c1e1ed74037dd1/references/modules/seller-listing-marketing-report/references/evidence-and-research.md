# Evidence and Research Protocol

## Contents

1. Property resolution
2. Search sequence
3. Evidence ledger
4. Duplicate control
5. Research stop conditions

## Property resolution

Start with the exact address and, when available, MLS number. Confirm at least three matching identifiers before merging evidence:

- normalized street address and unit;
- city, state, and ZIP;
- MLS number;
- current price;
- listing agent or brokerage;
- property facts or photo set.

Flag rather than merge records when identifiers conflict.

## Search sequence

1. Open the supplied listing or MLS URL.
2. Search the exact quoted address.
3. Search the address plus MLS number.
4. Search each priority portal by domain.
5. Verify the active listing status and source.
6. Capture public presentation and metrics.
7. Use authorized dashboards or supplied evidence only when needed.
8. Inspect brokerage, IDX, social, ad, email, and CRM evidence if included in scope.

Do not infer syndication merely because a search engine returns a result. Open the record and verify that it is active and current.

## Evidence ledger

For every source preserve:

| Field | Requirement |
|---|---|
| Source | Portal, MLS, dashboard, file, ad account, CRM, or marketing channel |
| Location | Direct URL or artifact filename/page |
| Access | Public, authorized dashboard, or user-provided |
| Observed at | Timestamp with timezone |
| Listing identity | Address/MLS match notes |
| Metric period | Exact window or unknown |
| Values | Exact source labels and values |
| Evidence | Screenshot, export, page text, or dashboard location |
| Limitation | Access, definition, duplication, or freshness issue |

When a screenshot is the evidence, inspect it visually and record the visible date range. Do not rely only on OCR.

## Duplicate control

Expect:

- Zillow and Trulia network overlap;
- IDX sites reproducing the same MLS feed;
- old and current MLS records;
- multiple units or similar street addresses;
- cumulative portal metrics observed on different dates;
- paid and organic events touching the same person.

Report portal-level activity separately. If presenting a distribution count, count verified destinations, not duplicated listings or search results.

## Research stop conditions

Stop and report the limitation when:

- the property cannot be resolved confidently;
- the user is not authorized to access the listing or dashboard;
- a login, MFA, or permission wall requires user action;
- the portal blocks access;
- the metric definition or reporting period cannot be established;
- the evidence contains private lead information not required for the report.

Continue with available evidence and state what would improve confidence.
