# Seller Report Specification

## Contents

1. Communication principles
2. Required sections
3. Visual hierarchy
4. Language
5. Delivery formats

## Communication principles

- Demonstrate activity with evidence, not volume of jargon.
- Explain what the metric means and what it does not mean.
- Separate agent-controlled execution from market response.
- Show weak signals honestly.
- Lead to a decision for the next reporting period.
- Avoid defensive language and seller blame.

## Required sections

### 1. Executive summary

Use three short statements:

- what marketing and distribution were verified;
- what buyer activity occurred;
- what the recommended next move is.

### 2. Property snapshot

Include address, MLS number, status, current/original price, DOM, report period, and generated date.

### 3. Distribution and visibility

Show each portal with:

- active status;
- URL;
- listing identity/status accuracy;
- presentation completeness;
- observation date;
- limitation.

### 4. Portal performance

Use exact source-native metrics:

| Portal/source | Period | Views | Saves/favorites | Inquiries/leads | Evidence status |
|---|---|---:|---:|---:|---|

Do not force unavailable fields into zeros.

### 5. Marketing completed

Group by:

- MLS/portal;
- visual assets;
- owned digital;
- social;
- paid media;
- database/agent network;
- open house/offline;
- follow-up.

Show paid and owned channel metrics separately from portal activity:

| Channel | Period | Impressions/reach | Clicks/video views | Leads | Evidence status |
|---|---|---:|---:|---:|---|

### 6. Response funnel

Show:

`views → saves/favorites → inquiries → showings → offers`

Use separate lines per source when the traffic cannot be deduplicated.

### 7. Trend

Compare with a prior period only when the scope is compatible. Use an arrow or concise table and explain material changes.

### 8. Feedback

Summarize recurring themes without identifying buyers or agents unnecessarily. Distinguish direct feedback from interpretation.

### 9. Interpretation

State:

- strongest signal;
- primary bottleneck;
- confidence level;
- evidence still needed.

### 10. Next actions

Limit to five. Include owner, date, KPI, and decision rule.

### 11. Evidence and limitations

List source links, dashboard/export references, observation times, inaccessible portals, and metric-definition warnings.

## Visual hierarchy

- Use a restrained professional cover.
- Put the executive summary and core metrics before detailed evidence.
- Use green only for verified positive movement, amber for attention, and red only for a confirmed critical issue.
- Avoid decorative charts without comparable time-series data.
- Use a table for exact portal metrics.
- Use one funnel visual only when all stages are populated or clearly marked unavailable.

## Language

Use plain seller-facing language:

- “The listing was viewed 1,240 times on Zillow during the observed scope.”
- “These views are activity signals and may include repeat visits.”
- “Redfin favorites increased compared with the prior verified snapshot.”

Avoid:

- “1,240 buyers saw the home.”
- “The marketing is working perfectly.”
- “The seller must reduce the price.”

## Delivery formats

- Markdown: working report and audit trail.
- DOCX: editable client-facing report.
- PDF: presentation-ready final.
- Separate Spanish and English versions by default when both are requested.
- Include an appendix only when the evidence would clutter the main seller narrative.
