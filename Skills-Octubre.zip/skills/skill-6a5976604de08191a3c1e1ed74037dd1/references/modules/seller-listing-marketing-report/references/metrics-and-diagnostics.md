# Metrics and Diagnostics

## Contents

1. Metric rules
2. Calculations
3. Funnel diagnosis
4. Trend logic
5. Decision framework

## Metric rules

- Use the source's exact period.
- Separate cumulative, rolling, and reporting-period metrics.
- Treat unavailable as null, never zero.
- Do not add views across portals and label them unique.
- Do not compare portals as if they use the same counting rules.
- Prefer within-source trends over cross-source rankings.
- Label views as activity, not buyer identity or purchase intent.

## Calculations

Calculate only from compatible values:

`views_per_day = views_in_period ÷ days_in_period`

`save_rate = saves_or_favorites ÷ views × 100`

`inquiry_rate = inquiries ÷ views × 100`

`click_through_rate = clicks ÷ impressions × 100`

`click_to_reach_rate = clicks ÷ reach × 100`

`lead_to_showing_rate = showings ÷ qualified_leads × 100`

`feedback_response_rate = feedback_count ÷ showings × 100`

`showing_to_offer_rate = offers ÷ showings × 100`

`period_change = (current - prior) ÷ prior × 100`

`portal_coverage = verified_active_portals ÷ portals_checked × 100`

`evidence_coverage = metrics_with_evidence ÷ metrics_reported × 100`

Do not calculate change when the prior value is zero. State the absolute difference instead.

## Funnel diagnosis

| Pattern | Possible explanation | Evidence needed |
|---|---|---|
| Missing portal presence | Feed, status, mapping, or duplicate issue | MLS syndication settings and portal record |
| Strong views, weak saves | Price, presentation, features, competition, or casual traffic | Comparable engagement, feedback, media audit |
| Strong saves, weak inquiries | Buyer hesitation, financing, disclosures, CTA, or price expectation | Inquiry path test and showing feedback |
| Inquiries, weak showings | Lead quality, response time, qualification, access, or scheduling | CRM response logs and showing requests |
| Showings, no offers | Price-to-condition gap, objection pattern, terms, or competition | Showing feedback and current comparables |
| Falling view velocity | Listing aging, reduced search placement, seasonality, or market shift | Same-source weekly trend and market context |

Present these as hypotheses until supporting evidence exists.

## Trend logic

Compare only:

- the same portal;
- the same metric label;
- compatible periods;
- the same listing record;
- a documented observation cadence.

For cumulative counts, derive period activity only from two verified snapshots:

`period_value = ending_cumulative - starting_cumulative`

Flag resets, relists, duplicate records, and source-definition changes.

## Decision framework

Prioritize the first measurable bottleneck:

1. Distribution problem: correct feeds and listing identity.
2. Presentation problem: improve media, description, ordering, tour, or facts.
3. Engagement problem: test price-positioning, message, or offer.
4. Inquiry problem: test CTA, contact path, response speed, and qualification.
5. Showing problem: address access, scheduling, condition, or buyer objections.
6. Offer problem: reconcile price, terms, condition, and competition through a separate pricing/relaunch analysis.

Attach one KPI and decision rule to every next action.
