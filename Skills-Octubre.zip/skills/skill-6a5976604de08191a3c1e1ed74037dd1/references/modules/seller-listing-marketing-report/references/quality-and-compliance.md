# Quality and Compliance

## Quality score

Score 100 points:

| Dimension | Points |
|---|---:|
| Property and listing identity | 15 |
| Source and evidence integrity | 20 |
| Portal coverage and presentation audit | 15 |
| Metric normalization and calculations | 15 |
| Marketing execution evidence | 10 |
| Funnel diagnosis | 10 |
| Seller communication and next actions | 10 |
| Privacy, Fair Housing, and limitations | 5 |

Do not deliver below 90.

## Critical failures

Reject or correct the report regardless of score when it:

- analyzes the wrong property;
- reports a stale record as active;
- fabricates a metric, source, action, or trend;
- uses zero for unavailable data;
- combines cross-portal views as unique reach;
- mixes cumulative and period metrics;
- exposes lead identities or contact details;
- makes a Fair Housing-sensitive recommendation;
- presents a pricing conclusion without appropriate market evidence;
- omits a material access or evidence limitation.

## Privacy

- Include aggregated activity in the seller report.
- Exclude names, emails, phone numbers, messages, and protected or sensitive buyer information unless necessary and authorized.
- Redact screenshots before delivery when they contain private lead data.
- Do not reuse seller, buyer, or agent credentials.

## Fair Housing and advertising

- Audit listing language and targeting for protected-class references or proxies when relevant.
- Keep observations objective and property-focused.
- Do not recommend selective marketing based on race, color, national origin, religion, sex, familial status, disability, or other protected classes.
- Treat platform, MLS, brokerage, and legal requirements as separate layers.

## Final checklist

- [ ] Property and active listing verified.
- [ ] Reporting period stated.
- [ ] Every metric has source, scope, and timestamp.
- [ ] Unavailable metrics remain null or labeled unavailable.
- [ ] Portal overlap and repeat visits are disclosed.
- [ ] Completed marketing has evidence.
- [ ] Trends use compatible snapshots.
- [ ] Recommendations follow the observed funnel.
- [ ] Private information is removed.
- [ ] Report scores at least 90/100.
