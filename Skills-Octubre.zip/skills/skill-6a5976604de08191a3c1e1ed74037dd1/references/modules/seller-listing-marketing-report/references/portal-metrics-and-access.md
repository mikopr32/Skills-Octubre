# Portal Metrics and Access

## Contents

1. Source matrix
2. Access rules
3. Metric normalization
4. Availability failures
5. Verification cadence

## Source matrix

Treat this matrix as routing guidance, not a guarantee that an interface or metric remains available.

| Source | Commonly available evidence | Typical access | Reporting rule |
|---|---|---|---|
| Zillow | Listing status, facts, media, Time on Zillow, views, saves when displayed | Public listing; owner/agent tools may add data | Capture the exact labels, timestamp, and whether counts are cumulative |
| Realtor.com | Listing presentation and days on site; listing views and inquiries in seller/performance reports | Public page plus professional dashboard | Use dashboard/export evidence for performance values |
| Redfin | Listing presentation; views and favorites in eligible owner/agent dashboard | Public page plus claimed listing/dashboard | Do not imply dashboard access from the public page |
| Homes.com | Listing presentation; views, engagement, favorites/saves, and leads in applicable analytics products | Public page plus account/product dashboard | State product/access limitations |
| Local MLS | Listing facts, distribution, client activity, reverse prospecting, favorites/rejects, reports | Authorized MLS access or user export | Preserve the MLS metric names and reporting window |
| Brokerage/IDX | Sessions, detail views, registrations, inquiries | Authorized analytics/dashboard | Distinguish sessions, users, and listing-detail events |
| Meta/Google | Impressions, reach, clicks, video engagement, conversions, spend | Authorized ad account or export | Attribute only to the documented campaign and period |
| Social organic | Reach, plays, engagement, clicks, shares | Authorized account or screenshots | Separate platform engagement from listing-portal activity |
| Email/CRM | Sends, delivery, opens, clicks, replies, leads, appointments | Authorized system or export | Respect consent and avoid exposing lead identities |

As of July 2026, Zillow describes Time on Zillow, Views, and Saves as interest signals on listing pages. Realtor.com documents Home Seller Reports with views and inquiries. Redfin has documented views and favorites in its Owner/Agent Dashboard. Homes.com advertises analytics covering views, engagement, and leads. Reverify current interfaces before giving click-by-click instructions.

## Access rules

- Use public pages without authentication when permitted.
- Use a browser session only when the user explicitly authorizes account access.
- Never request passwords, MFA codes, API keys, or tokens in chat.
- Allow the user to complete login and MFA directly.
- Do not change a listing, ad, profile, report setting, or account configuration during a read-only reporting task.
- If a portal blocks automation, use user-provided screenshots or exports.
- Follow applicable portal terms and rate limits. Do not bypass bot protection or access restrictions.

## Metric normalization

Preserve source-native terms:

- `views`
- `saves`
- `favorites`
- `likes`
- `shares`
- `inquiries`
- `leads`
- `showing requests`

Map terms only in a separate normalized category:

| Native metric | Normalized category |
|---|---|
| Saves, favorites | Consideration signal |
| Likes | Engagement signal |
| Inquiries, leads | Contact signal |
| Showing requests | Intent signal |

Never combine native values that may describe the same behavior.

## Availability failures

Use these statuses:

- **Verified:** value and scope captured from a reliable source.
- **Visible, no metric:** listing is present but the requested engagement value is not displayed.
- **Login required:** metric may exist behind authorized access.
- **Product dependent:** metric requires a portal product, account tier, claim, or dashboard.
- **Blocked:** access denied, bot challenge, or technical failure.
- **Not found:** no matching active listing located after reasonable verification.
- **Conflict:** multiple records disagree and require resolution.

Do not convert any of these statuses to zero.

## Verification cadence

- Capture a timestamp for every observation.
- For weekly reporting, use the same weekday and approximate time.
- Preserve prior snapshots for valid trend analysis.
- Reverify portal features, metric definitions, and access paths when producing instructions.
