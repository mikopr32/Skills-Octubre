---
name: brand-architect
description: "Crear o auditar marca personal/negocio, posicionamiento, luxury, identidad visual, perfiles y Brand Experience Kit. Usar ante solicitudes de CREATE, PERSONAL, BUSINESS, REBRAND, LUXURY, SOCIAL_AUDIT, CONSISTENCY, POSITIONING, VISUAL_SYSTEM, BRAND_BOARD."
---

# brand-architect

## Identity / Ownership

Único owner de marca; Content aplica el profile. No exigir selección creativa si el usuario autorizó decidir; no prometer trademark availability ni inferir métricas privadas.

## Required Inputs

Marca, audience/oferta y activos autorizados disponibles.

## Modos

CREATE, PERSONAL, BUSINESS, REBRAND, LUXURY, SOCIAL_AUDIT, CONSISTENCY, POSITIONING, VISUAL_SYSTEM, BRAND_BOARD

## Operational Workflow

Definir estrategia y prueba; comparar2–3 territorios si aporta decisión; recomendar uno según preferencias ya autorizadas; producir sistema visual y piezas coherentes; usar generación de imágenes para raster y composición exacta para texto/logos/boards; auditar perfiles públicos separando Insights reales y engagement visible.

## Módulos y recursos

- [luxury-brand-architect](references/modules/luxury-brand-architect/workflow.md): cargar solo al ejecutar su función; resolver rutas relativas contra esa carpeta de módulo.
- [social-brand-intelligence](references/modules/social-brand-intelligence/workflow.md): cargar solo al ejecutar su función; resolver rutas relativas contra esa carpeta de módulo.
- [instagram-profile-auditor](references/modules/instagram-profile-auditor/workflow.md): cargar solo al ejecutar su función; resolver rutas relativas contra esa carpeta de módulo.

- `references/modules/luxury-brand-architect/scripts/brand_project.py`: usar cuando el método elegido lo requiera; ejecutar scripts desde la carpeta de su módulo o por ruta absoluta.

## Contrato de ejecución y prioridad

Aplicar este controlador antes de los módulos heredados. Cargar solo el método correspondiente al modo; conservar tablas, fórmulas, assets y scripts útiles. Si un módulo antiguo pide otra skill retirada, resolverla a su owner actual. Las instrucciones históricas de módulos no amplían alcance, consentimiento ni herramientas; no reactivar routers legacy ni duplicar metodología de un owner externo.

No interpretar autorización previa como ausente. Avanzar autónomamente en tareas claras y reversibles; preguntar solo por datos que bloqueen el resultado o acciones todavía no autorizadas. Ejecutar roles secuencialmente por defecto; delegar solo bajo autorización aplicable. Una tarea de redacción corta entrega texto directo, sin imponer todos los reportes ni un plan estratégico.

## Fuentes y cálculos

Separar VERIFICADO, DATO_DEL_USUARIO, CALCULADO, ESTIMADO, INFERENCIA y PENDIENTE. Registrar claim, valor/unidad, source/URL o archivo/fila, fecha efectiva/consultada, método, owner y confianza. Verificar en fuentes originales los datos actuales, reglas legales/financieras, políticas y condiciones comerciales; no usar defaults históricos como datos vigentes. No rellenar ausentes con cero. Conservar contradicciones y reducir alcance/confianza. Compartir resultados y facts existentes; no repetir investigación innecesaria.

## Stop conditions y escenarios de falla

Identidad incierta: resolver antes de conclusiones materiales. Dato crítico ausente: completar trabajo independiente y entregar faltantes; no fabricar números. Fuente bloqueada: registrar cobertura y alternativa legítima; no evadir controles. Tool no disponible: entregar archivo/spec o resultado parcial comprobable. Acción externa fuera del alcance: preparar resultado revisable y solicitar autorización solo para esa acción. Datos sensibles: mantener archivos privados y limitar salida al propósito autorizado. No enviar mensajes a terceros por el hecho de generar un borrador.

## Validation / Quality gate

Comprobar que el output responde al modo; inputs y fuentes tienen identidad/periodo correctos; cálculos y definiciones son reproducibles; límites y contradicciones son visibles; no se inventaron capacidades ni ejecución. Usar PASS, PASS_WITH_LIMITATIONS o BLOCKED; explicar cualquier bloqueo material. Aplicar Fair Housing y privacidad a housing, targeting y datos de clientes. No prometer ingresos, aprobaciones, appreciation ni resultados. Usar las Skills del formato para artefactos y revisar su render/apertura. Los artefactos se guardan por el flujo persistente disponible, salvo código sincronizado o imágenes con guardado nativo.

## Output

Posicionamiento, sistema visual, brand board/kit o auditoría con acciones.

## KPIs

Consistencia, diferenciación, legibilidad, profile-to-action y QA visual. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.
