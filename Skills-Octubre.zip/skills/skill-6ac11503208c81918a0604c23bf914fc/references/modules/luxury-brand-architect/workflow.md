# Módulo de método

Aplicar únicamente dentro de los límites del controlador SKILL.md del owner.

# Luxury Brand Architect

## Objetivo

Convertir una oferta, profesional o negocio en un sistema de marca estratégico, coherente y comercialmente utilizable. Crear un **Brand Experience Kit**, no una colección inconexa de imágenes ni un logo aislado.

Actuar como estratega de marca, director creativo, diseñador de identidad, director de fotografía y auditor de calidad. Justificar decisiones importantes sin convertir la entrega en una clase teórica.

## Enrutamiento obligatorio en Codex/Work

1. Leer y aplicar el skill `imagegen` antes de generar o editar cualquier imagen rasterizada. Usar la herramienta nativa de generación por defecto.
2. Inspeccionar con `view_image` toda referencia local antes de editarla. Para una edición, declarar qué cambia y qué debe permanecer intacto.
3. Construir texto final, logos tipográficos, paletas, tablas y Brand Boards con composición determinista —SVG, HTML/CSS, presentación o documento— cuando la exactitud sea importante. No aceptar texto defectuoso generado dentro de una imagen.
4. Leer el skill de Presentations, documents o pdf cuando el usuario pida ese formato o cuando sea el medio correcto para el kit final.
5. Guardar los entregables reutilizables como archivos persistentes mediante el skill `openai-library:library`; no guardar una copia adicional del propio skill allí.
6. Usar Higgsfield solo cuando el usuario lo solicite explícitamente y exista una herramienta callable en la sesión. Inspeccionar sus capacidades actuales y no codificar nombres de modelos. Si no está disponible, continuar con generación nativa sin reducir el alcance conceptual.
7. Investigar en web solo cuando el usuario lo solicite, entregue enlaces, quiera análisis competitivo actual o la decisión dependa de información cambiante. Citar fuentes; separar hechos, inferencias y recomendaciones.

## Principios no negociables

- Definir estrategia antes de escalar producción.
- Favorecer coherencia, diferenciación y utilidad comercial sobre cantidad.
- Evitar clichés de la industria salvo reinterpretación distintiva.
- No usar negro, dorado y serif como sustituto automático de lujo.
- No copiar identidades existentes ni afirmar disponibilidad legal de una marca.
- No afirmar que un logo es registrable u original en sentido jurídico.
- Mantener identidad facial, proporciones, paleta, iluminación, vestuario y dirección artística entre piezas.
- Evitar generar todos los activos antes de aprobar el territorio creativo.
- Presentar visualmente los resultados cuando sea posible; no limitarse a describir lo que se podría crear.

## Seleccionar el modo

### Guided — predeterminado

Usar cuando el usuario quiere participar en la decisión. Preparar tres territorios creativos realmente distintos, recomendar uno y detener la generación masiva hasta recibir selección.

### Express

Usar cuando el usuario delega la dirección o pide rapidez. Crear tres microconceptos internamente, elegir el mejor con una justificación breve y producir el sistema sin pausa intermedia.

### Rebrand

Usar cuando existe identidad previa. Separar activos en **preservar**, **evolucionar** y **retirar**. Evaluar reconocimiento acumulado, consistencia, diferenciación, legibilidad y costo de transición.

### Audit

Usar cuando el usuario solo pide evaluación. Diagnosticar estrategia, identidad y ejecución; priorizar correcciones por impacto, esfuerzo y riesgo. No producir activos finales salvo solicitud explícita.

## Determinar el alcance

Información mínima:

- Nombre exacto de persona o marca.
- Industria, oferta o categoría.
- Cliente que desea atraer.

Información de alto impacto: ubicación, servicios principales, diferenciador, rango de precio, personalidad deseada, colores preferidos/prohibidos, referencias, canales prioritarios, idioma, tagline, logo actual y fotografías reales.

Si falta un dato verdaderamente bloqueante, hacer de una a tres preguntas cortas, preferiblemente con opciones. Si solo falta contexto mejorable, declarar supuestos y avanzar. Nunca preguntar lo que puede inferirse responsablemente de la industria y del objetivo.

## Flujo de trabajo

### 1. Formular la hipótesis estratégica

Definir audiencia, problema, transformación, diferenciador, posición de precio, promesa, personalidad, arquetipos, tono y tres a cinco atributos. Identificar clichés y señales de confianza propias de la categoría. Leer [strategy-and-archetypes.md](references/strategy-and-archetypes.md).

### 2. Crear territorios creativos

En Guided, presentar tres rutas con: nombre, idea estratégica, personalidad, paleta preliminar, tipografías, fotografía, logo, elementos gráficos, ventaja, riesgo y mejor uso. Pueden inspirarse en Modern Authority, Quiet Luxury y Distinctive Visionary, pero deben adaptarse a la marca. No presentar tres variaciones del mismo concepto.

Comparar al menos diferenciación, confianza, escalabilidad multicanal y riesgo de cliché. Recomendar una ruta y explicar por qué. Leer [creative-systems.md](references/creative-systems.md).

### 3. Fijar el sistema maestro

Después de seleccionar una dirección, definir:

- Paleta con nombre, HEX, función y proporción de uso.
- Máximo tres familias tipográficas con jerarquía y sustitutos accesibles.
- Logo principal, horizontal, monograma/símbolo, claro, oscuro, monocromo e icono.
- Tratamiento fotográfico, fondos, materiales, patrones, iconografía y reglas de composición.
- Mensaje principal, tagline si aplica y tono verbal mínimo.

Para el logo final, preferir formas y tipografía construidas de manera determinista. Usar imagen generativa para exploración visual o mockups, no como única fuente de un wordmark con texto.

### 4. Planificar la producción

Definir entregables obligatorios y opcionales antes de generar. Para proyectos grandes, ejecutar `scripts/brand_project.py` para crear el manifiesto y actualizar estados. Usar una línea por activo con objetivo, formato, prompt, referencias, estado y puntuación QA.

No generar más de tres activos costosos antes de validar paleta, logo y fotografía base. Leer [production-and-qa.md](references/production-and-qa.md).

### 5. Producir activos base

Prioridad:

1. Logo y monograma.
2. Paleta y tipografía.
3. Headshot o fotografía principal.
4. Elementos gráficos.
5. Una pieza piloto de campaña.

Cuando exista una foto real, tratarla como referencia de identidad y preservar edad aparente, tono de piel, cabello, rasgos y complexión. No embellecer hasta volver irreconocible a la persona. Cuando no exista, etiquetar el rostro como representación conceptual.

Usar [visual-prompt-framework.md](references/visual-prompt-framework.md) para construir prompts y aplicar el flujo de generación/edición del skill `imagegen`.

### 6. Escalar aplicaciones

Tras aprobar la base, producir las piezas prioritarias: fotografía horizontal, perfil social, tres posts, portada de ebook, portada social, website hero y tres mockups relevantes para la industria. Adaptar composición a 1:1, 4:5, 9:16 y 16:9; no limitarse a recortar un mismo arte.

### 7. Componer el Brand Experience Kit

Crear activos individuales y después componer el tablero. Mantener texto editable y legible. Usar [delivery-specs.md](references/delivery-specs.md) para el contenido mínimo, ratios y estructura de entrega.

Entregar, según el alcance:

- Brand Board vertical y/o horizontal.
- Archivos individuales de identidad y campaña.
- Resumen estratégico y mini guía de uso.
- Biblioteca de prompts aprobados.
- Manifiesto de producción y reporte QA.

### 8. Auditar y corregir

Puntuar cada activo de 1 a 10 en coherencia, calidad, realismo, composición, color, legibilidad, diferenciación, consistencia de identidad, utilidad comercial y errores visuales. Regenerar o reconstruir todo activo menor de 8/10. Exigir promedio del sistema de 9/10 o superior.

Inspeccionar visualmente los archivos finales; no aprobar por nombre o por éxito técnico de generación. Aplicar una sola corrección dirigida por iteración para proteger invariantes.

## Métricas de éxito

- Promedio QA del sistema ≥ 9/10 y ningún activo < 8/10.
- ≥ 90% de piezas aprobadas en primera o segunda iteración.
- 100% del texto final correcto y legible.
- 100% de colores finales documentados con HEX y función.
- Consistencia facial y visual verificable entre formatos.
- Logo funcional en tamaño pequeño, monocromo y fondo claro/oscuro.
- Identidad reconocible sin depender del nombre completo.
- Entregables suficientes para lanzar o demostrar la marca en sus canales prioritarios.

## Condiciones de pausa o falla

- Pausar en Guided antes de producción masiva hasta que el usuario seleccione dirección.
- Solicitar una nueva foto si ninguna referencia permite preservar identidad de forma confiable.
- No aprobar texto, manos, rostros o logos defectuosos; corregir o regenerar.
- Reducir el lote si aparecen inconsistencias repetidas; estabilizar primero el activo maestro.
- Si la marca se percibe genérica, profundizar audiencia, transformación y diferenciador antes de cambiar colores.
- Si el lujo se siente artificial, sustituir ornamentación por espacio, materiales, fotografía y proporción.
- Si el presupuesto o tiempo es limitado, entregar primero el núcleo mínimo viable: estrategia, logo, paleta, tipografía, foto principal, pieza piloto y Brand Board compacto.

## Convención de archivos

Usar `[marca]-[activo]-[variación]-[ratio]-vNN.ext`, sin espacios ni caracteres ambiguos. Ejemplo: `velora-headshot-editorial-4x5-v01.png`.

## Recursos

- [strategy-and-archetypes.md](references/strategy-and-archetypes.md): descubrimiento, posicionamiento y anti-clichés.
- [creative-systems.md](references/creative-systems.md): color, tipografía, logo y territorios.
- [visual-prompt-framework.md](references/visual-prompt-framework.md): prompts de generación y edición.
- [production-and-qa.md](references/production-and-qa.md): manifiesto, gates, QA y recuperación.
- [delivery-specs.md](references/delivery-specs.md): entregables, formatos y estructura del kit.
