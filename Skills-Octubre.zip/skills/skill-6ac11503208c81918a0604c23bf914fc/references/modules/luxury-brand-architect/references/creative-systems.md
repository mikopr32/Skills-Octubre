# Sistemas creativos

## Índice

1. Territorios
2. Color
3. Tipografía
4. Logo
5. Fotografía y elementos

## 1. Territorios

Cada territorio debe cambiar simultáneamente estrategia, lenguaje visual y experiencia, no solo colores.

| Base | Funciona para | Señales | Riesgo a controlar |
| --- | --- | --- | --- |
| Modern Authority | confianza contemporánea | sans precisa, grilla, contraste | verse corporativa genérica |
| Quiet Luxury | alto valor discreto | espacio, materiales, serif sobria | lujo inaccesible o frío |
| Distinctive Visionary | innovación reconocible | forma propia, ritmo, acento | depender de tendencias |

Renombrar las rutas según la marca y el mercado. Incluir una recomendación inequívoca.

## 2. Color

Definir entre cinco y seis colores:

- dominante oscuro o neutro;
- secundario de autoridad;
- acento premium;
- superficie clara;
- blanco o equivalente;
- color funcional de contraste.

Documentar nombre, HEX, RGB opcional, función y proporción sugerida. Verificar contraste de texto: 4.5:1 para texto normal y 3:1 para texto grande cuando el formato lo permita.

Sistemas de partida, nunca recetas automáticas:

- Executive: carbón, marfil, champagne, gris cálido.
- Modern Professional: azul marino, azul profundo, gris y cobre moderado.
- Organic Premium: bosque, oliva, piedra, terracota y crema.
- Contemporary Feminine: borgoña, ciruela, nude, champagne y marfil.
- Innovative: medianoche, índigo, grafito, plata y un acento frío controlado.

## 3. Tipografía

Seleccionar titular, cuerpo y acento opcional. Priorizar legibilidad, licencia/disponibilidad, soporte lingüístico, pantalla e impresión. Documentar sustitutos seguros. No usar más de tres familias.

Definir al menos:

- H1, H2 y cuerpo;
- pesos permitidos;
- interlineado y tracking orientativos;
- uso de mayúsculas;
- combinación que debe evitarse.

## 4. Logo

Sistema mínimo: principal, horizontal, símbolo/monograma, claro, oscuro, monocromo e icono.

Pruebas obligatorias:

- lectura a 24–32 px;
- una tinta;
- fondo claro y oscuro;
- impresión sin efectos;
- avatar circular;
- separación entre símbolo y wordmark.

Generar conceptos visuales si ayuda, pero reconstruir el logo final con tipografía y geometría exactas. Entregar versión plana además de mockups. No usar un mockup como evidencia de que el logo funciona.

## 5. Fotografía y elementos

Definir:

- encuadre, lente aparente y profundidad;
- luz, temperatura y contraste;
- fondos y materiales;
- vestuario y accesorios;
- expresiones y nivel de formalidad;
- espacio negativo por canal;
- tratamiento de color común.

Crear un elemento propietario repetible: marco, corte, patrón, línea, textura, inicial, forma o gesto compositivo. Debe funcionar aun cuando el logo no aparezca.
