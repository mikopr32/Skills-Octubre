# Especificaciones de entrega

## Índice

1. Kit esencial
2. Kit completo
3. Brand Board
4. Mini guía
5. Entrega en Work

## 1. Kit esencial

Usar cuando hay restricciones de tiempo o presupuesto:

- resumen estratégico;
- logo principal y monograma;
- paleta con HEX y funciones;
- sistema tipográfico;
- fotografía o imagen principal;
- una aplicación piloto;
- Brand Board compacto;
- reglas de uso básicas.

## 2. Kit completo

- estrategia y esencia de marca;
- tres direcciones creativas;
- familia de logos;
- paleta y tipografía;
- headshot formal, approachable y editorial;
- fotografía horizontal, perfil social y portada;
- tres posts: educativo, autoridad y promoción;
- reel cover, story y quote card;
- portada de ebook y arte plano;
- website hero o portada profesional;
- tres mockups relevantes;
- moodboard;
- Brand Board;
- mini guía y prompts aprobados.

Seleccionar opcionales por uso real: YouTube, podcast, webinar, presentación, email, uniforme, vehículo, oficina, empaque o producto digital.

## 3. Brand Board

Contenido mínimo:

1. marca y tagline;
2. posicionamiento en una línea;
3. logo principal, secundario y monograma;
4. paleta con HEX;
5. tipografías y jerarquía;
6. keywords;
7. fotografía y tratamiento;
8. elementos gráficos;
9. dos o tres aplicaciones;
10. reglas visuales esenciales.

Componer con grilla, espacio amplio, texto editable y jerarquía. Crear primero piezas individuales. Entregar vertical para lectura y horizontal si el uso es presentación.

### Patrón editorial de referencia

Cuando el usuario comparta tableros verticales tipo dossier, reinterpretar esta arquitectura:

- hero superior con retrato protagonista, nombre, categoría, tagline y promesa breve;
- paneles numerados del 01 al 10 con bordes discretos y fondo coherente;
- primera fila: foto profesional, paleta y tipografía;
- segunda fila: tres templates sociales y keywords;
- tercera fila: dirección visual, avatar circular y portada horizontal;
- cuarta fila: moodboard, pilares de contenido y reglas de marca;
- cierre con esencia o declaración central.

Mantener la lógica modular y la densidad informativa, pero crear una composición propia para cada marca. No copiar poses, textos, iconos, colores ni proporciones exactas de una referencia. En fondos oscuros, aumentar contraste y tamaño de texto; evitar el defecto frecuente de tableros atractivos pero ilegibles.

## 4. Mini guía

Incluir:

- posicionamiento, audiencia y personalidad;
- archivos y versiones del logo;
- área de seguridad y tamaño mínimo;
- colores y combinaciones aprobadas;
- tipografías, jerarquía y sustitutos;
- dirección fotográfica;
- patrones/iconografía;
- ejemplos correctos e incorrectos;
- adaptación a redes, web e impresión;
- biblioteca de prompts.

## 5. Entrega en Work

- Mostrar previews visuales de los activos importantes.
- Entregar archivos descargables con nombres consistentes.
- Usar PNG/JPG para fotografía y piezas rasterizadas; SVG para marcas vectoriales; PDF/PPTX cuando haya guía o presentación.
- Conservar fondos planos además de mockups.
- Mantener una carpeta lógica: `01-strategy`, `02-identity`, `03-photography`, `04-campaign`, `05-brand-board`, `06-guidelines`.
- Guardar el conjunto final como artefactos persistentes y enlazar los archivos útiles en la respuesta.
