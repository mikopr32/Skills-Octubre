# Estrategia y arquetipos

## Índice

1. Hipótesis de marca
2. Matriz de posicionamiento
3. Arquetipos
4. Señales de confianza
5. Anti-clichés

## 1. Hipótesis de marca

Completar antes de diseñar:

| Campo | Pregunta operativa |
| --- | --- |
| Categoría | ¿En qué mercado mental compite? |
| Audiencia | ¿Quién decide, paga y usa? |
| Dolor | ¿Qué tensión urgente o costosa resuelve? |
| Transformación | ¿Qué cambia después de contratar? |
| Diferenciador | ¿Qué puede defender y demostrar? |
| Precio percibido | ¿Accesible, premium o lujo? |
| Alternativa | ¿Qué haría el cliente sin esta marca? |
| Prueba | ¿Qué reduce riesgo: datos, experiencia, proceso o reputación? |

Redactar el posicionamiento como: “Para [audiencia], [marca] es [categoría] que [resultado] mediante [mecanismo diferenciador], a diferencia de [alternativa].” Tratarlo como hipótesis, no como hecho, cuando el usuario no haya aportado evidencia.

## 2. Matriz de posicionamiento

Evaluar cada dirección de 1 a 5 en:

- autoridad;
- cercanía;
- innovación;
- exclusividad;
- diferenciación;
- facilidad de implementación;
- coherencia con el precio;
- riesgo de confundirse con competidores.

No maximizar todas las variables. Una marca distintiva requiere decisiones y renuncias claras.

## 3. Arquetipos

Usar un arquetipo principal y uno secundario:

| Arquetipo | Señal visual útil | Riesgo |
| --- | --- | --- |
| Gobernante | orden, simetría, materiales sólidos | rigidez o elitismo |
| Sabio | estructura, detalle, evidencia | frialdad o complejidad |
| Creador | composición inesperada, textura | estética sin claridad |
| Héroe | contraste, energía, progreso | agresividad genérica |
| Cuidador | luz cálida, humanidad, calma | poca diferenciación |
| Explorador | espacio, horizonte, movimiento | desconexión del servicio |
| Mago | transformación, luz, profundidad | promesas exageradas |
| Persona común | naturalidad, comunidad | percepción poco premium |

Evitar construir la identidad desde el arquetipo solamente; usarlo como filtro de coherencia.

## 4. Señales de confianza

- Servicios profesionales: precisión, jerarquía, lenguaje sobrio y prueba.
- Salud/bienestar: claridad, calma, humanidad y límites éticos.
- Finanzas/crédito: estabilidad, privacidad, progreso y educación; evitar promesas garantizadas.
- Real estate: conocimiento local, orientación y resultado; evitar techos/llaves genéricos.
- Coaching: método, transformación demostrable y energía; evitar poses motivacionales vacías.
- Belleza: detalle, ritual, textura y resultado; evitar scripts ilegibles y rosa automático.
- Construcción: ingeniería, materiales, ejecución y seguridad; evitar cascos/engranajes genéricos.
- Tecnología: simplicidad, control y velocidad; evitar cerebros, robots y circuitos azules genéricos.

## 5. Anti-clichés

Para cada categoría, listar:

1. tres símbolos saturados;
2. dos combinaciones de color previsibles;
3. una promesa verbal genérica;
4. una oportunidad visual propia de la marca;
5. un elemento reconocible que pueda repetirse sin logo.

Aceptar un cliché solo cuando se transforme en un activo distintivo mediante geometría, narrativa, material o contexto.
