# Framework de prompts visuales

## Índice

1. Esquema maestro
2. Identidad facial
3. Logos y texto
4. Formatos
5. Reglas de iteración

## 1. Esquema maestro

Usar solo los campos relevantes y respetar el esquema del skill `imagegen`:

```text
Use case: [taxonomy slug]
Asset type: [uso exacto]
Primary request: [activo y objetivo]
Input images: [imagen + rol: referencia o edición]
Brand: [nombre, categoría, audiencia]
Positioning: [promesa y diferenciador]
Visual identity: [territorio, personalidad, arquetipos]
Subject: [persona, producto u objeto]
Scene/backdrop: [ambiente]
Style/medium: [fotografía, ilustración, mockup]
Composition/framing: [ratio, ubicación, espacio negativo]
Lighting/mood: [luz y emoción]
Color palette: [nombre y HEX]
Wardrobe/materials: [detalles]
Text (verbatim): "[texto exacto]"
Constraints: [invariantes]
Avoid: [clichés, defectos, colores y objetos]
```

No incluir detalles ornamentales que no apoyen el posicionamiento.

## 2. Identidad facial

Para editar o derivar una foto:

- declarar la imagen principal como referencia de identidad;
- preservar rostro, edad aparente, tono de piel, cabello, complexión y rasgos;
- cambiar solo vestuario, fondo, luz, expresión o encuadre solicitado;
- no adelgazar, rejuvenecer ni alterar rasgos sin solicitud explícita;
- repetir invariantes en cada iteración.

Si hay varias referencias, indicar qué aporta cada una. No mezclar identidades.

## 3. Logos y texto

Usar generación para explorar símbolo, material y mockup. Para wordmarks, slogans, paletas y tableros finales, componer el texto fuera de la imagen con herramientas deterministas.

Cuando se necesite texto dentro de una pieza generativa:

- citarlo literalmente;
- especificar posición y jerarquía;
- usar poco texto;
- inspeccionar carácter por carácter;
- reconstruir la pieza si el texto falla.

## 4. Formatos

- 1:1: avatar, post y portada cuadrada.
- 4:5: feed vertical con mayor área visible.
- 9:16: story, reel y video vertical; reservar zonas seguras superior/inferior.
- 16:9: web hero, YouTube, webinar y presentación.
- Horizontal amplio: fotografía editorial con espacio para copy.

Adaptar la composición a cada ratio. No resolver una campaña con recortes automáticos que corten rostro, logo o CTA.

## 5. Reglas de iteración

1. Generar un activo maestro.
2. Inspeccionarlo visualmente.
3. Anotar una sola falla dominante.
4. Cambiar una variable por iteración.
5. Comparar con referencia y paleta.
6. Aprobar antes de derivar formatos.

Mantener un prompt base aprobado y registrar únicamente los deltas por versión.
