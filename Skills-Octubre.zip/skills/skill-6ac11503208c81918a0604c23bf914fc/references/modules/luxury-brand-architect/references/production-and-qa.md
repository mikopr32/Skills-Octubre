# Producción y control de calidad

## Índice

1. Gates
2. Manifiesto
3. Scorecard
4. Regeneración
5. Fallas del sistema

## 1. Gates

| Gate | Debe estar aprobado antes de avanzar |
| --- | --- |
| G0 Alcance | nombre, audiencia, modo y entregables |
| G1 Estrategia | posicionamiento, personalidad y anti-clichés |
| G2 Dirección | territorio, paleta preliminar y tono |
| G3 Fundación | logo, tipografía, paleta y foto maestra |
| G4 Piloto | una pieza aplicada con QA ≥ 8 |
| G5 Escala | lote completo coherente |
| G6 Entrega | archivos, tablero, guía y prompts |

En Guided, G2 requiere selección explícita del usuario. En Express, documentar la recomendación y continuar.

## 2. Manifiesto

Campos mínimos:

| Campo | Contenido |
| --- | --- |
| ID | código estable |
| Activo | nombre comercial |
| Formato | ratio y extensión |
| Objetivo | canal y función |
| Prompt | prompt aprobado o referencia |
| Inputs | fotos/logos usados |
| Estado | planned, generating, review, approved, regenerate, delivered |
| QA | puntuación y falla dominante |

Usar `scripts/brand_project.py` para inicializar JSON y CSV. Actualizar el manifiesto durante la producción, no al final de memoria.

## 3. Scorecard

Puntuar de 1 a 10:

1. coherencia de marca;
2. calidad profesional;
3. realismo;
4. composición;
5. uso de color;
6. legibilidad;
7. diferenciación;
8. consistencia de identidad;
9. utilidad comercial;
10. ausencia de errores visuales.

Regla: ningún activo < 8 y promedio global ≥ 9. Inspeccionar el archivo renderizado, no solo sus metadatos.

## 4. Regeneración

Regenerar o reconstruir ante:

- texto incorrecto;
- rostro, manos o anatomía defectuosos;
- logo ilegible o inconsistente;
- color fuera de sistema;
- falta de contraste;
- clichés dominantes;
- duplicaciones o artefactos;
- apariencia artificial evidente;
- mockup que oculta el diseño;
- variación significativa entre piezas.

Corregir una variable a la vez y preservar explícitamente lo aprobado.

## 5. Fallas del sistema

- **Genérico:** volver a audiencia, transformación, prueba y diferenciador.
- **Lujo artificial:** reducir oro/ornamento; aumentar espacio, proporción y materialidad.
- **Rostro inconsistente:** reducir lote, fijar una referencia maestra y derivar desde ella.
- **Logo defectuoso:** separar símbolo, wordmark y mockup; reconstruir vectorialmente.
- **Tablero ilegible:** dividir tablero y guía; aumentar jerarquía y tamaño.
- **Costo alto:** aprobar G3 antes de escalar y limitar variantes no solicitadas.
- **Canales inconexos:** definir un activo propietario repetible y reglas de adaptación por ratio.
