#!/usr/bin/env python3
"""Initialize a deterministic production manifest for a brand project."""

from __future__ import annotations

import argparse
import csv
import json
import re
from datetime import datetime, timezone
from pathlib import Path


DEFAULT_ASSETS = [
    ("ID-001", "logo-primary", "svg", "Core identity"),
    ("ID-002", "monogram", "svg", "Avatar and small-format identity"),
    ("ID-003", "palette", "svg", "Color reference"),
    ("ID-004", "typography", "pdf", "Type hierarchy reference"),
    ("PH-001", "headshot-master", "4x5-png", "Primary brand portrait"),
    ("MK-001", "social-pilot", "4x5-png", "Campaign validation"),
    ("BB-001", "brand-board-vertical", "portrait-pdf", "System overview"),
]


def slugify(value: str) -> str:
    value = value.strip().lower()
    value = re.sub(r"[^a-z0-9]+", "-", value)
    return value.strip("-") or "brand"


def parse_asset(spec: str, index: int) -> tuple[str, str, str, str]:
    parts = [part.strip() for part in spec.split(":")]
    if len(parts) not in (2, 3):
        raise argparse.ArgumentTypeError(
            "Asset must be name:format or name:format:objective"
        )
    name, fmt = parts[:2]
    objective = parts[2] if len(parts) == 3 else "User-defined deliverable"
    return (f"AS-{index:03d}", slugify(name), fmt, objective)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--brand", required=True, help="Exact brand name")
    parser.add_argument(
        "--mode", choices=("guided", "express", "rebrand", "audit"), default="guided"
    )
    parser.add_argument("--output", required=True, type=Path, help="Project directory")
    parser.add_argument(
        "--asset",
        action="append",
        default=[],
        help="Repeatable name:format[:objective] specification",
    )
    args = parser.parse_args()

    project_slug = slugify(args.brand)
    project_dir = args.output.resolve()
    project_dir.mkdir(parents=True, exist_ok=True)

    assets = (
        [parse_asset(spec, i + 1) for i, spec in enumerate(args.asset)]
        if args.asset
        else DEFAULT_ASSETS
    )
    rows = []
    for asset_id, name, fmt, objective in assets:
        rows.append(
            {
                "id": asset_id,
                "asset": name,
                "format": fmt,
                "objective": objective,
                "filename": f"{project_slug}-{name}-v01",
                "prompt": "",
                "references": [],
                "status": "planned",
                "qa_score": None,
                "qa_note": "",
            }
        )

    manifest = {
        "brand": args.brand,
        "slug": project_slug,
        "mode": args.mode,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "approved_direction": None,
        "gates": {f"G{i}": "pending" for i in range(7)},
        "assets": rows,
    }

    json_path = project_dir / "generation-manifest.json"
    csv_path = project_dir / "generation-manifest.csv"
    json_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")

    with csv_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=[
                "id",
                "asset",
                "format",
                "objective",
                "filename",
                "prompt",
                "references",
                "status",
                "qa_score",
                "qa_note",
            ],
        )
        writer.writeheader()
        for row in rows:
            csv_row = dict(row)
            csv_row["references"] = ""
            writer.writerow(csv_row)

    print(json.dumps({"manifest": str(json_path), "csv": str(csv_path)}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
