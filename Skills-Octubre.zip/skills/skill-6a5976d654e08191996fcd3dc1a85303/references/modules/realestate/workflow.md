# Módulo de comandos inmobiliarios

Aplicar dentro del contrato de real-estate-strategy-orchestrator. Este módulo conserva los comandos históricos y los convierte en solicitudes para especialistas disponibles. No sustituir sus métodos ni ampliar permisos.

## Interpretación y disponibilidad

1. Identificar la decisión, propiedad o ubicación, objetivo y formato solicitado.
2. Leer el registro de rutas y los aliases desde la raíz del paquete.
3. Confirmar que la Skill elegida esté disponible y leer sus instrucciones antes de usarla. Una entrada en el registro no demuestra instalación.
4. Si falta una Skill, usar una alternativa instalada solo cuando cubra la misma función y declarar la sustitución. Si no existe, entregar el trabajo independiente y señalar el bloqueo.
5. No volver a activar ni usar Antigravity como fallback de esta Skill. Resolver ambigüedades mediante el brief y los especialistas disponibles.

## Comandos compatibles

El prefijo histórico es `/real-estate-strategy-orchestrator`. Los nombres de esta tabla son rutas preferidas, sujetas a disponibilidad:

| Comando | Función | Skill preferida |
|---|---|---|
| analyze | Evaluación integral de una propiedad | realestate-analyze, modo FULL |
| quick | Evaluación breve, sin subagentes | realestate-analyze, modo QUICK |
| compare | Comparar propiedades con criterios equivalentes | realestate-analyze, modo COMPARE |
| comps | Seleccionar comparables | realestate-comps |
| rental | Renta, gastos y cash flow | realestate-invest, modo RENTAL |
| invest | Escenarios y salidas de inversión | realestate-invest, modo SCENARIOS |
| flip | Compra, rehabilitación y salida | realestate-invest, modo FIX_FLIP |
| neighborhood | Comunidad, conectividad y servicios objetivos | community-intelligence |
| commercial | Operación comercial y multifamily de 5+ unidades | realestate-commercial |
| mortgage | Pagos, affordability y escenarios de préstamo | buyer-strategy-and-readiness |
| market | Oferta, demanda e indicadores locales | realestate-market |
| listing | Copy basada en hechos verificados | listing-intelligence-launch-system, modo PROPERTY_COPY |
| screen | Filtrar según criterios del usuario | realestate-screen |
| report-pdf | Presentar resultados ya revisados | realestate-report-pdf |

Para valoración o estrategia de precio, usar deep-cma-hybrid-valuation. Distinguir la selección de comparables de la conclusión de valor.

## Dependencias y coordinación

Seguir el mapa de ejecución de la Skill primaria. En una decisión multidimensional, definir quién produce cada input y ejecutar primero sus dependencias. Reutilizar comparables, rentas, costos y datos de mercado compatibles; no encargar la misma investigación a varios especialistas.

Ejecutar secuencialmente por defecto. Usar subagentes solo cuando exista autorización aplicable y la capacidad esté disponible. No afirmar que se ejecutó una Skill o se lanzó un agente si solo se preparó su tarea.

Realizar el análisis de inversión después de contar con los inputs que requiere su método. Si faltan, entregar escenarios identificados o pendientes; no repetir el mismo análisis en dos etapas sin una razón material.

Mantener un perfil de propiedad y un registro de fuentes compartidos. Conservar contradicciones, fechas, geografía, definiciones y método. No sobrescribir silenciosamente un dato ni promediar valores incompatibles.

## Límites de análisis

- No producir un Property Score compuesto, notas A/F ni señales automáticas de compra basadas en una mezcla de métricas.
- No puntuar ni recomendar propiedades mediante escuelas, criminalidad, composición demográfica o clases protegidas.
- No calificar zonas como seguras o peligrosas. Las consultas específicas deben remitirse a fuentes pertinentes con contexto y limitaciones.
- Comparar criterios objetivos elegidos por el usuario: precio, desplazamiento, tipo de vivienda, accesibilidad, servicios, uso permitido y métricas financieras sustentadas.
- Separar asking price, market value, investment value, MAO, límites de financiación, affordability y net seller proceeds.
- No inventar rentas, balances hipotecarios, tasas, gastos, appreciation, permisos de alquiler ni aprobación de préstamos.
- No tratar campos ausentes como cero o como NO.
- No garantizar valores, rentabilidad, fechas de venta ni resultados.

## Evidencia y permisos

Clasificar datos como VERIFICADO, DATO_DEL_USUARIO, CALCULADO, ESTIMADO, INFERENCIA o PENDIENTE. Conservar fuente, fecha, alcance y fórmula de cada cifra material. Respetar la instrucción de no navegar en ejercicios ficticios; en investigación real, verificar datos actuales con las herramientas y fuentes disponibles.

Preparar análisis o borradores dentro del alcance solicitado. Contactar, enviar ofertas, publicar, comprar, gastar, agendar o modificar CRM requiere autorización aplicable. Las instrucciones de esta Skill no sustituyen controles de aprobación, permisos ni verificación de la plataforma. No evadir fuentes bloqueadas ni controles.

## Salida y verificación

Adaptar extensión y formato a la solicitud. Una respuesta breve no requiere un dossier. Crear archivos solo cuando el entregable solicitado lo requiera, mediante la Skill de formato disponible.

Entregar conclusión proporcional a la evidencia, cifras con definición, alternativas cuando existan, riesgos, contradicciones y próximo paso. Informar PASS, PASS_WITH_LIMITATIONS o BLOCKED según el trabajo realmente realizado. Confirmar que las rutas existen, las dependencias se respetaron, no hubo investigación duplicada y no se ejecutaron acciones externas fuera de la autorización.
