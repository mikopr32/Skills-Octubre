#!/usr/bin/env python3
"""Audit intent registry against active packages by YAML name, not folder ID."""
import argparse,json,re,sys
from pathlib import Path
from collections import Counter
def inventory(root):
    records=[]
    for f in sorted(Path(root).glob('*/SKILL.md')):
        m=re.match(r'---\n(.*?)\n---',f.read_text(),re.S)
        name=re.search(r'^name:\s*([a-z0-9-]+)\s*$',m.group(1),re.M) if m else None
        if name:records.append((name.group(1),str(f)))
    return records
def audit(registry,root):
    routes=json.loads(Path(registry).read_text())['routes'];records=inventory(root);installed={n for n,_ in records}
    invalid=[];intents=[];referenced=[]
    for i,r in enumerate(routes):
        if not isinstance(r,dict) or not isinstance(r.get('intent'),str) or not isinstance(r.get('primary'),str) or not isinstance(r.get('supports',[]),list):invalid.append(i);continue
        intents.append(r['intent']);referenced.append(r['primary']);referenced+=r.get('supports',[])
        if r['primary'] in r.get('supports',[]) or len(set(r.get('supports',[])))!=len(r.get('supports',[])):invalid.append(i)
    duplicates=sorted(k for k,v in Counter(intents).items() if v>1);duplicate_names=sorted(k for k,v in Counter(n for n,_ in records).items() if v>1)
    missing=sorted(set(referenced)-installed)
    return {'route_count':len(routes),'invalid_routes':invalid,'duplicate_intents':duplicates,'duplicate_skill_names':duplicate_names,'missing_referenced_skills':missing,'installed_skill_count':len(installed),'valid':not(invalid or duplicates or missing or duplicate_names)}
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--registry',required=True);p.add_argument('--skills-root',required=True);a=p.parse_args();r=audit(a.registry,a.skills_root);print(json.dumps(r,indent=2));sys.exit(0 if r['valid'] else 1)
