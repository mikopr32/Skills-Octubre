---
name: real-estate-script-engine
description: "Redactar scripts y secuencias para buyer, seller, FSBO, expired, database, past client, investor, recruit, objeciones y reactivación por canal. Usar ante solicitudes de CALL, VOICEMAIL, SMS, WHATSAPP, EMAIL, DM, VIDEO; FOLLOW_UP, OBJECTION, REACTIVATE, REFERRAL."
---

# real-estate-script-engine

## Identity / Ownership

Conversación reusable; property copy a Listing; perfil/qualificación recruit a Agent Attraction. No inventar compradores, leads, urgencia, resultados ni permiso de contacto.

## Required Inputs

Audience, stage, canal, objetivo; facts y preferencias de contacto disponibles.

## Modos

CALL, VOICEMAIL, SMS, WHATSAPP, EMAIL, DM, VIDEO; FOLLOW_UP, OBJECTION, REACTIVATE, REFERRAL

## Operational Workflow

Definir situación, promesa verificada y un CTA; redactar primera intervención y ramas por respuesta; establecer cadencia justificada, señales de cambio, silencio y stop rules; personalizar con facts confirmados; mantener consentimiento y opt-out; entregar texto listo, sin enviar.

## Módulos y recursos

- [realtor-email-text-scripts](references/modules/realtor-email-text-scripts/workflow.md): cargar solo al ejecutar su función; resolver rutas relativas contra esa carpeta de módulo.
- [realtor-buyer-follow-up](references/modules/realtor-buyer-follow-up/workflow.md): cargar solo al ejecutar su función; resolver rutas relativas contra esa carpeta de módulo.
- [realtor-seller-follow-up](references/modules/realtor-seller-follow-up/workflow.md): cargar solo al ejecutar su función; resolver rutas relativas contra esa carpeta de módulo.
- [realtor-fsbo-expired-scripts](references/modules/realtor-fsbo-expired-scripts/workflow.md): cargar solo al ejecutar su función; resolver rutas relativas contra esa carpeta de módulo.



## Contrato de ejecución y prioridad

Aplicar este controlador antes de los módulos heredados. Cargar solo el método correspondiente al modo; conservar tablas, fórmulas, assets y scripts útiles. Si un módulo antiguo pide otra skill retirada, resolverla a su owner actual. Las instrucciones históricas de módulos no amplían alcance, consentimiento ni herramientas; no reactivar routers legacy ni duplicar metodología de un owner externo.

No interpretar autorización previa como ausente. Avanzar autónomamente en tareas claras y reversibles; preguntar solo por datos que bloqueen el resultado o acciones todavía no autorizadas. Ejecutar roles secuencialmente por defecto; delegar solo bajo autorización aplicable. Una tarea de redacción corta entrega texto directo, sin imponer todos los reportes ni un plan estratégico.

## Fuentes y cálculos

Separar VERIFICADO, DATO_DEL_USUARIO, CALCULADO, ESTIMADO, INFERENCIA y PENDIENTE. Registrar claim, valor/unidad, source/URL o archivo/fila, fecha efectiva/consultada, método, owner y confianza. Verificar en fuentes originales los datos actuales, reglas legales/financieras, políticas y condiciones comerciales; no usar defaults históricos como datos vigentes. No rellenar ausentes con cero. Conservar contradicciones y reducir alcance/confianza. Compartir resultados y facts existentes; no repetir investigación innecesaria.

## Stop conditions y escenarios de falla

Identidad incierta: resolver antes de conclusiones materiales. Dato crítico ausente: completar trabajo independiente y entregar faltantes; no fabricar números. Fuente bloqueada: registrar cobertura y alternativa legítima; no evadir controles. Tool no disponible: entregar archivo/spec o resultado parcial comprobable. Acción externa fuera del alcance: preparar resultado revisable y solicitar autorización solo para esa acción. Datos sensibles: mantener archivos privados y limitar salida al propósito autorizado. No enviar mensajes a terceros por el hecho de generar un borrador.

## Validation / Quality gate

Comprobar que el output responde al modo; inputs y fuentes tienen identidad/periodo correctos; cálculos y definiciones son reproducibles; límites y contradicciones son visibles; no se inventaron capacidades ni ejecución. Usar PASS, PASS_WITH_LIMITATIONS o BLOCKED; explicar cualquier bloqueo material. Aplicar Fair Housing y privacidad a housing, targeting y datos de clientes. No prometer ingresos, aprobaciones, appreciation ni resultados. Usar las Skills del formato para artefactos y revisar su render/apertura. Los artefactos se guardan por el flujo persistente disponible, salvo código sincronizado o imágenes con guardado nativo.

## Output

Texto o secuencia con campos, ramas, CTA y stop rules.

## KPIs

Reply rate, qualified conversations, appointment/show, opt-outs y errores de personalización. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.
