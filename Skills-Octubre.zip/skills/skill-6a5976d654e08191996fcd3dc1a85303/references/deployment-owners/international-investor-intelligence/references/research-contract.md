# Investigación internacional

Construir Source Matrix con claim, definiciones, población, geografía, periodo, sample, método, publicación, consulta, URL y confidence. Buscar informes originales de NAR (https://www.nar.realtor/research-and-statistics), Florida Realtors (https://www.floridarealtors.org/tools-research/reports), Census/BEA y fuente oficial local pertinente. No asumir que una publicación titulada 2026 mide todo 2026; comprobar ventana.

Separar país de origen, residencia, ciudadanía, idioma y origen del capital: no son equivalentes. Una compra con LLC no identifica beneficiario, país ni motivación. Distinguir unidades, transactions, volumen $, median ticket y survey shares. No extrapolar ranking de Florida a Polk/Orlando/Central Florida sin datos locales. Si faltan, mostrar gap y alternativa de investigación; no inventar top5.

Comparar 2–3 segmentos por tesis: preservación de capital, cash flow, diversificación, proyecto/operación y horizonte. Confirmar necesidades mediante entrevistas abiertas con clientes y profesionales autorizados, sin atribuir rasgos psicológicos a una nacionalidad. Registrar miedos/motivaciones como hipótesis hasta observar evidencia; diseñar proof pack y proceso de due diligence para cada uno.

No limitar el producto a Lake Alfred Village ni dúplex. Evaluar residencial, rental, multifamily, commercial/land según encaje y capacidad; handoff a underwriting correspondiente. Referir cuestiones tributarias, titularidad, migración, FIRPTA, transferencias y financing a profesionales y fuentes actuales; no ofrecer un plan legal como certeza.

Diseñar canal → oferta → qualification → proof → consulta → underwriting → decisión → operación. Comparar partnerships profesionales, educación/webinars y campañas directas por velocidad/costo/confianza/capacidad. Pilotear uno antes de escalar. Medir qualified conversations, attended consultations, casos underwritten, cierres/cohorte, elapsed time y costo total; no llamar successful un canal por clicks.
