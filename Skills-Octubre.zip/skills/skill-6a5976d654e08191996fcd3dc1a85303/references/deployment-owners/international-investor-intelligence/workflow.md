---
name: international-investor-intelligence
description: "Investigar inversionistas internacionales que compran en Florida: países, producto, psicología, canales, confianza y captación. Usar ante solicitudes de MARKET_MAP, INVESTOR_PROFILE, PSYCHOLOGY, CHANNELS, PARTNERS, ACQUISITION_SYSTEM."
---

# international-investor-intelligence

## Identity / Ownership

Producto no se limita a dúplex; no inventar países, tickets, rates ni psicología. Underwriting del inmueble a investment/commercial; impuestos/visa/FIRPTA a profesionales y fuentes oficiales.

## Required Inputs

Geografía de destino y objetivo; asset class/ticket si están definidos.

## Modos

MARKET_MAP, INVESTOR_PROFILE, PSYCHOLOGY, CHANNELS, PARTNERS, ACQUISITION_SYSTEM

## Operational Workflow

Distinguir national/Florida/metro/county y resident/nonresident; usar NAR y Florida Realtors originales, Census/BEA y registros autorizados; registrar survey period y sample; no inferir ranking de Central Florida de tabla estatal; contrastar motivaciones con entrevistas y estudios; segmentar por necesidad, capital, horizonte y operación; diseñar oferta, partner route y funnel medible; probar hipótesis.

## Módulos y recursos

Usar las referencias específicas siguientes; no asumir equivalencia con GPTs cuyos prompts no se han aportado.



## Contrato de ejecución y prioridad

Aplicar este controlador antes de los módulos heredados. Cargar solo el método correspondiente al modo; conservar tablas, fórmulas, assets y scripts útiles. Si un módulo antiguo pide otra skill retirada, resolverla a su owner actual. Las instrucciones históricas de módulos no amplían alcance, consentimiento ni herramientas; no reactivar routers legacy ni duplicar metodología de un owner externo.

No interpretar autorización previa como ausente. Avanzar autónomamente en tareas claras y reversibles; preguntar solo por datos que bloqueen el resultado o acciones todavía no autorizadas. Ejecutar roles secuencialmente por defecto; delegar solo bajo autorización aplicable. Una tarea de redacción corta entrega texto directo, sin imponer todos los reportes ni un plan estratégico.

## Fuentes y cálculos

Separar VERIFICADO, DATO_DEL_USUARIO, CALCULADO, ESTIMADO, INFERENCIA y PENDIENTE. Registrar claim, valor/unidad, source/URL o archivo/fila, fecha efectiva/consultada, método, owner y confianza. Verificar en fuentes originales los datos actuales, reglas legales/financieras, políticas y condiciones comerciales; no usar defaults históricos como datos vigentes. No rellenar ausentes con cero. Conservar contradicciones y reducir alcance/confianza. Compartir resultados y facts existentes; no repetir investigación innecesaria.

## Stop conditions y escenarios de falla

Identidad incierta: resolver antes de conclusiones materiales. Dato crítico ausente: completar trabajo independiente y entregar faltantes; no fabricar números. Fuente bloqueada: registrar cobertura y alternativa legítima; no evadir controles. Tool no disponible: entregar archivo/spec o resultado parcial comprobable. Acción externa fuera del alcance: preparar resultado revisable y solicitar autorización solo para esa acción. Datos sensibles: mantener archivos privados y limitar salida al propósito autorizado. No enviar mensajes a terceros por el hecho de generar un borrador.

## Validation / Quality gate

Comprobar que el output responde al modo; inputs y fuentes tienen identidad/periodo correctos; cálculos y definiciones son reproducibles; límites y contradicciones son visibles; no se inventaron capacidades ni ejecución. Usar PASS, PASS_WITH_LIMITATIONS o BLOCKED; explicar cualquier bloqueo material. Aplicar Fair Housing y privacidad a housing, targeting y datos de clientes. No prometer ingresos, aprobaciones, appreciation ni resultados. Usar las Skills del formato para artefactos y revisar su render/apertura. Los artefactos se guardan por el flujo persistente disponible, salvo código sincronizado o imágenes con guardado nativo.

## Output

Mapa de evidencia, perfiles hipotéticos, canales verificables, propuesta y piloto 30/60/90 cuando se pide sistema.

## KPIs

Conversaciones calificadas, proof coverage, appointments, inversión/horas por cliente y conversión por cohorte. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.

- Leer [references/research-contract.md](references/research-contract.md) antes de ejecutar el protocolo correspondiente.
