# Evaluación breve de propiedad

Aplicar dentro del contrato realestate-analyze. Entregar una respuesta breve en chat, sin subagentes ni archivo por defecto. Priorizar datos decisivos y límites visibles; no prometer un tiempo fijo.

## Inputs

Identificar dirección o parcela, tipo, precio y decisión cuando existan. Confirmar identidad antes de combinar fuentes. Para un ejercicio ficticio, conservar esa etiqueta y usar solo los datos aportados si el usuario prohíbe navegar.

## Investigación y revisión

Usar herramientas disponibles para confirmar los datos actuales necesarios. No asumir WebSearch, MLS ni herramientas privadas. Registrar fuente y fecha. Si la identidad no se puede confirmar, entregar lo independiente y el faltante.

Reunir precio con su tipo, beds/baths, sqft, año, condición documentada, HOA/CDD, impuestos, uso permitido y los riesgos pertinentes a la pregunta. No inferir condición por antigüedad ni sustituir market value por assessed value.

Cuando la decisión requiera valoración, rentabilidad, comunidad o financiación, usar el especialista disponible correspondiente y reutilizar sus resultados. Una pregunta sencilla puede resolverse con datos aportados y cálculos transparentes.

## Cálculos

- Precio por sqft: precio / superficie habitable, si ambos existen y el denominador es válido.
- Gross rental yield: renta anual / precio, únicamente con renta respaldada o un supuesto explícito solicitado.
- Pagos de préstamo: requieren principal, tasa, plazo y demás inputs del método.
- PITI, costo de propiedad y cash flow: requieren sus componentes; separar HOA/CDD y otros gastos, sin doble conteo.

No inventar renta con la regla del 1%, usar 20% de down payment por defecto, sustituir gastos por un factor del 28%, ni obtener equity a partir de Purchase Price. Mantener cualquier cálculo sin inputs críticos como PENDIENTE.

## Evaluación objetiva

Mostrar hallazgo, evidencia y pendiente para precio/comparables, renta/costos, comunidad/usos, mercado y condición cuando sean relevantes. No crear Property Score, notas de barrio ni señales automáticas de compra. No usar escuelas, crimen, demografía o clases protegidas para recomendar.

Comparar solo criterios elegidos por el usuario. Identificar las tres verificaciones que más puedan cambiar su decisión. Con datos insuficientes, explicar el límite con claridad.

## Salida y control

Entregar identidad, fecha, datos esenciales, números calculables, principales hallazgos y próximo paso. Usar una tabla compacta si facilita la lectura. No imponer ASCII, terminal ni un informe largo.

Clasificar VERIFICADO, DATO_DEL_USUARIO, CALCULADO, ESTIMADO, INFERENCIA y PENDIENTE. No rellenar ausentes con cero. No afirmar que una Skill o agente se ejecutó si no ocurrió. Con varias propiedades, aplicar los mismos criterios y mostrar comparabilidad.

Informar PASS, PASS_WITH_LIMITATIONS o BLOCKED según la evidencia. No garantizar valor, renta, appreciation, préstamo o venta. No ejecutar contacto, publicación, ofertas, gastos ni cambios externos sin autorización aplicable; respetar los controles de la plataforma.
