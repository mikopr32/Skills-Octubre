# Análisis integral de propiedad

Aplicar dentro del controlador realestate-analyze y de los límites de real-estate-strategy-orchestrator. Coordinar evidencia especializada y producir una evaluación condicionada; no crear un Property Score, calificaciones A/F ni una recomendación automática por promedio de métricas.

## Inputs y alcance

Identificar dirección o parcela, tipo de propiedad, decisión, precio o presupuesto, estrategia, financiación, horizonte y formato. Aceptar casos ficticios identificados; respetar una instrucción de no investigar en internet. No convertir datos del ejercicio en hechos verificados externamente.

Antes de investigar, confirmar identidad y jurisdicción. Distinguir residencia, renta larga, STR, flip, BRRRR, terreno y comercial. Ajustar las preguntas y métricas a la estrategia. Si falta un dato crítico, avanzar en las partes independientes y mantener la conclusión afectada pendiente.

## Perfil compartido

Registrar dirección, precio solicitado y fecha, precio de última compra y fecha, beds/baths, superficie habitable, lote, año, tipo, condición observada, garaje, HOA, CDD, impuestos, zonificación y riesgos físicos cuando existan. Conservar fuente, fecha, alcance y confianza por campo.

Separar asking price, precio de compra, assessed value, market value, ARV, investment value, MAO, techo de financiación, affordability y net seller proceeds. No sustituir un tipo de valor por otro. Purchase Price no demuestra balance hipotecario ni equity disponible.

## Plan y especialistas

Confirmar disponibilidad real y leer los contratos de los especialistas antes de actuar. Usar la Skill independiente cuando exista. Para un owner pendiente, el orquestador puede utilizar el workflow incluido que identifica deployment-map.json; declarar que se ejecutó un módulo y no una Skill independiente instalada.

Definir dependencias para que cada dato tenga un solo productor:

1. realestate-comps selecciona comparables; deep-cma-hybrid-valuation determina valor o estrategia de precio cuando sea necesario.
2. realestate-invest, modo RENTAL, produce renta y gastos operativos conforme a su método.
3. community-intelligence verifica HOA/CDD, usos permitidos, conectividad, servicios y riesgos físicos objetivos.
4. realestate-market produce indicadores del mercado y periodo aplicables.
5. realestate-invest realiza escenarios de inversión después de recibir los inputs reconciliados. Reutilizar el modelo de renta; no repetir su investigación.
6. dscr-loan-underwriter o buyer-strategy-and-readiness intervienen únicamente si la decisión requiere financiación y existen inputs suficientes.

No imponer todos los especialistas a todos los casos. Ejecutar secuencialmente por defecto. Delegar o paralelizar mediante agentes solo con autorización aplicable y herramientas disponibles. No simular llamadas, agentes o ejecuciones.

## Handoff y reconciliación

Entregar decisión, subtarea, identidad, datos aportados, hechos revisados, incógnitas, supuestos autorizados, fuentes requeridas, output y dependencias. Solicitar evidencia, cálculos, método, confianza, riesgos y pendientes.

Centralizar identidad, precios, superficies, valor/ARV, rentas, gastos, geografía y periodos antes de las proyecciones dependientes. Ante una contradicción, comparar alcance, fecha, definición, autoridad y método. Conservar las alternativas si no se puede resolver. El especialista devuelve un INPUT_CHALLENGE si cuestiona un input; no lo reemplaza silenciosamente.

Registrar CLAIM_ID, dato, valor/unidad, fuente o archivo/fila, fecha efectiva y consultada, geografía, método, responsable, confianza y estado del conflicto. Separar VERIFICADO, DATO_DEL_USUARIO, CALCULADO, ESTIMADO, INFERENCIA y PENDIENTE.

## Cálculos y escenarios

Utilizar las fórmulas y definiciones del especialista competente. Mostrar inputs, unidades, periodo y método. Calcular solo métricas relevantes y con datos suficientes:

- Precio por sqft y comparación con comparables realmente pertinentes.
- Renta, vacancy, ingresos efectivos, gastos, NOI y cash flow.
- Cap rate y cash-on-cash con bases y denominadores explícitos.
- DSCR conforme a la definición y requisitos del lender, cuando se conozcan.
- Hold: cash flow, deuda y sensibilidad temporal.
- BRRRR: ARV, rehabilitación y refinance bajo supuestos identificados.
- Flip: compra, rehabilitación, holding y selling costs sustentados.
- Escenarios bajo/base/alto cuando existan rangos defendibles.

No imponer vacancy, mantenimiento, down payment, tasas, LTV, meses de holding, comisiones o appreciation como datos del caso. Un supuesto de sensibilidad debe identificarse como tal; no representa una cotización, gasto real o resultado garantizado. No inferir renta mediante la regla del 1% ni usar un porcentaje global de gastos como sustituto del presupuesto. No calcular beneficios fiscales personalizados como certeza.

Si falta deuda, precio, renta o gasto crítico, mantener la métrica afectada PENDIENTE. No completar con cero. Evitar doble conteo del CDD incluido en taxes y distinguir pago hipotecario de gastos operativos.

## Ubicación y criterios de decisión

No puntuar escuelas, criminalidad, ingresos de residentes, demografía ni clases protegidas. No calificar barrios ni asignarlos a familias, jóvenes o retirados. Comparar solo criterios objetivos del usuario. Si solicita asignación escolar, verificarla por dirección y mantenerla separada de la valoración.

Analizar conectividad, amenidades realmente incluidas, costos, restricciones de uso, flood y otras condiciones documentadas. No inferir ausencia de CDD ni permiso STR por falta de documentación o presencia de anuncios.

## Síntesis y salida

Adaptar el informe a la profundidad solicitada. No crear archivos por defecto. Para un entregable, utilizar la Skill de formato disponible y guardar por el flujo persistente aplicable.

Incluir cuando proceda:

1. Decisión, identidad, alcance y fecha.
2. Resumen ejecutivo condicionado a la evidencia.
3. Perfil compartido y tabla de fuentes.
4. Comparables y valoración, conservando método y límites.
5. Renta y costos, con escenarios comparables.
6. Comunidad, usos y riesgos físicos objetivos.
7. Escenarios de inversión y financiación pertinentes.
8. Mercado con periodo, geografía y definiciones.
9. Matriz de riesgos: evidencia, impacto, incertidumbre y mitigación.
10. Alternativas, trade-offs, condiciones que cambiarían la conclusión y próximo paso.

Presentar una recomendación solo si los criterios del usuario y la evidencia permiten sostenerla. Si no, indicar qué verificación resolvería la decisión. No convertir una nota compuesta en BUY/STRONG BUY/PASS.

## Verificación final

Revisar disponibilidad, identidad, fórmulas, denominadores, fechas, límites, contradicciones y permisos. No prometer valores, returns, financiación, tiempos de venta ni appreciation. No enviar ofertas, contactar, publicar, gastar o modificar cuentas sin autorización aplicable. Respetar los controles de la plataforma.

Informar PASS, PASS_WITH_LIMITATIONS o BLOCKED según el trabajo realizado. La cobertura parcial puede servir para describir o calcular ciertos datos sin acreditar una recomendación final.
