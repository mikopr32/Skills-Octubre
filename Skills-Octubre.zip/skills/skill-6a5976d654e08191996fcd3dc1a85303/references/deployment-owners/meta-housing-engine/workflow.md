---
name: meta-housing-engine
description: "Investigar competencia, diseñar, auditar y optimizar campañas Meta Housing con copy, creative, forms, CRM, tracking y QA; recuperar Google Search bajo solicitud explícita. Usar ante solicitudes de RESEARCH, COMPETITIVE, CAMPAIGN_BUILD, CREATIVE, INSTANT_FORM, CRM, TRACKING, OPTIMIZE, QA, GOOGLE_SEARCH_COMPAT."
---

# meta-housing-engine

## Identity / Ownership

Único owner de paid Meta Housing. Funnel/landing/ManyChat son implementadores distintos. No lanzar gasto ni inferir performance privada. Si se pide Google-only usar compatibilidad explícita y declarar alcance; no fingir soporte avanzado.

## Required Inputs

Mercado/offer y objetivo; budget y acceso si se solicita ejecución.

## Modos

RESEARCH, COMPETITIVE, CAMPAIGN_BUILD, CREATIVE, INSTANT_FORM, CRM, TRACKING, OPTIMIZE, QA, GOOGLE_SEARCH_COMPAT

## Operational Workflow

Verificar políticas oficiales vigentes; clasificar oferta y Special Ad Category cuando aplica; registrar anuncios públicos sin inferir spend/CPL/ROI; aprobar Pattern Matrix y originalidad; construir campaign architecture, dos copies y form/thank-you; definir tracking, CRM handoff, test y quality KPIs. Google Search compatibility usa módulo genérico y fuentes Google actuales; no aplicar targeting Meta a Google.

## Módulos y recursos

- [realtor-meta-housing-ads](references/modules/realtor-meta-housing-ads/workflow.md): cargar solo al ejecutar su función; resolver rutas relativas contra esa carpeta de módulo.
- [meta-housing-ad-intelligence](references/modules/meta-housing-ad-intelligence/workflow.md): cargar solo al ejecutar su función; resolver rutas relativas contra esa carpeta de módulo.
- [realtor-ads-lead-generation](references/modules/realtor-ads-lead-generation/workflow.md): cargar solo al ejecutar su función; resolver rutas relativas contra esa carpeta de módulo.

- `references/modules/meta-housing-ad-intelligence/scripts/analyze_ads.py`: usar cuando el método elegido lo requiera; ejecutar scripts desde la carpeta de su módulo o por ruta absoluta.

## Contrato de ejecución y prioridad

Aplicar este controlador antes de los módulos heredados. Cargar solo el método correspondiente al modo; conservar tablas, fórmulas, assets y scripts útiles. Si un módulo antiguo pide otra skill retirada, resolverla a su owner actual. Las instrucciones históricas de módulos no amplían alcance, consentimiento ni herramientas; no reactivar routers legacy ni duplicar metodología de un owner externo.

No interpretar autorización previa como ausente. Avanzar autónomamente en tareas claras y reversibles; preguntar solo por datos que bloqueen el resultado o acciones todavía no autorizadas. Ejecutar roles secuencialmente por defecto; delegar solo bajo autorización aplicable. Una tarea de redacción corta entrega texto directo, sin imponer todos los reportes ni un plan estratégico.

## Fuentes y cálculos

Separar VERIFICADO, DATO_DEL_USUARIO, CALCULADO, ESTIMADO, INFERENCIA y PENDIENTE. Registrar claim, valor/unidad, source/URL o archivo/fila, fecha efectiva/consultada, método, owner y confianza. Verificar en fuentes originales los datos actuales, reglas legales/financieras, políticas y condiciones comerciales; no usar defaults históricos como datos vigentes. No rellenar ausentes con cero. Conservar contradicciones y reducir alcance/confianza. Compartir resultados y facts existentes; no repetir investigación innecesaria.

## Stop conditions y escenarios de falla

Identidad incierta: resolver antes de conclusiones materiales. Dato crítico ausente: completar trabajo independiente y entregar faltantes; no fabricar números. Fuente bloqueada: registrar cobertura y alternativa legítima; no evadir controles. Tool no disponible: entregar archivo/spec o resultado parcial comprobable. Acción externa fuera del alcance: preparar resultado revisable y solicitar autorización solo para esa acción. Datos sensibles: mantener archivos privados y limitar salida al propósito autorizado. No enviar mensajes a terceros por el hecho de generar un borrador.

## Validation / Quality gate

Comprobar que el output responde al modo; inputs y fuentes tienen identidad/periodo correctos; cálculos y definiciones son reproducibles; límites y contradicciones son visibles; no se inventaron capacidades ni ejecución. Usar PASS, PASS_WITH_LIMITATIONS o BLOCKED; explicar cualquier bloqueo material. Aplicar Fair Housing y privacidad a housing, targeting y datos de clientes. No prometer ingresos, aprobaciones, appreciation ni resultados. Usar las Skills del formato para artefactos y revisar su render/apertura. Los artefactos se guardan por el flujo persistente disponible, salvo código sincronizado o imágenes con guardado nativo.

## Output

Campaign kit, policy/claim ledger, form, creative brief, tracking y test plan.

## KPIs

CPL, qualified-lead cost, appointment/show, adquisición y política QA; métricas públicas no equivalen a ROI. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.
