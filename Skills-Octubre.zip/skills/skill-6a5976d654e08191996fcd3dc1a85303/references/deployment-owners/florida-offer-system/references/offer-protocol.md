# Protocolo Florida Offer

## Fuente y alcance

Integrar la lógica revisada de Florida_SkySlope_Offer_Agent_SKILL.pdf, v1.0.0, consultada 3 octubre 2026. Preservar Agent Profile separado de Transaction Data. No codificar identidad, brokerage, escrow, fechas, términos económicos ni versión de contrato. No afirmar equivalencia con Michael Offer GPT hasta disponer de prompt y casos históricos.

## Estados por dato

CONFIRMED, CALCULATED, IMPORTED_UNVERIFIED, MISSING, AMBIGUOUS, NOT_APPLICABLE, NEEDS_HUMAN_REVIEW. Registrar valor original, valor normalizado, source, timestamp, estado y aprobación. Insertar solo valores CONFIRMED o importados verificados por fuente autorizada. Un cálculo se muestra para revisión; no reemplaza un término contractual confirmado.

## Scope y bloqueos

Soportar Florida residential buyer-side, single family/townhouse apropiados, cash/conventional/FHA/VA, HOA/CDD, seller contribution y ocupación normal at closing. Condo/cooperative/land/commercial/5+units/seller financing/assumption/lease option/short sale/probate/foreclosure/post-closing/pre-closing/unusual assignment requieren workflow especializado y revisión humana. No elegir un form sustituto por su parecido.

## Intake

Agent: legal name, brokerage, Florida license, email, phone.
Property: address, city/state/ZIP/county, MLS si disponible, parcel/legal description verificados, year/type/HOA/CDD.
Parties: buyer legal names, entity y vesting cuando aplique; seller identity/import plan y resolución de contradicciones.
Economic: price, financing, initial deposit y mecánica exacta del deadline, additional deposit o NOT_APPLICABLE, loan amount/LTV y approval period cuando aplica, contributions con wording confirmado.
Contract: escrow/closing agent/title company sin asumir que coinciden; closing, inspection period, occupancy, expiration exacta con hora/zona, included/excluded personal property, warranty, buyer-property contingency, otras contingencias/additional terms.

Normalizar formato obvio; no corregir silenciosamente Lakelando, nombres ni artículos mal escritos que alteren contrato. Resolver tomorrow/Friday a fecha/hora exacta y confirmar. No imponer defaults contractuales sin decisión explícita. FHA y VA no implican lender approval, appraisal ni entitlement conocidos.

## Paquete documental

Siempre: CURRENT FR/BAR AS IS autorizado en SkySlope.
FHA/VA: identificar current applicable rider; multiple matches requiere revisión.
Conventional/cash: no agregar financing rider FHA/VA.
HOA YES: disclosure aplicable y términos confirmados; UNKNOWN no equivale NO.
CDD YES: mecanismo/documento autorizado, sin inventar distrito o assessment; verificar si está en tax bill.
Lead: most pre-1978 housing, con excepciones que requieren verificación. Año <1978: evaluar disclosure y materiales exigibles; >=1978 no activa obligación por año solamente. Si año está ambiguo o contradice records, NEEDS_HUMAN_REVIEW. No contestar conocimiento/records del seller ni renunciar a inspección en nombre de buyer.

Verificación pública EPA 3 octubre 2026: https://www.epa.gov/lead/real-estate-disclosures-about-potential-lead-hazards (actualizada 27 mayo 2026). La EPA excluye vivienda construida después de 1977. Este dato corrige la ambigüedad de year==1978 del PDF. Verificar de nuevo antes de uso real. Las versiones de FR/BAR/riders se comprueban dentro del catálogo autorizado; su página pública de descripciones exige acceso de miembro, así que esta consolidación no certifica una edición.

## Secuencia de preparación y confirmación

1. Validar intake y preparar OFFER_SUMMARY + checklist antes de acciones en SkySlope.
2. Mostrar exactamente propiedad, partes, precio, financiación, depósitos/deadlines, escrow, inspección, closing, contribution, personal property, occupancy, contingencias, expiration y riders.
3. Si la instrucción actual confirma inequívocamente esos términos y autoriza preparar, conservar evidencia y proceder. En otro caso obtener confirmación de ese resumen concreto. Silencio no confirma.
4. Usar sesión autorizada del agente; no pedir credenciales por chat ni sustituir cuentas. Verificar la integración/browser disponible según su protocolo vigente.
5. Crear/abrir transacción sin duplicarla; verificar MLS import sin sobrescribir términos.
6. Seleccionar forms corrientes y completar confirmados.
7. Comparar FIELD/EXPECTED/ACTUAL/RESULT (MATCH/MISMATCH/MISSING/NEEDS_REVIEW). Repetir independentemente nombres, address, price, financing, loan/deposit/deadlines, approval period, inspection, closing, contribution, expiration, property items, clauses y riders.
8. Corregir mismatch solo desde Offer Object confirmado. Verificar package y guardar.
9. Devolver READY_FOR_AGENT_REVIEW cuando no hay critical mismatch/document faltante; en otro caso DRAFT_INCOMPLETE. Siempre indicar si solo existe paquete local y no SkySlope.

Prohibido: sign, imitate signature, Send, Submit, Request Signature, email offer, deliver to listing agent o cambiar términos sustantivos. La consolidación no autoriza ninguna transacción real.

## Reanudación, interfaz y audit log

Detectar probable draft duplicado por MLS/address/buyer antes de crear. Si existe, comprobar identidad y autorización para abrirlo; si no puede resolverse, presentar la decisión concreta, sin crear otro. Resolver controles por labels/form name/field association/document title, nunca por posición aproximada. Un campo no identificable bloquea ese paso. Sesión expirada/MFA requiere handoff autorizado; no almacenar passwords/cookies y continuar desde el último checkpoint verificable.

Guardar eventos INTAKE_RECEIVED, MISSING_DATA_REQUESTED, TERMS_CONFIRMED, SKYSLOPE_OPENED, PROPERTY_IMPORTED, CONTRACT_SELECTED, DOCUMENTS_ADDED, CONTRACT_COMPLETED, AUDIT_STARTED, AUDIT_PASSED/AUDIT_FAILED, SAVED, READY_FOR_AGENT_REVIEW. No incluir secretos. Aceptar intake completo por chat/Telegram/form y preguntar solo faltantes o ambigüedades; no implementar integración ni credenciales por asumir que hay un formulario.
