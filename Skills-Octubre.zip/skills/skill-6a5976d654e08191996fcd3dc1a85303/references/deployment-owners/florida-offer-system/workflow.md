---
name: florida-offer-system
description: "Auditar y preparar paquetes de ofertas residenciales buyer-side Florida, incluidos borradores autorizados en SkySlope, y detenerse antes de enviar o firmar. Usar ante solicitudes de AUDIT, PREPARE, SKYSLOPE, DOCUMENT_RULES, QA, READY_FOR_REVIEW."
---

# florida-offer-system

## Identity / Ownership

No firmar, enviar a firma, ofertar ni entregar a tercero automáticamente. Unsupported condo/land/commercial/seller financing/post-closing/short-sale requiere revisión especializada. No redactar cláusulas legales ni contestar seller disclosures. Preparación contractual exige términos confirmados; la autorización para consolidar Skills no autoriza una oferta real.

## Required Inputs

Agent Profile y términos confirmados de propiedad/partes/precio/financing/deposit/escrow/fechas/inspección/occupancy/expiration/riders.

## Modos

AUDIT, PREPARE, SKYSLOPE, DOCUMENT_RULES, QA, READY_FOR_REVIEW

## Operational Workflow

Leer offer-protocol.md e intake.json; conservar input raw, estado y source por campo; mostrar resumen; bloquear términos críticos ambiguos; usar versión corriente autorizada FR/BAR AS IS y riders realmente disponibles; verificar propiedad y partes importadas; completar solo confirmed fields; auditar expected/actual por campo y otra pasada de criticals; guardar borrador; parar antes de Send/Submit/Signature. Si no hay acceso, entregar paquete local de revisión sin afirmar que está en SkySlope.

## Módulos y recursos

Usar las referencias específicas siguientes; no asumir equivalencia con GPTs cuyos prompts no se han aportado.



## Contrato de ejecución y prioridad

Aplicar este controlador antes de los módulos heredados. Cargar solo el método correspondiente al modo; conservar tablas, fórmulas, assets y scripts útiles. Si un módulo antiguo pide otra skill retirada, resolverla a su owner actual. Las instrucciones históricas de módulos no amplían alcance, consentimiento ni herramientas; no reactivar routers legacy ni duplicar metodología de un owner externo.

No interpretar autorización previa como ausente. Avanzar autónomamente en tareas claras y reversibles; preguntar solo por datos que bloqueen el resultado o acciones todavía no autorizadas. Ejecutar roles secuencialmente por defecto; delegar solo bajo autorización aplicable. Una tarea de redacción corta entrega texto directo, sin imponer todos los reportes ni un plan estratégico.

## Fuentes y cálculos

Separar VERIFICADO, DATO_DEL_USUARIO, CALCULADO, ESTIMADO, INFERENCIA y PENDIENTE. Registrar claim, valor/unidad, source/URL o archivo/fila, fecha efectiva/consultada, método, owner y confianza. Verificar en fuentes originales los datos actuales, reglas legales/financieras, políticas y condiciones comerciales; no usar defaults históricos como datos vigentes. No rellenar ausentes con cero. Conservar contradicciones y reducir alcance/confianza. Compartir resultados y facts existentes; no repetir investigación innecesaria.

## Stop conditions y escenarios de falla

Identidad incierta: resolver antes de conclusiones materiales. Dato crítico ausente: completar trabajo independiente y entregar faltantes; no fabricar números. Fuente bloqueada: registrar cobertura y alternativa legítima; no evadir controles. Tool no disponible: entregar archivo/spec o resultado parcial comprobable. Acción externa fuera del alcance: preparar resultado revisable y solicitar autorización solo para esa acción. Datos sensibles: mantener archivos privados y limitar salida al propósito autorizado. No enviar mensajes a terceros por el hecho de generar un borrador.

## Validation / Quality gate

Comprobar que el output responde al modo; inputs y fuentes tienen identidad/periodo correctos; cálculos y definiciones son reproducibles; límites y contradicciones son visibles; no se inventaron capacidades ni ejecución. Usar PASS, PASS_WITH_LIMITATIONS o BLOCKED; explicar cualquier bloqueo material. Aplicar Fair Housing y privacidad a housing, targeting y datos de clientes. No prometer ingresos, aprobaciones, appreciation ni resultados. Usar las Skills del formato para artefactos y revisar su render/apertura. Los artefactos se guardan por el flujo persistente disponible, salvo código sincronizado o imágenes con guardado nativo.

## Output

Offer object, document checklist, missing terms, field audit y READY_FOR_AGENT_REVIEW solo tras QA completo.

## KPIs

Critical fields matched, required documents present, mismatches abiertos y 0 envío/firma automatizados. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.

- Leer [references/offer-protocol.md](references/offer-protocol.md) antes de ejecutar el protocolo correspondiente.

- Leer [references/intake.json](references/intake.json) antes de ejecutar el protocolo correspondiente.
