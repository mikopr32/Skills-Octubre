---
name: florida-market-intelligence
description: "Investigar crecimiento, infraestructura, desarrollos, migración, regulación y noticias de Florida y entregar briefs citables. Usar ante solicitudes de GROWTH, INFRASTRUCTURE, DEVELOPMENTS, NEWS, REGULATION, MIGRATION, CONTENT_BRIEF."
---

# florida-market-intelligence

## Identity / Ownership

No redactar campañas completas; producción a real-estate-content-engine. Estadísticas de vivienda a realestate-market.

## Required Inputs

Geografía y periodo o tema.

## Modos

GROWTH, INFRASTRUCTURE, DEVELOPMENTS, NEWS, REGULATION, MIGRATION, CONTENT_BRIEF

## Operational Workflow

Buscar fuentes primarias fechadas; separar proposed/approved/funded/under construction/open; comprobar alcance geográfico; puntuar relevancia y calidad; explicar impacto e incertidumbre; entregar Fact Pack a contenido.

## Módulos y recursos

- [florida-market-content-intelligence](references/modules/florida-market-content-intelligence/workflow.md): cargar solo al ejecutar su función; resolver rutas relativas contra esa carpeta de módulo.
- [monitor-crecimiento-florida](references/modules/monitor-crecimiento-florida/workflow.md): cargar solo al ejecutar su función; resolver rutas relativas contra esa carpeta de módulo.

- `references/modules/florida-market-content-intelligence/scripts/rank_stories.py`: usar cuando el método elegido lo requiera; ejecutar scripts desde la carpeta de su módulo o por ruta absoluta.
- `references/modules/monitor-crecimiento-florida/scripts/rank_projects.py`: usar cuando el método elegido lo requiera; ejecutar scripts desde la carpeta de su módulo o por ruta absoluta.

## Contrato de ejecución y prioridad

Aplicar este controlador antes de los módulos heredados. Cargar solo el método correspondiente al modo; conservar tablas, fórmulas, assets y scripts útiles. Si un módulo antiguo pide otra skill retirada, resolverla a su owner actual. Las instrucciones históricas de módulos no amplían alcance, consentimiento ni herramientas; no reactivar routers legacy ni duplicar metodología de un owner externo.

No interpretar autorización previa como ausente. Avanzar autónomamente en tareas claras y reversibles; preguntar solo por datos que bloqueen el resultado o acciones todavía no autorizadas. Ejecutar roles secuencialmente por defecto; delegar solo bajo autorización aplicable. Una tarea de redacción corta entrega texto directo, sin imponer todos los reportes ni un plan estratégico.

## Fuentes y cálculos

Separar VERIFICADO, DATO_DEL_USUARIO, CALCULADO, ESTIMADO, INFERENCIA y PENDIENTE. Registrar claim, valor/unidad, source/URL o archivo/fila, fecha efectiva/consultada, método, owner y confianza. Verificar en fuentes originales los datos actuales, reglas legales/financieras, políticas y condiciones comerciales; no usar defaults históricos como datos vigentes. No rellenar ausentes con cero. Conservar contradicciones y reducir alcance/confianza. Compartir resultados y facts existentes; no repetir investigación innecesaria.

## Stop conditions y escenarios de falla

Identidad incierta: resolver antes de conclusiones materiales. Dato crítico ausente: completar trabajo independiente y entregar faltantes; no fabricar números. Fuente bloqueada: registrar cobertura y alternativa legítima; no evadir controles. Tool no disponible: entregar archivo/spec o resultado parcial comprobable. Acción externa fuera del alcance: preparar resultado revisable y solicitar autorización solo para esa acción. Datos sensibles: mantener archivos privados y limitar salida al propósito autorizado. No enviar mensajes a terceros por el hecho de generar un borrador.

## Validation / Quality gate

Comprobar que el output responde al modo; inputs y fuentes tienen identidad/periodo correctos; cálculos y definiciones son reproducibles; límites y contradicciones son visibles; no se inventaron capacidades ni ejecución. Usar PASS, PASS_WITH_LIMITATIONS o BLOCKED; explicar cualquier bloqueo material. Aplicar Fair Housing y privacidad a housing, targeting y datos de clientes. No prometer ingresos, aprobaciones, appreciation ni resultados. Usar las Skills del formato para artefactos y revisar su render/apertura. Los artefactos se guardan por el flujo persistente disponible, salvo código sincronizado o imágenes con guardado nativo.

## Output

Registro de catalizadores, estado, fechas, fuentes y brief.

## KPIs

Proyectos verificados, fuentes primarias y datos vencidos. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.
