#!/usr/bin/env python3
"""Preliminary Fetch + same-community sold-MLS screen; no debt or net invention."""
import argparse,csv,json,re,calendar,math,statistics
from pathlib import Path
from datetime import date,datetime

ALIASES={
 'owner':['owner','owner name','ownername'], 'address':['property address','address','propertyaddress','street address'],
 'apn':['apn','parcel id','tax id','parcel number'], 'purchase_price':['purchase price','sale price','last sale price'],
 'purchase_date':['purchase date','sale date','last sale date'], 'sold_price':['sold price','close price','sale price','soldprice'],
 'sold_date':['sold date','close date','closing date','sale date'], 'sqft':['living area','living area sqft','square footage','sqft','heated area','heated area sqft'],
 'type':['property type','type','propertytype'], 'community':['subdivision','subdivision name','community'],
 'mailing':['mailing address','mailingaddress'], 'pool':['pool','private pool'],
}
def key(s): return re.sub(r'[^a-z0-9]','',str(s or '').lower())
def money(s):
    if s is None or str(s).strip()=='': return None
    t=str(s).strip();negative=t.startswith('-') or (t.startswith('(') and t.endswith(')'))
    try: v=float(re.sub(r'[$,()\s]','',t));return -abs(v) if negative else v
    except ValueError:return None
def dt(s):
    for fmt in ('%Y-%m-%d','%m/%d/%Y','%m/%d/%y','%Y/%m/%d','%m-%d-%Y'):
        try:return datetime.strptime(str(s or '').strip(),fmt).date()
        except ValueError:pass
    return None
def safe(v):
    s='' if v is None else str(v)
    return "'"+s if s.lstrip().startswith(('=','+','-','@')) else s
def load(path,overrides=None):
    with Path(path).open(encoding='utf-8-sig',newline='') as f:
        sample=f.read(4096);f.seek(0)
        try:dialect=csv.Sniffer().sniff(sample,delimiters=',;\t|')
        except csv.Error:dialect=csv.excel
        rd=csv.DictReader(f,dialect=dialect);headers=rd.fieldnames or [];rows=list(rd)
    mapping={};ambiguities={}
    for target,aliases in ALIASES.items():
        if overrides and target in overrides:
            if overrides[target] not in headers:raise ValueError('Mapped header missing: '+target)
            mapping[target]=overrides[target];continue
        matches=[h for h in headers if key(h) in {key(v) for v in aliases}]
        if len(matches)==1:mapping[target]=matches[0]
        elif len(matches)>1:ambiguities[target]=matches
    if ambiguities:raise ValueError('Ambiguous headers: '+json.dumps(ambiguities))
    return rows,mapping
def percentile(v,values):
    if v is None or not values:return 0
    return (sum(x<v for x in values)+0.5*sum(x==v for x in values))/len(values)
def screen(fetch,fetch_map,sold,sold_map,community,as_of,scope_confirmed=False,min_comps=3):
    start=date(as_of.year-1,as_of.month,min(as_of.day,calendar.monthrange(as_of.year-1,as_of.month)[1]))
    if not community:raise ValueError('Community required')
    for m,required in ((fetch_map,['address','purchase_price']),(sold_map,['sold_price','sold_date','sqft','type'])):
        absent=set(required)-set(m)
        if absent:raise ValueError('Critical columns missing: '+str(sorted(absent)))
        if 'community' not in m and not scope_confirmed:raise ValueError('Verify community scope or provide community column')
    get=lambda raw,m,k:raw.get(m.get(k,''),'')
    comps=[];excluded=[];seen_comps=set()
    for i,raw in enumerate(sold,2):
        d=dt(get(raw,sold_map,'sold_date'));price=money(get(raw,sold_map,'sold_price'));area=money(get(raw,sold_map,'sqft'));typ=key(get(raw,sold_map,'type'))
        reason=None
        if not d or not start<=d<=as_of:reason='OUTSIDE_WINDOW_OR_INVALID_DATE'
        elif 'community'in sold_map and key(get(raw,sold_map,'community'))!=key(community):reason='OTHER_COMMUNITY'
        elif not price or price<=0 or not area or area<=0 or not typ:reason='MISSING_OR_INVALID_COMP_DATA'
        ident=key(get(raw,sold_map,'apn')) or key(get(raw,sold_map,'address'))
        dup=(ident,d,price) if ident else None
        if not reason and dup and dup in seen_comps:reason='DUPLICATE_SALE'
        if reason:excluded.append({'source_row':i,'reason':reason});continue
        if dup:seen_comps.add(dup)
        comps.append({'row':i,'date':d,'price':price,'area':area,'type':typ,'identity':ident,'pool':key(get(raw,sold_map,'pool'))})
    out=[];identities={}
    for i,raw in enumerate(fetch,2):
        flags=[];ident=key(get(raw,fetch_map,'apn')) or key(get(raw,fetch_map,'address'))
        duplicate=identities.get(ident) if ident else None
        if ident and not duplicate:identities[ident]=i
        if duplicate:flags.append('DUPLICATE_PROPERTY;FIRST_ROW='+str(duplicate))
        in_scope='community' not in fetch_map or key(get(raw,fetch_map,'community'))==key(community)
        if not in_scope:flags.append('OTHER_COMMUNITY')
        area=money(get(raw,fetch_map,'sqft'));purchase=money(get(raw,fetch_map,'purchase_price'));typ=key(get(raw,fetch_map,'type'));pool=key(get(raw,fetch_map,'pool'))
        if purchase is None or purchase<=0:flags.append('PURCHASE_PRICE_UNUSABLE');purchase=None
        eligible=[]
        if in_scope and ident and area and area>0 and typ:
            eligible=[c for c in comps if c['type']==typ and 0.8*area<=c['area']<=1.2*area and c['identity']!=ident and (not pool or not c['pool'] or pool==c['pool'])]
        else:flags.append('SUBJECT_SPECS_OR_IDENTITY_INCOMPLETE')
        value=None;low=None;high=None
        if len(eligible)>=min_comps:
            indications=sorted(c['price']/c['area']*area for c in eligible)
            value=statistics.median(indications);low=min(indications);high=max(indications)
        else:flags.append('INSUFFICIENT_COMPARABLE_SALES')
        appreciation=None if value is None or purchase is None else value-purchase
        confidence='MEDIUM' if value is not None else 'NOT_EVALUABLE'
        # No inspection/condition verification; this algorithm never declares high confidence.
        sale_date=dt(get(raw,fetch_map,'purchase_date'));years=None if not sale_date or sale_date>as_of else (as_of-sale_date).days/365.2425
        if get(raw,fetch_map,'purchase_date') and years is None:flags.append('PURCHASE_DATE_UNUSABLE')
        mailing=key(get(raw,fetch_map,'mailing'));address=key(get(raw,fetch_map,'address'))
        absentee='POSSIBLE' if mailing and address and mailing!=address else 'NOT_INDICATED' if mailing and address else 'PENDING'
        row={'Source_Row_ID':i,'Owner':get(raw,fetch_map,'owner'),'Property_Address':get(raw,fetch_map,'address'),'APN':get(raw,fetch_map,'apn'),
             'Purchase_Price':purchase,'Estimated_Value_Low':low,'Estimated_Value_Base':value,'Estimated_Value_High':high,'Potential_Appreciation':appreciation,
             'Mortgage_Balance':'PENDING','Real_Equity':'PENDING','Net_Seller_Proceeds':'PENDING','Years_Owned':years,'Absentee_Signal':absentee,
             'Confidence':confidence,'Comp_Source_Row_IDs':';'.join(str(c['row']) for c in eligible),'Comp_Count':len(eligible),'Property_Opportunity':'PENDING','Flags':';'.join(flags),
             'Priority_Score':None,'Score_Reasons':'','Value_Method':'PRELIMINARY_MEDIAN_SOLD_PPSF;condition/bed/bath/year/lots not adjusted'}
        out.append(row)
    candidates=[r['Potential_Appreciation'] for r in out if r['Potential_Appreciation'] is not None and 'DUPLICATE_PROPERTY' not in r['Flags']]
    for row in out:
        if row['Potential_Appreciation'] is not None:
            proxy=45*percentile(row['Potential_Appreciation'],candidates)
            # Signals are hypotheses, not seller intent. No points for unknown opportunity.
            signals=(10 if row['Years_Owned'] is not None and row['Years_Owned']>=10 else 0)+(10 if row['Absentee_Signal']=='POSSIBLE' else 0)
            row['Priority_Score']=round(proxy+signals+9,2)
            row['Score_Reasons']=f'Appreciation proxy={proxy:.2f}/45;ownership={signals}/20;property opportunity=0/20 pending;confidence=9/15 preliminary'
    ranked=sorted([r for r in out if r['Priority_Score'] is not None and 'DUPLICATE_PROPERTY' not in r['Flags']],key=lambda r:(-r['Priority_Score'],-r['Potential_Appreciation'],r['Source_Row_ID']))
    summary={'as_of':str(as_of),'community':community,'window_start':str(start),'fetch_rows':len(fetch),'reconciled_rows':len(out),'unique_properties':len(identities),'eligible_sold_comps':len(comps),'sold_exclusions':excluded,
             'ranked_unique_properties':len(ranked),'unknown_debt_rows':len(out),'ranking_method':'APPRECIATION_PROXY_NOT_REAL_EQUITY','limitations':['Same-type +/-20% living area PPSF screen','Unadjusted condition/beds/baths/year/lot','Observed range is not a statistical confidence interval','No current mortgage, real equity or net inferred']}
    assert len(out)==len(fetch)
    return out,ranked,summary

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--fetch',required=True);p.add_argument('--sold',required=True);p.add_argument('--community',required=True);p.add_argument('--as-of',required=True);p.add_argument('--output-dir',required=True);p.add_argument('--column-map');p.add_argument('--scope-confirmed',action='store_true');p.add_argument('--min-comps',type=int,default=3)
    a=p.parse_args()
    if a.min_comps<3:raise ValueError('At least3 comps required for automated estimate')
    maps=json.loads(Path(a.column_map).read_text()) if a.column_map else {}
    f,fm=load(a.fetch,maps.get('fetch'));s,sm=load(a.sold,maps.get('sold'))
    all_rows,ranked,summary=screen(f,fm,s,sm,a.community,date.fromisoformat(a.as_of),a.scope_confirmed,a.min_comps)
    target=Path(a.output_dir);target.mkdir(parents=True,exist_ok=False)
    for filename,rows in [('All_Properties_Reconciled.csv',all_rows),('Priority_List.csv',ranked)]:
        with (target/filename).open('w',encoding='utf-8-sig',newline='') as h:
            writer=csv.DictWriter(h,fieldnames=list(all_rows[0]) if all_rows else ['Source_Row_ID']);writer.writeheader();writer.writerows({k:safe(v) for k,v in row.items()} for row in rows)
    (target/'Audit.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2))
