# Equity Farming: Fetch + MLS12 meses

## Inputs y auditoría

Fetch farming completo de la subdivisión + ventas cerradas MLS últimos12 meses de la misma subdivisión, tal como se exportan. No exigir payoff para screening; no exigir limpieza al usuario. Usar Spreadsheets para XLSX/CSV y mapear Purchase Price/Purchase Date, Owner, APN, Address, living area/type/beds/baths/pool/year; MLS sold date/price, identidad y specs. Verificar la subdivisión legal y scope, no solo nombre comercial.

Auditar filas, campos faltantes, formats, units, transferrals/no-arm-length, duplicados y conflictos. Registrar original row IDs y reconcile todos los propietarios, incluyendo no evaluables. Priorizar APN; address canónica conserva unidad. Ventas fuera de ventana o comunidad no entran como comps sin decisión explícita y degradación de confianza.

## Estimación y etiquetas

Usar sold comps comparables por tipo y specs; explicar inclusión y ajustes. Valores son preliminares de screening, no CMA formal. Escaso comp set, missing sqft/type/condition o purchase price dudoso reducen confianza. No inferir condición o remodel de fotos si no hay evidencia. Valor histórico de compra sirve para comparar, no es deuda. Formal valuation al owner CMA.

`Potential_Appreciation = Estimated_Market_Value - Purchase_Price`.
`Real_Equity = Estimated_Market_Value - Verified_Current_Debt - Verified_Liens`, solo si existen deuda/liens confirmados y evitar presentar equity verificado cuando valor es estimado.
`Net_Seller_Proceeds = sale_price_scenario - payoff - liens - confirmed selling costs - concessions - repairs/credits`, solo con inputs suficientes y sin doble conteo.

Si faltan balances/costos, mostrar PENDIENTE. No fabricar balances con LTV, tasa, plazo, mortgage original ni amortización supuesta. No estimar tasas/rentas/HELOC/closing costs como hechos. Si el usuario pide un escenario hipotético, separarlo de lista de propietarios y no usarlo como balance real.

## Ranking

Priorizar primero oportunidades evaluables y calidad de datos; usar Potential_Appreciation como proxy claramente rotulado cuando no hay payoff. Combinar percentiles de appreciation45, ownership signals20, property opportunity documentada20 y confidence15. No asignar15/20 de property opportunity sin señal; falta de dato no demuestra ausencia ni baja motivación. Registrar pesos/componentes y tratar umbrales como propuesta. Contactabilidad no decide ranking patrimonial. Con equity/neto documentados se puede reemplazar proxy, declarando nueva versión y rubric.

## Entrega

Lista TopN con owner/property identity privada, Purchase Price/date, value Low/Base/High, comp IDs, appreciation proxy, equity/neto pendientes o calculados con base documentada, ownership signals, property signals, confidence, score reasons, próximo dato por verificar. Incluir universo completo reconciliado, exclusions, audit y fuentes. No automatizar contacto. Usar el módulo LEAD_LIST solo para contactabilidad y supresión; desactivar su cálculo legado de deuda.
