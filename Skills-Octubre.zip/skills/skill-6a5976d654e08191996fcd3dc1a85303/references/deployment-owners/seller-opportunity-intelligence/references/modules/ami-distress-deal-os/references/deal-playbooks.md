# Playbooks de ruta

## Urgent legal-stage review

Confirmar fecha/estado de sale el mismo día. No prometer detenerla. Escalar inmediatamente a abogado y, si el propietario busca conservar, a servicer/HUD-approved counselor. Limitar el análisis inmobiliario a opciones y documentos autorizados.

## Home retention resource review

Usar solo cuando el propietario exprese intención de conservar. Organizar preguntas y documentos, compartir recursos legítimos y separar claramente Realtor, counselor, servicer y abogado. No recomendar una opción específica de loss mitigation.

## Traditional sale possibility

Validar title, payoff y net sheet; completar CMA, estrategia de precio, condición, timeline y listing readiness. Confirmar que el neto conservador cubre obligaciones conocidas.

## Short sale assessment

Exigir consentimiento, servicer, tipo de préstamo, payoff/title, déficit sustentado y tiempo razonable. Crear checklist, document tracker, offer/net analysis y communication log. No redactar hardship falso ni garantizar waiver, approval o relocation assistance.

## Investor due diligence

Calcular ARV, repairs range, holding/selling costs, MAO, rental/DSCR cuando aplique y sensibilidad. Exigir inspection, title y buyer proof before recommendation. Distinguir Realtor representation de principal/investor interest.

## REO or auction buyer review

Confirmar owner/title y términos de sale. Analizar occupancy, redemption/objection risks cuando corresponda mediante abogado, liens que puedan sobrevivir, access, repairs y funding deadlines. No llamar REO a una propiedad sin title transfer.

## Priority conditioned

Listar máximo tres datos que desbloquean la decisión, responsable, fuente y fecha límite. No invertir más investigación hasta obtenerlos salvo cambio de plazo.

## Watchlist y low priority

Definir trigger específico: nuevo filing, judgment, auction, tax deed, price change o segunda señal. No nutrir automáticamente con mensajes invasivos.

## Exclude

Registrar razón, evidencia y fecha: resuelto, vendido, duplicado, fuera de ventana, identidad incorrecta, sin margen, no residencial o acceso insuficiente.
