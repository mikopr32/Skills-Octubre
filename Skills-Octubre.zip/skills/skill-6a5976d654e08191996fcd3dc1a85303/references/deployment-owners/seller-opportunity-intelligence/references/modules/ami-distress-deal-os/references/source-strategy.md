# Estrategia de fuentes

## Jerarquía

1. Fuente oficial primaria y documento original.
2. Docket, recorded instrument o dataset oficial.
3. Fuente pública secundaria que enlaza al registro.
4. MLS autorizado o portal público permitido.
5. Snippet de buscador solo para descubrimiento.

No usar snippets como prueba final si existe el registro oficial.

## Registro mínimo por condado

- Clerk/Court: civil cases, foreclosure docket y sale calendar.
- Official Records/Recorder: lis pendens, mortgages, assignments, releases, liens, judgments y deeds.
- Tax Collector: delinquency, certificates y tax deeds.
- Property Appraiser: parcel, characteristics, owner of record, last sale y assessed data.
- County/municipal: code enforcement, unsafe structures, nuisance y permits.
- Market: MLS autorizado, public short-sale/REO/auction sources permitidas.

## Consultas de descubrimiento

- `{county} Florida clerk foreclosure case search`
- `{county} official records lis pendens`
- `{county} foreclosure sale calendar`
- `{county} delinquent property taxes tax deed`
- `{county} property appraiser parcel search`
- `{county} code enforcement building permits`
- `{county} short sale REO auction`

## Acceso y cobertura

- Preferir CSV/XLS/PDF oficial.
- Automatizar solo acceso público permitido y conservar URL/fecha.
- Usar consultas individuales para verificación, no para afirmar cobertura masiva.
- Ante CAPTCHA, login, fee o prohibición, marcar `blocked` y continuar.
- Etiquetar `bulk`, `searchable`, `verification_only` o `blocked`.

## Valor y deuda

- Estimar valor con ventas cerradas comparables; assessed value no es market value.
- Tratar listing price como competencia, no como prueba de valor.
- Mortgage registrado es monto original, no payoff.
- Estimar balance solo si monto, fecha, plazo y tasa tienen sustento; documentar fórmula y rango.
- Si faltan payoff o liens completos, reportar equity como rango o `unknown`.

## Privacidad y contacto

Usar datos personales solo si existe fuente legítima y propósito permitido. No incorporar protected classes al scoring. Separar investigación del contacto; antes de campañas revisar consentimiento, DNC/TCPA/FTSA y políticas del brokerage. La skill no ejecuta cold outreach automatizado.
