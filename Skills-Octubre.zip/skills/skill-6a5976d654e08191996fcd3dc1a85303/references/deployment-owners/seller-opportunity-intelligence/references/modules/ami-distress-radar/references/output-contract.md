# Contrato de salida

## Reporte ejecutivo

Incluir condado, estado, ventana, fecha, cobertura, fuentes bloqueadas, registros revisados, candidatos únicos, prioridades, watchlist, descartes, señales predominantes, top candidatos, riesgos, límites y plan de 48 horas.

## CSV de prioridad

Una fila por propiedad con identidad, etapa, fechas, scores, confianza, ruta, razón, próxima acción, fuentes y última verificación.

## Dossier

Para cada prioridad alta incluir identidad, resumen, timeline, hechos, inferencias, cálculos, desconocidos, valor/deuda/equity preliminar, riesgo de plazo, ruta principal y alternativa, evidencia y condición para escalar o descartar.

## Descartes

Mostrar identidad, señal inicial, evidencia de descarte, fecha y fuente. Nunca eliminar candidatos silenciosamente.
