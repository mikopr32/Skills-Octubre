# Contrato de datos canónico

Usar UTF-8 y fechas ISO `YYYY-MM-DD`. Un registro representa una propiedad consolidada.

## Campos

- Identidad: `candidate_id`, `county`, `parcel_id`, `address`, `city`, `state`, `zip`, `owner_record_name`.
- Legal: `legal_stage`, `case_number`, `filing_date`, `auction_date`, `case_status`.
- Financiero/municipal: `tax_delinquent`, `tax_balance`, `tax_deed`, `liens_count`, `hoa_lien`, `code_violation`, `unsafe_structure`, `open_permit_issue`.
- Mercado: `listing_status`, `list_price`, `original_price`, `dom`, `price_reductions`, `short_sale_text`, `third_party_approval`, `reo_text`, `condition_signal`.
- Valor/deuda: `estimated_value`, `value_source`, `recorded_mortgage_amount`, `estimated_debt`, `debt_is_estimate`, `known_liens_amount`, `estimated_selling_costs`, `estimated_net_equity`.
- Evidencia: `official_source_count`, `independent_source_count`, `source_urls`, `last_verified`, `verification_status`, `data_conflicts`, `missing_critical_fields`.
- Resultado: `distress_score`, `viability_score`, `confidence`, `route`, `priority_reason`, `next_action`, `exclusion_reason`.

Valores de `legal_stage`: `none`, `lis_pendens`, `complaint`, `final_judgment`, `auction_scheduled`, `sold_auction`, `reo`, `tax_deed`, `hoa_foreclosure`, `dismissed`, `released`, `unknown`.

Usar vacío para desconocido. No convertir desconocido en cero o `false`.
