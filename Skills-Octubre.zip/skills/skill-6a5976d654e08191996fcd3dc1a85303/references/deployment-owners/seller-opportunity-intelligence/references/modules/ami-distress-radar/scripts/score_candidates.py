#!/usr/bin/env python3
"""Score canonical AMI Distress Radar CSV records using transparent rules."""

import argparse
import csv
from datetime import date, datetime
from pathlib import Path

TRUE_VALUES = {"1", "true", "yes", "y", "si", "sí"}


def truthy(value):
    return str(value or "").strip().lower() in TRUE_VALUES


def number(value, default=0):
    try:
        return float(str(value or "").replace("$", "").replace(",", "").strip())
    except ValueError:
        return default


def days_until(value):
    if not value:
        return None
    try:
        return (datetime.strptime(value.strip(), "%Y-%m-%d").date() - date.today()).days
    except ValueError:
        return None


def score(row):
    stage = (row.get("legal_stage") or "none").strip().lower()
    legal = {"auction_scheduled": 35, "final_judgment": 30, "complaint": 25,
             "lis_pendens": 25, "tax_deed": 22, "hoa_foreclosure": 20,
             "reo": 18, "dismissed": 0, "released": 0}.get(stage, 0)

    financial = (10 if truthy(row.get("tax_delinquent")) else 0)
    financial += 12 if truthy(row.get("tax_deed")) else 0
    financial += 8 if truthy(row.get("hoa_lien")) else 0
    financial += min(int(number(row.get("liens_count"))) * 2, 8)
    value = number(row.get("estimated_value"))
    debt = number(row.get("estimated_debt"))
    liens = number(row.get("known_liens_amount"))
    costs = number(row.get("estimated_selling_costs"))
    negative_equity = value > 0 and debt > 0 and value - debt - liens - costs < 0
    financial = min(financial + (7 if negative_equity else 0), 25)

    status = (row.get("listing_status") or "").strip().lower()
    market = (15 if truthy(row.get("short_sale_text")) else 0)
    market += 12 if truthy(row.get("third_party_approval")) else 0
    market += 12 if truthy(row.get("reo_text")) else 0
    market += 6 if status in {"expired", "canceled", "cancelled", "withdrawn"} else 0
    market += 5 if status in {"back_on_market", "back on market"} else 0
    market += 5 if number(row.get("price_reductions")) >= 3 else 0
    market += 4 if number(row.get("dom")) >= 120 else 0
    market = min(market, 20)

    municipal = (8 if truthy(row.get("unsafe_structure")) else 0)
    municipal += 5 if truthy(row.get("code_violation")) else 0
    municipal += 4 if truthy(row.get("open_permit_issue")) else 0
    municipal += 3 if truthy(row.get("condition_signal")) else 0
    municipal = min(municipal, 10)

    official = int(number(row.get("official_source_count")))
    independent = int(number(row.get("independent_source_count")))
    conflicts = bool((row.get("data_conflicts") or "").strip())
    evidence = 0 if conflicts else (10 if official >= 1 and independent >= 2 else
                                    8 if official >= 1 else 3 if independent >= 1 else 0)
    distress = min(legal + financial + market + municipal + evidence, 100)

    viability = 20 if row.get("parcel_id") or row.get("address") else 0
    viability += 20 if value > 0 and row.get("value_source") else 0
    viability += 20 if debt > 0 or liens > 0 else 0
    auction_days = days_until(row.get("auction_date"))
    viability += 15 if auction_days is None or auction_days > 30 else 8 if auction_days >= 15 else 0
    viability += 15 if status or legal > 0 else 0
    viability += 10 if not conflicts and not truthy(row.get("unsafe_structure")) else 0
    viability -= 20 if auction_days is not None and auction_days <= 14 else 0
    viability -= 15 if conflicts else 0
    viability -= 15 if value <= 0 else 0
    viability -= 15 if debt <= 0 and liens <= 0 else 0
    viability = max(0, min(viability, 100))

    case_status = (row.get("case_status") or "").strip().lower()
    exclusion = ""
    if stage == "sold_auction" or case_status in {"sold", "transferred", "completed"}:
        route, exclusion = "exclude", "Property already sold or transferred"
    elif stage in {"dismissed", "released"} and distress < 40:
        route, exclusion = "exclude", "Primary distress event resolved"
    elif auction_days is not None and auction_days <= 14:
        route = "urgent legal-stage review"
    elif distress >= 75 and viability >= 50:
        short_sale_evidence = negative_equity and official >= 1 and independent >= 2 and bool(row.get("value_source"))
        route = ("short-sale assessment" if short_sale_evidence else
                 "priority conditioned" if negative_equity else
                 "traditional-sale possibility")
    elif distress >= 60 and viability >= 45:
        route = "priority conditioned"
    elif distress >= 40:
        route = "watchlist"
    else:
        route = "low priority"

    confidence = "high" if official >= 1 and independent >= 2 and not conflicts else "medium" if official >= 1 and not conflicts else "low"
    row.update(distress_score=str(distress), viability_score=str(viability),
               confidence=confidence, route=route, exclusion_reason=exclusion)
    return row


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input_csv", type=Path)
    parser.add_argument("output_csv", type=Path)
    args = parser.parse_args()
    with args.input_csv.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        rows = [score(dict(row)) for row in reader]
        fields = list(reader.fieldnames or [])
    for field in ["distress_score", "viability_score", "confidence", "route", "exclusion_reason"]:
        if field not in fields:
            fields.append(field)
    args.output_csv.parent.mkdir(parents=True, exist_ok=True)
    with args.output_csv.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


if __name__ == "__main__":
    main()
