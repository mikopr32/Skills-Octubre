# Contrato de datos canónico

Usar UTF-8 y fechas ISO `YYYY-MM-DD`. Un registro representa una propiedad consolidada. Usar vacío para desconocido; nunca convertir desconocido en cero o `false`.

## Identidad

`candidate_id`, `county`, `parcel_id`, `address`, `city`, `state`, `zip`, `owner_record_name`, `owner_name_source`, `property_type`, `occupancy_status`, `occupancy_is_inference`.

## Legal y timeline

`legal_stage`, `case_number`, `filing_date`, `judgment_date`, `auction_date`, `auction_status`, `case_status`, `dismissal_date`, `certificate_of_title_date`, `days_to_auction`.

Valores de `legal_stage`: `none`, `lis_pendens`, `complaint`, `final_judgment`, `auction_scheduled`, `sold_auction`, `reo`, `tax_deed`, `hoa_foreclosure`, `dismissed`, `released`, `unknown`.

## Fiscal, title y municipal

`tax_delinquent`, `tax_balance`, `tax_deed`, `mortgages_count`, `recorded_mortgage_amount`, `estimated_debt`, `debt_is_estimate`, `liens_count`, `known_liens_amount`, `hoa_lien`, `judgment_lien`, `municipal_lien`, `code_violation`, `unsafe_structure`, `open_permit_issue`, `title_conflict`.

## Mercado y condición

`listing_status`, `list_price`, `original_price`, `dom`, `segment_median_dom`, `price_reductions`, `short_sale_text`, `third_party_approval`, `reo_text`, `condition_signal`, `estimated_repairs_low`, `estimated_repairs_high`.

## Valor y equity

`value_low`, `value_base`, `value_high`, `value_source`, `value_as_of`, `estimated_selling_costs`, `net_equity_low`, `net_equity_base`, `net_equity_high`, `equity_is_estimate`, `payoff_received`, `title_search_received`.

## Consentimiento y operación

`seller_contacted`, `contact_basis`, `consent_status`, `seller_intent`, `authorized_documents`, `professional_referral_needed`, `next_deadline`, `next_action`.

## Evidencia y resultado

`official_source_count`, `independent_source_count`, `source_urls`, `evidence_ledger`, `last_verified`, `verification_status`, `data_conflicts`, `missing_critical_fields`, `distress_score`, `viability_score`, `confidence`, `primary_route`, `alternate_route`, `route_conditions`, `priority_reason`, `exclusion_reason`.
