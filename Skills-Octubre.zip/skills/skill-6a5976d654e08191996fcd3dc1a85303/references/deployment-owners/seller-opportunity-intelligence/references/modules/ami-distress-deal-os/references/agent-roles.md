# Roles y contratos de agentes

## Coordinador

Interpretar el modo, fijar ventana, crear plan, mantener ledger de supuestos y resolver contradicciones. Consolidar la identidad, calcular scores, decidir rutas y ensamblar entregables.

## Source Mapper

Localizar fuentes oficiales y gratuitas. Entregar URL, entidad, dato, método, periodo, frecuencia de actualización, cobertura, restricciones y etiqueta de acceso.

## Court & Foreclosure Researcher

Recolectar complaints, lis pendens, docket, judgment, auction, cancellations, dismissals, satisfactions y certificates of title. Entregar hechos con fechas y evidencia; no puntuar.

## Tax & Municipal Researcher

Recolectar tax delinquency, certificates/deeds, liens, HOA/condo filings, code, unsafe structure, nuisance y permits. Diferenciar abierto, pagado, released o desconocido.

## Market Signal Researcher

Buscar short sale, third-party approval, REO, auctions, failed listings, DOM, reducciones y condición en fuentes públicas o autorizadas. Tratar remarks como evidencia secundaria salvo declaración expresa.

## Title & Debt Analyst

Ordenar mortgages, assignments, releases, liens y judgments conocidos. Crear waterfall preliminar y registrar payoff/title como desconocidos hasta recibirlos. No emitir opinión de title.

## Valuation & Exit Analyst

Construir valor conservador/base/optimista con comparables verificables, estimar costos y probar venta tradicional, short sale potencial, investor, rental o REO/auction buyer review. No usar assessed value como market value.

## Document & Timeline Analyst

Aplicar OCR, extraer campos, ordenar eventos y detectar documentos, firmas, fechas o páginas faltantes en casos autorizados. No crear hardship ni alterar documentos.

## Normalization Agent

Consolidar por parcel ID o dirección, preservar alias y provenance, y marcar `duplicate_of`, `conflict` o `needs_verification`.

## Verification Agent

Intentar refutar cada prioridad. Devolver `verified`, `partially_verified`, `stale`, `resolved`, `conflicted` o `unverified` con la evidencia correspondiente.

## Ranking & Routing Owner

Aplicar una sola rúbrica, evitar doble conteo y emitir scores, confianza, ruta primaria, alternativa, condiciones y siguiente acción. No cambiar datos crudos.

## Contrato de retorno

Todo agente devolverá: modo, condado/propiedad, periodo, fuentes, fecha de consulta, registros, campos faltantes, conflictos, limitaciones, señales sin score y archivos creados. Nunca devolverá conclusiones sin provenance.

## Secuencia

1. Source Mapper.
2. Court, Tax/Municipal y Market en paralelo.
3. Normalization.
4. Title/Debt, Valuation y Timeline sobre shortlist.
5. Verification.
6. Ranking & Routing central.
