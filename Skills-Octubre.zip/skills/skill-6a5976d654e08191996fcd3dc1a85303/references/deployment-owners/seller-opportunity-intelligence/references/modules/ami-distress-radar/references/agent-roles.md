# Roles de agentes

## Coordinador

Recibir solo el condado, definir ventana, crear plan, delegar, mantener el ledger de supuestos y ensamblar la salida. Resolver contradicciones y calcular el ranking final.

## Source Mapper

Encontrar sitios oficiales y fuentes gratuitas. Entregar URL, entidad responsable, dato, método de consulta, periodo, actualización, restricciones y cobertura.

## Court & Foreclosure Researcher

Buscar foreclosure cases, lis pendens, final judgments, auction dates, dismissals, satisfactions, certificates of title y cambios. Entregar datos crudos con URL y fechas. No asignar scores.

## Tax & Municipal Researcher

Buscar delinquent taxes, tax certificates, tax deeds, recorded liens, HOA-related filings, code cases, unsafe structures y permits. Diferenciar abierto, pagado, released o desconocido.

## Market Signal Researcher

Buscar fuentes públicas permitidas de short sale, third-party approval, REO, auction, failed listings, DOM y price reductions. Tratar remarks como evidencia secundaria salvo declaración expresa.

## Normalization Agent

Crear registros canónicos por parcel ID o dirección. Conservar alias, provenance y conflictos. Marcar `duplicate_of`, `conflict` o `needs_verification`.

## Verification Agent

Revisar candidatos principales contra fuentes oficiales y buscar evidencia que refute la hipótesis. Devolver `verified`, `partially_verified`, `stale`, `resolved`, `conflicted` o `unverified`.

## Ranking Owner

Aplicar una rúbrica única. Evitar doble conteo. Emitir ambos scores, confianza, ruta, razón y próxima acción. No cambiar datos crudos.

## Contrato de retorno

Cada recolector debe devolver condado, periodo, fuente, URL, fecha de consulta, registros, campos faltantes, limitaciones, señales preliminares sin score y archivos creados.

## Paralelización

Ejecutar Source Mapper primero. Luego Court, Tax/Municipal y Market en paralelo. Ejecutar Normalization al reunir resultados, Verification sobre el shortlist y Ranking al final.
