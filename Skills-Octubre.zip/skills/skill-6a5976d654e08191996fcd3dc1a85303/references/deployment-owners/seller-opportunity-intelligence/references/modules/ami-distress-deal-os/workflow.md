# Módulo de método

Aplicar únicamente dentro de los límites del controlador SKILL.md del owner.

# AMI Distress Deal OS

## Objetivo

Convertir señales públicas fragmentadas en oportunidades residenciales verificadas y rutas ejecutables. Operar como sistema de inteligencia y coordinación, no como generador de listas ni asesor legal.

Aceptar como input mínimo `Condado: {nombre}`. Asumir Florida si no se indica estado y el condado es inequívoco. No pedir archivos, credenciales, APIs pagadas ni listas para iniciar. También aceptar una dirección, parcel ID, case number o CSV cuando el usuario los proporcione voluntariamente.

## Principios no negociables

- Tratar cada señal como hipótesis hasta verificarla.
- Separar hechos, cálculos, inferencias, supuestos y desconocidos.
- Conservar fuente, URL, fecha efectiva, fecha de consulta y confianza para cada dato material.
- No afirmar short sale sin confirmación del servicer o déficit sustentado; un filing no demuestra equity negativo.
- No usar assessed value como market value ni mortgage original como balance actual.
- No inferir hardship, intención, ocupación, protected class ni información personal no demostrada.
- No evadir login, CAPTCHA, robots, paywalls, permisos ni términos de uso.
- No automatizar cold SMS, robocalls, AI voice, voicemail drops ni contacto que carezca de consentimiento o revisión de cumplimiento.
- No dar asesoría legal, fiscal, crediticia, foreclosure-defense ni loss-mitigation. Escalar a abogado, title, CPA o HUD-approved counselor cuando corresponda.
- Mantener humano en verificación, contacto, valoración final, decisiones de ruta y documentos enviados a terceros.

## Preparación obligatoria

Leer al comenzar:

- `references/source-strategy.md` para construir el registro de fuentes.
- `references/data-contract.md` para capturar y normalizar datos.
- `references/agent-roles.md` antes de delegar investigación.

Leer antes de decidir:

- `references/scoring.md` antes de puntuar.
- `references/deal-playbooks.md` antes de asignar una ruta.
- `references/output-contract.md` antes de generar entregables.

## Modos

1. **County Radar:** universo reciente de un condado.
2. **Property Dossier:** investigación profunda de una propiedad o caso.
3. **Portfolio Triage:** normalizar, deduplicar y priorizar una lista suministrada.
4. **Case Monitor:** comparar con una ejecución anterior y detectar cambios.
5. **Deal Operations:** analizar valor, deuda, documentos, plazos, buyer fit y próximos pasos de un candidato autorizado.

Si el usuario solo da el condado, ejecutar County Radar completo sin preguntas adicionales. Usar ventana de 180 días; ampliar a 365 si hay menos de 25 candidatos antes de deduplicar.

## Orquestación

Usar un coordinador central. Cuando existan agentes o subagentes, delegar trabajos independientes según `references/agent-roles.md` y mantener centralizados normalización, scoring y routing. Ejecutar en paralelo Court, Tax/Municipal y Market después de Source Mapping. No permitir que recolectores asignen el score final.

Si no hay subagentes, conservar los mismos roles como fases secuenciales y contratos de retorno.

## Workflow

### 1. Construir Source Registry

Localizar Clerk/Court, Official Records, Tax Collector, Property Appraiser, code enforcement, permits, auction calendars y portales públicos permitidos. Clasificar cada fuente `bulk`, `searchable`, `verification_only` o `blocked`. Declarar cobertura real; no confundir una búsqueda individual con cobertura del condado.

### 2. Crear universo inicial

Capturar foreclosure complaints, lis pendens, judgments, auction dates, tax delinquency/deeds, HOA/condo liens o foreclosure, municipal liens, code/unsafe/permit issues, REO, short-sale language, third-party approval, failed listings, DOM y price reductions. Capturar señales tempranas combinadas sin presentarlas como eventos confirmados.

### 3. Extraer y normalizar

Usar exportaciones oficiales cuando existan. Aplicar OCR a PDFs escaneados cuando sea necesario. Extraer al esquema canónico; usar parcel ID como llave primaria y dirección normalizada como secundaria. Conservar alias, documentos, provenance y conflictos. No convertir vacío en cero o `false`.

### 4. Verificar y refutar

Para cada candidato potencialmente prioritario, exigir una fuente oficial primaria o dos fuentes independientes con al menos una oficial. Buscar activamente dismissal, release, satisfaction, sale completed, certificate of title, transferencia reciente, payoff incompatible, listing cerrado o dato desactualizado.

### 5. Reconstruir timeline y waterfall

Ordenar filing, service cuando sea visible, judgment, auction, cancelación, reprogramación, sale y title. Construir rangos conservador/base/optimista de valor y net equity. Etiquetar deuda estimada y excluirla como prueba de short sale. No completar payoff, liens o closing costs faltantes con invenciones.

### 6. Puntuar

Calcular por separado:

- **Distress Score:** intensidad, proximidad y corroboración.
- **Deal Viability Score:** identidad, valor, deuda/liens, plazo, title/condición y ruta plausible.

Usar `scripts/score_candidates.py` para CSV canónico. Si se calcula manualmente, aplicar exactamente `references/scoring.md`. Los scores priorizan investigación; no predicen cierre, aprobación ni motivación.

### 7. Asignar una ruta primaria

Elegir solo una:

- `urgent_legal_stage_review`
- `home_retention_resource_review`
- `traditional_sale_possibility`
- `short_sale_assessment`
- `investor_due_diligence`
- `reo_or_auction_buyer_review`
- `priority_conditioned`
- `watchlist`
- `low_priority`
- `exclude`

Agregar ruta alternativa, condiciones para cambiar de ruta y próximo paso. Seguir `references/deal-playbooks.md`.

### 8. Generar entregables

Seguir `references/output-contract.md`. Para County Radar producir reporte ejecutivo, priority CSV, watchlist, source registry, exclusions y dossiers de prioridad alta. Para Property Dossier producir un expediente único con timeline, evidence ledger, equity waterfall, riesgos, rutas y plan de 48 horas.

### 9. Monitorear y aprender

En ejecuciones posteriores comparar nuevos, escalados, resueltos, pospuestos, vendidos y excluidos. Medir detection latency, verified-signal rate, false positives, prioridad-a-cita, cita-a-listing, approval/close rate y costo/tiempo por candidato. No cambiar pesos por una sola ejecución; revisar después de al menos 30 outcomes verificados.

## Quality gate

No finalizar hasta confirmar:

- Condado, periodo, fecha y cobertura declarados.
- Identidad canónica y deduplicación.
- Estado actual de cada prioridad alta.
- Auction dates con fecha de consulta.
- Hechos separados de estimaciones e inferencias.
- Valor, deuda y equity presentados como rangos cuando falte evidencia.
- Scores calculados centralmente sin doble conteo.
- Ruta, condición, próximo paso y profesional a escalar cuando aplique.
- Descartes y fuentes bloqueadas visibles.
- Ningún dato personal o contacto presentado como verificado sin fuente legítima.
- Ninguna recomendación legal, fiscal o crediticia presentada como certeza.

La imposibilidad de acceder a una fuente no impide terminar: entregar cobertura parcial, registrar el bloqueo y reducir la confianza.
