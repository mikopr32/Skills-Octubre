# Contrato de salida

## County Radar

Crear:

1. `DISTRESS-DEAL-OS-{COUNTY}-{DATE}.md`
2. `PRIORITY-CANDIDATES-{COUNTY}-{DATE}.csv`
3. `WATCHLIST-{COUNTY}-{DATE}.csv`
4. `SOURCE-REGISTRY-{COUNTY}-{DATE}.csv`
5. `EXCLUDED-{COUNTY}-{DATE}.csv`
6. `DOSSIERS/PROPERTY-{candidate_id}.md` para cada prioridad alta.

El reporte ejecutivo incluirá periodo, cobertura, bloqueos, registros revisados, candidatos únicos, rutas, top candidatos, señales, riesgos, métricas y plan de 48 horas.

## Property Dossier

Incluir identidad; estado; timeline; evidence ledger; hechos; inferencias; supuestos; desconocidos; valor low/base/high; deuda/liens; equity waterfall; scores; confianza; ruta primaria y alternativa; condiciones; preguntas; escalaciones; y plan de 48 horas.

## Portfolio Triage

Entregar CSV canónico puntuado, duplicados, conflictos, shortlist, watchlist, exclusions y resumen de calidad del input.

## Case Monitor

Entregar delta: nuevos, escalados, pospuestos, resueltos, vendidos, estancados y cambios de ruta. Mantener historial y fecha de verificación.

## Reglas de presentación

- Una fila por propiedad.
- URLs y fechas junto a la señal material.
- Montos estimados marcados y expresados como rango.
- Descartes visibles; no borrar candidatos silenciosamente.
- Mostrar `coverage_partial` cuando falte una fuente material.
- Terminar con acciones por responsable y plazo, no con recomendaciones genéricas.
