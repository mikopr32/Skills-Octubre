# Rúbrica de scoring

Calcular dos scores y aplicar topes para evitar doble conteo.

## Distress Score 0–100

- Etapa legal, máximo 35: auction scheduled 35; final judgment 30; complaint/lis pendens 25; tax deed 22; HOA foreclosure 20; REO 18; dismissed/released 0.
- Presión financiera, máximo 25: tax delinquent 10; tax deed 12; HOA lien 8; otros liens hasta 8; equity negativo estimado 7.
- Mercado, máximo 20: short sale 15; third-party approval 12; REO 12; expired/canceled/withdrawn 6; back on market 5; tres reducciones 5; DOM anómalo 4.
- Propiedad/municipal, máximo 10: unsafe structure 8; code violation 5; permit issue 4; condition signal 3.
- Evidencia, máximo 10: evento oficial vigente corroborado por otra fuente 10; una fuente oficial vigente 8; una secundaria 3; conflicto 0.

Usar solo el evento legal activo de mayor puntuación.

## Viability Score 0–100

- Identidad/status verificables 20.
- Valor sustentado 20.
- Deuda/liens suficientemente conocidos 20.
- Plazo ejecutable 15.
- Ruta plausible 15.
- Condición/title manejables 10.

Restar 20 por auction inminente, 15 por title conflict, 15 por valor débil y 15 por deuda crítica desconocida. Excluir propiedad vendida o transferida.

## Confianza y routing

- Alta: evento oficial y datos críticos corroborados.
- Media: evento oficial con faltantes.
- Baja: señales predictivas o secundarias.
- Distress >=75 y Viability >=50: prioridad alta.
- Distress 60–74 y Viability >=45: prioridad condicionada.
- Distress 40–59: watchlist.
- Distress <40: baja prioridad.
- Auction dentro de 14 días, inclusive: `urgent legal-stage review`.

Los scores priorizan investigación; no predicen cierre ni aprobación.
