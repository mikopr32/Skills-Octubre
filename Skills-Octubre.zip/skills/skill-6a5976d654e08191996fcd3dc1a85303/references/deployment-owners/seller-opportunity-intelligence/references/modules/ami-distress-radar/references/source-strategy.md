# Estrategia de fuentes gratuitas

## Prioridad

1. Fuente oficial primaria.
2. Documento registrado o docket oficial.
3. Dataset oficial descargable.
4. Fuente pública secundaria que enlaza al registro.
5. Listing o auction portal permitido.
6. Snippet de buscador solo para descubrimiento.

No usar snippets como prueba final cuando exista el registro oficial.

## Consultas

- `{county} Florida clerk foreclosure case search`
- `{county} Florida official records lis pendens search`
- `{county} Florida foreclosure sale calendar`
- `{county} Florida delinquent property taxes`
- `{county} Florida tax deed auction`
- `{county} Florida property appraiser search`
- `{county} Florida code enforcement search`
- `{county} Florida building permit search`
- `{county} short sale homes`
- `{county} REO foreclosure auction`

## Acceso

- Usar exportación CSV/XLS/PDF cuando exista.
- Extraer tablas públicas solo cuando esté permitido y conservar la URL.
- Usar consultas individuales para verificar, no para afirmar cobertura masiva.
- Ante CAPTCHA, login o fee, registrar `blocked` y continuar.
- No automatizar sitios que lo prohíban.

## Etiquetas de cobertura

- `bulk`: universo amplio.
- `searchable`: consultas sin cobertura demostrable.
- `verification_only`: confirmar candidatos.
- `blocked`: requiere pago, autenticación o intervención.

## Valor y deuda sin servicios pagados

- Estimar valor con ventas cerradas públicas comparables cuando estén disponibles. No usar assessed value como market value.
- Usar listing prices solo como competencia, no como prueba de valor.
- Tratar el monto de la hipoteca registrada como monto original, no como balance actual.
- Estimar saldo únicamente si existen monto, fecha, plazo y una tasa razonablemente sustentada; etiquetar método, supuestos y rango.
- Si faltan payoff o liens completos, no afirmar equity ni short sale; reportar un rango o `unknown`.
