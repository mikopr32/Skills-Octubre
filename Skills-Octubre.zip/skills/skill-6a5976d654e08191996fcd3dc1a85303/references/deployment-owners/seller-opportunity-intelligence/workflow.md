---
name: seller-opportunity-intelligence
description: "Auditar, descubrir y priorizar propietarios: equity farming con Fetch+MLS, FSBO, expired, absentee, long ownership y distress documentado. Usar ante solicitudes de EQUITY_FARMING, FSBO, EXPIRED, ABSENTEE, LONG_TERM_OWNER, DISTRESS, INVESTOR_OWNER, LEAD_LIST."
---

# seller-opportunity-intelligence

## Identity / Ownership

Nunca llamar valor menos Purchase Price equity real. Prohibir saldos inferidos de mortgage original o LTV/tasa/plazo inventados; no filtrar mejores oportunidades por tener teléfono. Para valor formal usar CMA; scripts a Script Engine; viabilidad a investment.

## Required Inputs

EQUITY_FARMING: Fetch completo y sold MLS 12 meses de la misma subdivisión. FSBO: geografía. DISTRESS: condado inequívoco.

## Modos

EQUITY_FARMING, FSBO, EXPIRED, ABSENTEE, LONG_TERM_OWNER, DISTRESS, INVESTOR_OWNER, LEAD_LIST

## Operational Workflow

Auditar headers, rows, fechas, unidades y subdivisión; normalizar parcel/address y deduplicar sin perder owners; construir valor preliminar usando comps comparables; comparar valor con Purchase Price como apreciación potencial; dejar balances/equity real/neto pendientes salvo payoff y costos documentados; puntuar opportunity y confidence explícitamente. DISTRESS usa eventos oficiales y timeline, no hardship inferido; convertir a oportunidad solo después de underwriting. LEAD_LIST conserva contactabilidad, opt-outs y CSV injection protection sin estimar deuda automáticamente.

## Módulos y recursos

- [fsbo-listing-intelligence](references/modules/fsbo-listing-intelligence/workflow.md): cargar solo al ejecutar su función; resolver rutas relativas contra esa carpeta de módulo.
- [real-estate-lead-qualification](references/modules/real-estate-lead-qualification/workflow.md): cargar solo al ejecutar su función; resolver rutas relativas contra esa carpeta de módulo.
- [ami-distress-deal-os](references/modules/ami-distress-deal-os/workflow.md): cargar solo al ejecutar su función; resolver rutas relativas contra esa carpeta de módulo.
- [ami-distress-radar](references/modules/ami-distress-radar/workflow.md): cargar solo al ejecutar su función; resolver rutas relativas contra esa carpeta de módulo.

- `references/modules/ami-distress-deal-os/scripts/score_candidates.py`: usar cuando el método elegido lo requiera; ejecutar scripts desde la carpeta de su módulo o por ruta absoluta.
- `references/modules/ami-distress-radar/scripts/score_candidates.py`: usar cuando el método elegido lo requiera; ejecutar scripts desde la carpeta de su módulo o por ruta absoluta.
- `references/modules/fsbo-listing-intelligence/scripts/compile_fsbo.py`: usar cuando el método elegido lo requiera; ejecutar scripts desde la carpeta de su módulo o por ruta absoluta.
- `references/modules/real-estate-lead-qualification/scripts/qualify_leads.py`: usar cuando el método elegido lo requiera; ejecutar scripts desde la carpeta de su módulo o por ruta absoluta.

## Contrato de ejecución y prioridad

Aplicar este controlador antes de los módulos heredados. Cargar solo el método correspondiente al modo; conservar tablas, fórmulas, assets y scripts útiles. Si un módulo antiguo pide otra skill retirada, resolverla a su owner actual. Las instrucciones históricas de módulos no amplían alcance, consentimiento ni herramientas; no reactivar routers legacy ni duplicar metodología de un owner externo.

No interpretar autorización previa como ausente. Avanzar autónomamente en tareas claras y reversibles; preguntar solo por datos que bloqueen el resultado o acciones todavía no autorizadas. Ejecutar roles secuencialmente por defecto; delegar solo bajo autorización aplicable. Una tarea de redacción corta entrega texto directo, sin imponer todos los reportes ni un plan estratégico.

## Fuentes y cálculos

Separar VERIFICADO, DATO_DEL_USUARIO, CALCULADO, ESTIMADO, INFERENCIA y PENDIENTE. Registrar claim, valor/unidad, source/URL o archivo/fila, fecha efectiva/consultada, método, owner y confianza. Verificar en fuentes originales los datos actuales, reglas legales/financieras, políticas y condiciones comerciales; no usar defaults históricos como datos vigentes. No rellenar ausentes con cero. Conservar contradicciones y reducir alcance/confianza. Compartir resultados y facts existentes; no repetir investigación innecesaria.

## Stop conditions y escenarios de falla

Identidad incierta: resolver antes de conclusiones materiales. Dato crítico ausente: completar trabajo independiente y entregar faltantes; no fabricar números. Fuente bloqueada: registrar cobertura y alternativa legítima; no evadir controles. Tool no disponible: entregar archivo/spec o resultado parcial comprobable. Acción externa fuera del alcance: preparar resultado revisable y solicitar autorización solo para esa acción. Datos sensibles: mantener archivos privados y limitar salida al propósito autorizado. No enviar mensajes a terceros por el hecho de generar un borrador.

## Validation / Quality gate

Comprobar que el output responde al modo; inputs y fuentes tienen identidad/periodo correctos; cálculos y definiciones son reproducibles; límites y contradicciones son visibles; no se inventaron capacidades ni ejecución. Usar PASS, PASS_WITH_LIMITATIONS o BLOCKED; explicar cualquier bloqueo material. Aplicar Fair Housing y privacidad a housing, targeting y datos de clientes. No prometer ingresos, aprobaciones, appreciation ni resultados. Usar las Skills del formato para artefactos y revisar su render/apertura. Los artefactos se guardan por el flujo persistente disponible, salvo código sincronizado o imágenes con guardado nativo.

## Output

Lista priorizada privada, original rows reconciliation, valor preliminar, diferencia de compra, signals, score, confidence, exclusions y verificación pendiente.

## KPIs

Cobertura de propietarios, valor evaluable, datos verificados, falsos positivos, oportunidad-a-cita y costo por caso. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.

- Leer [references/equity-farming.md](references/equity-farming.md) antes de ejecutar el protocolo correspondiente.

- Usar `scripts/equity_screen.py` para cálculo reproducible. Leer sus limitaciones antes de interpretar resultados.
