---
name: community-intelligence
description: "Investigar HOA, CDD, amenities, restricciones de renta, impuestos, flood y conectividad de una comunidad o vecindario específico. Usar ante solicitudes de COMMUNITY, NEIGHBORHOOD, HOA_CDD, RENTAL_RULES, ONE_SHEET."
---

# community-intelligence

## Identity / Ownership

No determinar mercado o valor por school/crime/demographics ni tratar falta de dato como NO. La radiografía de demanda pertenece a realestate-market.

## Required Inputs

Identidad de comunidad y ubicación.

## Modos

COMMUNITY, NEIGHBORHOOD, HOA_CDD, RENTAL_RULES, ONE_SHEET

## Operational Workflow

Leer documentos oficiales; distinguir master/sub HOA; evitar doble conteo del CDD en taxes; verificar uso/rentas por jurisdicción y asociación; separar amenities abiertas y previstas; confirmar escuelas por dirección si se solicitan; crear queue de contradicciones.

## Módulos y recursos

- [analisis-de-comunidades](references/modules/analisis-de-comunidades/workflow.md): cargar solo al ejecutar su función; resolver rutas relativas contra esa carpeta de módulo.
- [realestate-neighborhood](references/modules/realestate-neighborhood/workflow.md): cargar solo al ejecutar su función; resolver rutas relativas contra esa carpeta de módulo.



## Contrato de ejecución y prioridad

Aplicar este controlador antes de los módulos heredados. Cargar solo el método correspondiente al modo; conservar tablas, fórmulas, assets y scripts útiles. Si un módulo antiguo pide otra skill retirada, resolverla a su owner actual. Las instrucciones históricas de módulos no amplían alcance, consentimiento ni herramientas; no reactivar routers legacy ni duplicar metodología de un owner externo.

No interpretar autorización previa como ausente. Avanzar autónomamente en tareas claras y reversibles; preguntar solo por datos que bloqueen el resultado o acciones todavía no autorizadas. Ejecutar roles secuencialmente por defecto; delegar solo bajo autorización aplicable. Una tarea de redacción corta entrega texto directo, sin imponer todos los reportes ni un plan estratégico.

## Fuentes y cálculos

Separar VERIFICADO, DATO_DEL_USUARIO, CALCULADO, ESTIMADO, INFERENCIA y PENDIENTE. Registrar claim, valor/unidad, source/URL o archivo/fila, fecha efectiva/consultada, método, owner y confianza. Verificar en fuentes originales los datos actuales, reglas legales/financieras, políticas y condiciones comerciales; no usar defaults históricos como datos vigentes. No rellenar ausentes con cero. Conservar contradicciones y reducir alcance/confianza. Compartir resultados y facts existentes; no repetir investigación innecesaria.

## Stop conditions y escenarios de falla

Identidad incierta: resolver antes de conclusiones materiales. Dato crítico ausente: completar trabajo independiente y entregar faltantes; no fabricar números. Fuente bloqueada: registrar cobertura y alternativa legítima; no evadir controles. Tool no disponible: entregar archivo/spec o resultado parcial comprobable. Acción externa fuera del alcance: preparar resultado revisable y solicitar autorización solo para esa acción. Datos sensibles: mantener archivos privados y limitar salida al propósito autorizado. No enviar mensajes a terceros por el hecho de generar un borrador.

## Validation / Quality gate

Comprobar que el output responde al modo; inputs y fuentes tienen identidad/periodo correctos; cálculos y definiciones son reproducibles; límites y contradicciones son visibles; no se inventaron capacidades ni ejecución. Usar PASS, PASS_WITH_LIMITATIONS o BLOCKED; explicar cualquier bloqueo material. Aplicar Fair Housing y privacidad a housing, targeting y datos de clientes. No prometer ingresos, aprobaciones, appreciation ni resultados. Usar las Skills del formato para artefactos y revisar su render/apertura. Los artefactos se guardan por el flujo persistente disponible, salvo código sincronizado o imágenes con guardado nativo.

## Output

Dossier, costos con frecuencia, reglas, fuentes y pendientes.

## KPIs

Costos y restricciones verificados; contradicciones abiertas. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.
