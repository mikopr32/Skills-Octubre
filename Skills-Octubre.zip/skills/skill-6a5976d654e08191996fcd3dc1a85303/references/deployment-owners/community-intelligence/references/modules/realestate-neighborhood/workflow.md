# Módulo de vecindario y conectividad

Aplicar dentro del contrato de community-intelligence. Este método cubre datos objetivos de ubicación, servicios, infraestructura y riesgos físicos verificables. Para cuotas, asociaciones y restricciones, usar el módulo analisis-de-comunidades del mismo paquete.

## Inputs

Nombre de comunidad, ciudad y estado; dirección cuando se requiera identificar parcela, asociación, flood zone o asignación escolar. Confirmar identidad antes de combinar fuentes. Si falta dirección, entregar el perfil general y señalar los campos que dependen de una parcela concreta.

## Investigación

1. Confirmar límites, municipio, condado y jurisdicción mediante fuentes oficiales.
2. Identificar vías de acceso y rutas hacia destinos que el usuario haya indicado. Reportar distancias y tiempos aproximados, con fecha, ruta y condiciones de tráfico cuando existan. No garantizarlos.
3. Verificar supermercados, hospitales, parques, bibliotecas y transporte. Separar servicios públicos, servicios privados, amenidades de la asociación y lugares simplemente cercanos. Indicar distancia, acceso y costos conocidos.
4. Si el usuario solicita escuelas, consultar la asignación del distrito por dirección; distinguir zonificación confirmada de opciones cercanas. Conservar fecha y pendientes de confirmación. La asignación puede cambiar.
5. Verificar obras, proyectos de infraestructura y propuestas de zonificación en registros oficiales. Separar anunciado, propuesto, aprobado, en construcción y operativo; no garantizar fechas ni inferir appreciation.
6. Consultar flood zone y otros riesgos físicos pertinentes mediante mapas y agencias oficiales. Indicar versión del mapa, alcance parcelario y limitaciones. Costos de seguro requieren cotización específica; no asumirlos.
7. Si se solicitan cuotas, CDD o usos de alquiler, cargar el módulo de comunidades y verificar asociación y jurisdicción antes de responder. No inferir permisos por anuncios.

## Límites

- No producir Neighborhood Score, calificaciones A/F ni ranking de calidad de zonas.
- No puntuar, valorar o recomendar viviendas o comunidades mediante raza, etnia, nacionalidad, religión, situación familiar, discapacidad, composición demográfica, ingresos de residentes, escolaridad o pobreza.
- No determinar valor o atractivo inmobiliario mediante ratings escolares o criminalidad.
- No asignar barrios a perfiles como familias, jóvenes o retirados. Comparar únicamente criterios objetivos que el usuario haya elegido: presupuesto, desplazamiento, tipo de vivienda, accesibilidad, servicios y uso permitido.
- No calificar una zona como segura o peligrosa. Ante una consulta expresa de seguridad pública, ofrecer fuentes oficiales y contexto de cobertura, periodo y metodología; no convertir estadísticas en una recomendación residencial o un score.
- No realizar búsquedas de residentes identificables ni crear perfiles de personas.
- No enviar mensajes, contactar asociaciones, publicar, comprar ni modificar cuentas por realizar una investigación.
- Usar exclusivamente herramientas disponibles y fuentes autorizadas. Ejecutar secuencialmente; delegar únicamente cuando exista autorización aplicable.

## Evidencia y contradicciones

Registrar dato, fuente directa, fecha efectiva, fecha de consulta, ubicación aplicable y confianza. Separar VERIFICADO, DATO_DEL_USUARIO, CALCULADO, ESTIMADO, INFERENCIA y PENDIENTE. No tratar ausencia como cero o NO. Conservar contradicciones y explicar qué documento o dato resolvería cada una. Una anécdota no acredita un hecho financiero, legal, escolar o regulatorio.

## Salida

Entregar el formato solicitado, con estas secciones cuando sean pertinentes:

- Identidad y alcance de la comunidad o dirección.
- Conectividad y destinos indicados por el usuario.
- Servicios cercanos frente a amenidades incluidas.
- Asignación escolar si fue solicitada.
- Infraestructura y proyectos, con estado verificable.
- Riesgos físicos y limitaciones de los mapas.
- Costos o reglas remitidos al módulo de comunidades.
- Tabla de fuentes, contradicciones y pendientes.

No imponer un informe completo a una pregunta puntual. Usar las Skills del formato cuando se requiera un archivo.

## Verificación final

Confirmar identidad, fechas, fuentes y alcance. Revisar que no haya puntuaciones de barrio, recomendaciones por clases protegidas ni inferencias de valor mediante escuelas, crimen o demografía. Confirmar que los datos ausentes permanezcan pendientes y que se distingan hechos de estimaciones. Informar PASS, PASS_WITH_LIMITATIONS o BLOCKED según la evidencia realmente disponible.
