# Sistemas de layout

## Selector

| Estructura del contenido | Layout principal | Visual dominante | Evitar |
|---|---|---|---|
| Beneficios, características, curiosidades | Imagen central + puntos alrededor | Sujeto, objeto o concepto central | Más de 7 llamadas |
| Anatomía o componentes | Visual central etiquetado | Diagrama o ilustración | Líneas cruzadas |
| Proceso o método | Flujo vertical o escalonado | Etapas numeradas | Imagen central decorativa |
| Comparación simple | Dos columnas balanceadas | Dos sujetos o categorías | Escalas inconsistentes |
| Antes y después | División 50/50 | Contraste visual | Diferencias artificiales |
| Timeline | Eje vertical | Hitos y fechas | Texto en párrafos |
| Estadísticas | Cifra dominante + micrográficos | Número o gráfico principal | Métricas sin contexto |
| Ranking | Lista editorial jerárquica | Top 3 o posición principal | Tarjetas repetidas |
| Framework | Módulos conectados | Modelo conceptual | Conectores ambiguos |
| Resumen educativo | Página editorial modular | Una ilustración de apoyo | Grid uniforme sin prioridad |

## Imagen central

Usar aproximadamente 35–45% de la composición cuando sea el patrón elegido. Distribuir de cuatro a seis puntos alrededor con alineación óptica, distancias consistentes y conectores mínimos. Mantener el título fuera de la zona de interferencia visual.

## Cuadrícula

- Trabajar dentro de un área segura del 80% central: 10% del ancho a izquierda/derecha y 10% de la altura arriba/abajo.
- Social 1080 × 1350: reservar aproximadamente 108 px laterales y 135 px arriba/abajo.
- A4 2480 × 3508: reservar aproximadamente 248 px laterales y 351 px arriba/abajo.
- A4: favorecer 6 columnas y ritmo vertical amplio.
- 4:5: favorecer 4 columnas, título corto y bloques de lectura rápida.
- Alinear texto a una cuadrícula; evitar centrado en párrafos de más de dos líneas.
- Crear un solo punto focal. Los demás elementos deben sostenerlo.

## Adaptación

Recalcular jerarquía, posiciones y tamaños para cada ratio. Preservar tesis, copy y sistema visual; no preservar coordenadas ni recortar mecánicamente.
