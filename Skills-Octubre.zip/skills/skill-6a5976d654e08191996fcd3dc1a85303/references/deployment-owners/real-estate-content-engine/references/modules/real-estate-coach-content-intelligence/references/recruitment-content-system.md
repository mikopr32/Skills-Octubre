# Sistema de contenido para reclutamiento por valor

## Arquitectura

Diseñar el contenido como recorrido, no como publicaciones aisladas:

| Función | Pregunta del agente | Activo útil | CTA apropiado |
| --- | --- | --- | --- |
| Atraer | “¿Alguien entiende mi problema?” | diagnóstico, opinión, historia | comentar o guardar |
| Resolver | “¿Me puede ayudar?” | tutorial, plantilla, checklist | descargar o responder |
| Demostrar | “¿Funciona en la práctica?” | caso, sesión, detrás de cámaras | ver clase o comunidad |
| Invitar | “¿Cuál es mi siguiente paso?” | evento, aplicación, conversación | registrarse o aplicar |

## Pilares sugeridos

Validar antes de adoptar:

1. Producción y prospección ejecutable.
2. Conversión, seguimiento y sistemas.
3. Marca personal y contenido que genera conversaciones.
4. IA y tecnología aplicada sin complejidad innecesaria.
5. Comunidad, liderazgo y crecimiento profesional.

Cada pilar debe contener una promesa, un mecanismo propio, prueba disponible y puente hacia la comunidad.

## Escalera de CTA

Usar el mínimo compromiso necesario:

1. Guardar, compartir o contestar una pregunta.
2. Comentar una palabra o enviar DM.
3. Descargar una herramienta o entrar a un canal informativo.
4. Asistir a un live, workshop o sesión abierta.
5. Solicitar conversación o ingreso.

No saltar a “únete” cuando la pieza todavía no ha creado confianza.

## Ficha por contenido

Entregar:

- segmento;
- dolor y evidencia;
- objetivo de negocio;
- hipótesis;
- hook;
- promesa y mecanismo;
- formato y duración;
- estructura;
- CTA;
- activo de seguimiento;
- KPI principal y umbral de decisión;
- versión siguiente si gana o pierde.

## Ciclo de optimización

1. Publicar una hipótesis por pieza.
2. Medir atención, resonancia y acción por separado.
3. Clasificar resultado como ganador, prometedor o débil contra la línea base del canal.
4. Iterar el hook si falla atención.
5. Iterar profundidad o claridad si hay atención sin guardados/comentarios.
6. Iterar CTA o oferta si hay resonancia sin acciones.
7. Convertir ganadores en series, email, live, lead magnet y taller.

Evitar atribuir reclutamiento a una sola publicación cuando el candidato consumió varias piezas. Registrar primer contacto, contenido asistido y último paso cuando sea posible.
