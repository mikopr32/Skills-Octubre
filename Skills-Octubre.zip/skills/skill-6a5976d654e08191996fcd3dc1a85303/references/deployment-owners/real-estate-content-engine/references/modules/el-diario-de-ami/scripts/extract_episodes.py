#!/usr/bin/env python3
"""Extract monthly podcast scripts into episode folders and JSON manifests."""

from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

HEADING = re.compile(
    r"(?im)^\s*(?:#{1,4}\s*)?(?:\*\*)?\s*episodio\s+(\d+)\s*[:\-–—_]\s*(.+?)(?:\*\*)?\s*$"
)
PRODUCTION_CUE = re.compile(
    r"\((?:m[uú]sica[^)]*|primer minuto|[uú]ltimo minuto|minuto\s+\d+(?:\s*[-–—]\s*\d+)?)\)",
    re.IGNORECASE,
)


def read_source(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix == ".txt":
        return path.read_text(encoding="utf-8")
    if suffix == ".pdf":
        result = subprocess.run(
            ["pdftotext", "-layout", str(path), "-"],
            check=True,
            capture_output=True,
            text=True,
        )
        text = result.stdout
        if not text.strip():
            raise ValueError("PDF sin texto extraíble; requiere OCR.")
        return text
    if suffix == ".docx":
        with zipfile.ZipFile(path) as archive:
            xml = archive.read("word/document.xml")
        root = ET.fromstring(xml)
        namespace = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
        paragraphs = []
        for paragraph in root.findall(".//w:p", namespace):
            parts = [node.text or "" for node in paragraph.findall(".//w:t", namespace)]
            if parts:
                paragraphs.append("".join(parts))
        return "\n".join(paragraphs)
    raise ValueError(f"Formato no compatible: {suffix}")


def clean_script(text: str) -> str:
    text = re.sub(r"(?i)\brealtor(?:s)?\b", "agente inmobiliario", text)
    text = re.sub(
        r"(?i)\*{0,2}LLAMADO AMI\s*[–—-]\s*ACCI[ÓO]N DE HOY\*{0,2}",
        "Tarea de hoy",
        text,
    )
    text = re.sub(r"(?im)^\s*\*{0,2}fecha:\*{0,2}.*$", "", text)
    text = PRODUCTION_CUE.sub("", text)
    text = re.sub(r"(?m)^\s*---+\s*$", "", text)
    text = text.replace("**", "").replace("__", "")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def split_episodes(text: str) -> list[dict]:
    matches = list(HEADING.finditer(text))
    if not matches:
        raise ValueError("No se detectaron encabezados tipo 'Episodio 63: Título'.")
    episodes = []
    seen = set()
    for index, match in enumerate(matches):
        number = int(match.group(1))
        if number in seen:
            raise ValueError(f"Número duplicado: episodio {number}.")
        seen.add(number)
        body_end = matches[index + 1].start() if index + 1 < len(matches) else len(text)
        body = clean_script(text[match.end() : body_end])
        if len(body) < 80:
            raise ValueError(f"Episodio {number} demasiado corto tras limpieza.")
        episodes.append({"number": number, "title": match.group(2).strip(" *_"), "script": body})
    return episodes


def write_batch(source: Path, output: Path, episodes: list[dict]) -> None:
    output.mkdir(parents=True, exist_ok=True)
    batch = {"source": str(source.resolve()), "status": "extracted", "episodes": []}
    for ep in episodes:
        ep_dir = output / f"episode-{ep['number']:03d}"
        ep_dir.mkdir(exist_ok=True)
        script_path = ep_dir / "script.txt"
        manifest_path = ep_dir / "manifest.json"
        script_path.write_text(ep["script"] + "\n", encoding="utf-8")
        manifest = {
            "episode": ep["number"],
            "title": ep["title"],
            "spotify_summary": "",
            "instagram_copy": "",
            "artwork": None,
            "explicit": False,
            "season": None,
            "publish_at": None,
            "timezone": "America/New_York",
            "status": "extracted",
            "files": {
                "script": str(script_path.resolve()),
                "voice": None,
                "final": None,
                "qa": None,
                "artwork": None,
            },
            "evidence": {},
            "errors": [],
        }
        manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        batch["episodes"].append(str(manifest_path.resolve()))
    (output / "batch.json").write_text(json.dumps(batch, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    try:
        episodes = split_episodes(read_source(args.source))
        write_batch(args.source, args.output, episodes)
        print(json.dumps({"ok": True, "episodes": len(episodes), "output": str(args.output.resolve())}))
        return 0
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
