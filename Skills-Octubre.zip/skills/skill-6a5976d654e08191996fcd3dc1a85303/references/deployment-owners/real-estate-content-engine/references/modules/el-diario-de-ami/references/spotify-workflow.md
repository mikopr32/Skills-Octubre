# Spotify for Creators

## Precondiciones

- El usuario aprobó explícitamente los audios finales del lote.
- Todos los episodios tienen estado `user-approved`; `quality-approved` por sí solo no autoriza ninguna carga.
- Cada manifiesto incluye número, título con emojis, descripción sin spoilers, carátula, archivo final y fecha/hora ET.
- Existe una sesión autenticada de Spotify for Creators. No solicitar ni almacenar contraseña.

## Programación

1. Leer y seguir completamente el skill `control-browser`.
2. Abrir Spotify for Creators y seleccionar bajo `Your Shows` el show de carátula azul. Confirmar el nombre y el ID `44eP54c72vtJWibRBeXj57`; no modificar la versión vieja.
3. Comprobar que no exista ya un episodio con el mismo número, título o fecha.
4. Crear un episodio de audio y cargar el MP3 final correspondiente.
5. Subir la carátula indicada y comprobar su miniatura en la vista de revisión.
6. Introducir el título y la descripción Spotify exactos del manifiesto. No continuar si la descripción está vacía.
7. Configurar temporada, número de episodio, tipo `Full`, contenido explícito y contenido promocional según el manifiesto.
8. Revisar antes de programar: carátula, título, descripción, temporada, número, tipo, explicit/promotional, archivo y duración.
9. Elegir publicación programada.
10. Configurar la fecha del manifiesto y las 6:00 a. m. en la zona horaria visible. Si la interfaz muestra otra zona, convertir y documentar la hora mostrada.
11. Guardar y esperar confirmación visible.
12. Reabrir la página del episodio y verificar que sean visibles la carátula, el título, la descripción y el número.
13. Volver a la lista/calendario y verificar fecha, hora y estado `Scheduled`.
14. Registrar evidencia estructurada con `show_id`, `artwork_visible`, `title_visible`, `description_visible`, `episode_number_visible`, `publish_at_visible` y `status_visible`. Si no hay URL pública antes de publicar, registrar la URL interna observada sin inventar una pública.

## Control de lote

- Procesar en orden cronológico.
- Tras cada episodio, actualizar `scheduled`; actualizar `verified` solo cuando todos los campos de evidencia obligatorios sean verdaderos.
- Si un episodio falla, registrar el error y continuar solo cuando hacerlo no desordene ni duplique el calendario.
- Al final, comparar la cantidad esperada con la cantidad verificada.

## Regla de calendario

Asignar únicamente lunes a viernes a las 6:00 a. m. `America/New_York`. Saltar sábados y domingos. No saltar feriados salvo instrucción del usuario.

## Detención segura

Detener y pedir intervención si aparece:

- inicio de sesión, MFA, CAPTCHA o cambio de permisos;
- show incorrecto;
- episodio duplicado;
- hora/zona horaria ambigua;
- advertencia de derechos o contenido;
- diferencia entre el archivo y su manifiesto.
