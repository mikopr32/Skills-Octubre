# Atribución y experimentos de reclutamiento

## Identidad del contenido

Asignar `content_id` con el patrón `AAAAMMDD-plataforma-tema-###`. Mantenerlo en enlaces, formularios y CRM.

## Campos mínimos

Registrar:

- `content_id`, plataforma, formato, tema, hook y CTA;
- campaña, lead magnet y URL con UTM;
- primer contenido conocido;
- contenidos asistidos relevantes;
- último paso antes de conversión;
- registro, asistencia, respuesta o DM;
- conversación realizada;
- candidato cualificado;
- incorporación y fecha;
- razón de pérdida o no avance.

Usar `utm_source`, `utm_medium`, `utm_campaign`, `utm_content` y `utm_term` de forma consistente. No colocar información personal en parámetros UTM.

## Definiciones del recorrido

1. **Lead identificado:** entregó un canal de contacto permitido.
2. **Lead comprometido:** consumió un recurso, respondió o asistió.
3. **Conversación:** hubo intercambio humano sobre necesidad y encaje.
4. **Candidato cualificado:** cumple criterios definidos de licencia, mercado, intención y encaje.
5. **Incorporado:** completó el paso oficial de ingreso.

## Atribución

Reportar tres perspectivas:

- primer contacto: qué contenido abrió la relación;
- contenido asistido: qué piezas construyeron confianza;
- último paso: qué CTA precedió la acción.

No declarar causalidad con muestras pequeñas. Usar entrevistas de origen en las conversaciones: “¿Qué contenido te hizo prestar atención?” y “¿Qué te convenció de hablar con nosotros?”.

## Diseño de experimentos

Cambiar una variable principal por prueba: hook, tema, formato, prueba o CTA. Definir antes de publicar:

- hipótesis;
- audiencia;
- métrica primaria;
- ventana de medición;
- línea base;
- umbral para repetir, iterar o detener.

Priorizar tasas por cada 1,000 vistas o por cada 100 visitantes cualificados cuando sea posible. Revisar semanalmente atención y resonancia; revisar mensualmente conversación, cualificación e incorporación.
