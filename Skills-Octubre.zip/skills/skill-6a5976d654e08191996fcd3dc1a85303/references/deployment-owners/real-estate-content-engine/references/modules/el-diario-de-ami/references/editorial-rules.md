# Reglas editoriales

## Guion hablado

- Reemplazar `realtor` por `agente inmobiliario`, sin importar mayúsculas.
- Reemplazar `LLAMADO AMI – ACCIÓN DE HOY` por `Tarea de hoy`.
- Retirar encabezados de episodio, líneas de fecha, Markdown y acotaciones de producción inequívocas como `(Música)`, `(Primer minuto)`, `(Minuto 2–3)` y `(Último minuto)`.
- Conservar paréntesis que sean parte del discurso, aclaraciones, cantidades o citas. No aplicar una eliminación global de todo texto entre paréntesis.
- No resumir ni reescribir el guion sin autorización. Marcar fragmentos dudosos para revisión.
- Mantener una pausa natural después del título o apertura; no insertar cadenas artificiales de puntos.

## Título de Spotify

- Mantener el número del episodio cuando exista.
- Usar el título real del contenido; evitar títulos genéricos o promesas no sustentadas.
- Añadir 1–2 emojis relevantes sin sustituir palabras ni dificultar la lectura.

## Descripción de Spotify

- Escribir 2–3 frases y aproximadamente 35–70 palabras.
- Anticipar el tema, la tensión y el beneficio de escuchar sin revelar la conclusión.
- Usar 2–3 emojis relevantes distribuidos naturalmente.
- No repetir el título como primera oración.
- No inventar datos, invitados, resultados ni enlaces.
- No revelar, resumir ni insinuar la respuesta de la `Tarea de hoy`.
- Evitar spoilers, listas exhaustivas o conclusiones que eliminen la curiosidad.

## Instagram

Crear:

1. Hook de una o dos líneas.
2. Dos o tres ideas de valor extraídas del episodio.
3. CTA para escuchar El Diario de AMI.
4. Emojis moderados y de 3 a 6 hashtags relevantes.

Evitar plantillas idénticas entre episodios y errores como dobles signos, espacios defectuosos o frases cortadas.
