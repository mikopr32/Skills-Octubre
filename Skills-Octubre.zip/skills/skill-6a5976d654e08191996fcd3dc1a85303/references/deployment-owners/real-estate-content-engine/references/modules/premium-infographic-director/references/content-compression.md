# Compresión de contenido

## Objetivo

Reducir sin cambiar significado, precisión ni promesa. Cada palabra visible debe ayudar a identificar, comparar, recordar o actuar.

## Límites recomendados

| Elemento | Instagram/Facebook 4:5 | Flyer A4 |
|---|---:|---:|
| Título | 4–10 palabras | 4–12 palabras |
| Subtítulo opcional | Hasta 15 palabras | Hasta 20 palabras |
| Unidades informativas | 4–6 | 4–7 |
| Encabezado por unidad | 2–6 palabras | 2–7 palabras |
| Apoyo por unidad | 4–14 palabras | 6–24 palabras |
| Total visible orientativo | 60–110 palabras | 100–220 palabras |

Tratar estos límites como guardrails, no como metas de relleno.

## Método

1. Escribir la tesis en una frase.
2. Marcar hechos y términos que no pueden cambiar.
3. Agrupar ideas repetidas.
4. Elegir de cuatro a siete ideas que sostengan la tesis.
5. Convertir cada idea en encabezado + una línea de apoyo.
6. Eliminar introducción, transición, conclusión y redundancia.
7. Leer únicamente títulos y encabezados; deben contar la historia por sí solos.
8. Eliminar cualquier bloque final que repita la tesis como «resumen», «conclusión» o «idea clave», salvo que sea contenido obligatorio del usuario.

## Exactitud

- Copiar literalmente nombres, precios, porcentajes, fechas, direcciones y citas aprobadas.
- No redondear cifras sin indicarlo.
- No convertir correlación en causalidad.
- No añadir superlativos que la fuente no sostenga.
- Mantener una versión canónica del copy antes de producir el arte.

## Señales de sobrecarga

- Más de siete bloques.
- Más de dos tamaños de cuerpo.
- Párrafos de tres líneas o más en 4:5.
- Necesidad de reducir el cuerpo por debajo de lectura móvil cómoda.
- Todos los elementos compiten con el título.

Ante sobrecarga, eliminar, agrupar o dividir en serie.
