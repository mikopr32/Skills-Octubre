# Esquema y puntuación V2

## Esquema CSV

Usar la plantilla en `assets/content-intelligence-v2-template.csv`.

Campos principales:

`competitor,platform,url,published_at,consulted_at,format,topic,hook,cta,followers,views,likes,comments,shares,saves,age_days,comments_sampled,comment_quality,recruitment_intent,questions_count,resource_requests,community_questions,reported_actions`

Dejar vacío lo desconocido; no usar cero. Usar números enteros sin separadores. Los ceros se reservan para métricas observadas cuyo valor sea realmente cero.

## Firma de comparabilidad

Crear `metric_signature` con las métricas públicas presentes, por ejemplo `likes+comments` o `likes+comments+shares`. Comparar resonancia solo entre piezas con la misma cuenta, plataforma, formato y firma. Exigir cinco piezas por grupo.

## Scores separados

### Reach Score

Usar `views / followers` cuando ambos existan; de lo contrario, usar vistas. Comparar contra la mediana del grupo compatible y limitar el índice relativo a 3× antes de convertirlo a 0–100.

### Resonance Score

Usar interacción por vista cuando haya vistas; de lo contrario, interacción por seguidores. Incluir únicamente métricas de la firma. Combinar 70% rendimiento relativo y 30% calidad de conversación cuando ambos existan; redistribuir pesos entre datos disponibles.

### Recruitment Signal Score

Combinar intención cualitativa con tasas visibles de solicitudes de recurso y preguntas sobre comunidad. Exigir muestra de comentarios. Marcar confianza baja con menos de cinco comentarios muestreados.

No crear un score total predeterminado. Alcance, resonancia e intención responden preguntas diferentes.

## Puntuación de oportunidad editorial

Puntuar de 0 a 5: demanda, rendimiento, relevancia, diferenciación, encaje, facilidad, saturación y riesgo.

`base = 0.20 demanda + 0.15 rendimiento + 0.20 relevancia + 0.15 diferenciación + 0.15 encaje + 0.15 facilidad`

`penalización = 0.10 saturación + 0.10 riesgo`

`oportunidad = max(0, min(100, base / 5 * 100 - penalización / 5 * 100))`

- 80–100: producir y probar pronto.
- 65–79: priorizar con un ángulo distintivo.
- 50–64: experimento limitado.
- Menos de 50: posponer o replantear.

No calcular cuando falte más de la mitad de los componentes.
