# Protocolos por plataforma

## Índice

1. Reglas comunes
2. YouTube
3. Instagram
4. TikTok
5. Facebook
6. Podcasts, sitios y webinars
7. Fuentes de dolor
8. Reglas de parada

## 1. Reglas comunes

Usar buscadores para descubrir y la fuente original para verificar. Registrar URL directa, fecha de publicación, fecha de consulta y métricas visibles. No convertir abreviaturas redondeadas en cifras exactas. Separar contenido reciente de contenido popular.

Construir consultas con combinaciones de:

- `coach inmobiliario`, `entrenamiento para agentes`, `captación de agentes`, `reclutamiento inmobiliario`;
- `real estate coach español`, `real estate agents en español`, `brokerage latino`;
- dolor: `no consigo clientes`, `cómo conseguir listings`, `seguimiento`, `CRM`, `marca personal`, `IA para Realtors`;
- ubicación: Estados Unidos, Florida, Orlando, Tampa, Miami, Texas, Georgia u otra región solicitada.

## 2. YouTube

Priorizar canal oficial y pestañas de videos, Shorts, lives y playlists. Capturar una mezcla de publicaciones recientes y populares. Usar vistas, fecha, duración y comentarios visibles. No asumir retención, CTR, suscriptores ganados ni leads sin acceso autorizado a Analytics.

Comparar videos largos con videos largos y Shorts con Shorts. Codificar título/hook, miniatura, promesa, estructura, CTA, lead magnet y oferta. Leer comentarios de piezas prioritarias para detectar preguntas y lenguaje del agente.

## 3. Instagram

Usar perfil y publicaciones públicas. Separar Reels, carruseles, imágenes y lives. Capturar vistas o reproducciones, likes y comentarios solo cuando sean visibles. Guardados, compartidos, alcance, visitas y DMs requieren datos autorizados; marcarlos `ND` en análisis externo.

Si la interfaz bloquea el contenido, verificar enlaces alternos oficiales o publicaciones incrustadas. No usar snippets de buscador como evidencia de métricas.

## 4. TikTok

Usar perfil y videos públicos. Capturar vistas, likes, comentarios y compartidos cuando aparezcan. Separar videos fijados de la muestra cronológica. Comparar duración y antigüedad similares. Revisar comentarios para preguntas específicas, no solo volumen.

## 5. Facebook

Usar páginas y grupos públicos sin intentar entrar a espacios privados. Distinguir publicaciones orgánicas, lives, eventos y anuncios. Las reacciones no son equivalentes a likes de otras plataformas. Registrar el tipo de reacción solo cuando sea material.

## 6. Podcasts, sitios y webinars

Usarlos para estudiar posicionamiento, temas, profundidad, oferta, frecuencia y CTA. No inferir rendimiento a partir del orden mostrado. Registrar episodios repetidos, invitados, lead magnets, programas, precios públicos y rutas de conversión.

## 7. Fuentes de dolor

Triangular contenido de coaches con lenguaje directo de agentes en:

- comentarios de YouTube, Instagram, TikTok y Facebook públicos;
- comunidades y foros públicos de agentes;
- Reddit y preguntas abiertas indexadas;
- reseñas públicas de herramientas o programas;
- estudios y encuestas primarias de asociaciones inmobiliarias;
- sugerencias de búsqueda y tendencias, tratadas como señales y no como volumen exacto.

No tomar una queja aislada como patrón. Buscar repetición entre al menos dos tipos de fuente.

## 8. Reglas de parada

- Tras tres intentos fallidos de abrir contenido de un perfil, marcar `acceso restringido` y continuar.
- No sustituir métricas inaccesibles con valores de terceros sin metodología verificable.
- Detener la captura cuantitativa cuando no existan cinco piezas comparables por grupo; producir análisis cualitativo.
- Considerar Estándar completo con 8 competidores y 60 piezas verificadas; aspirar a 100–150 si el acceso lo permite.
- Informar cobertura exacta por plataforma, cuenta y formato.
