# Rúbrica de calidad

## Puntuación

Puntuar de 1 a 10 cada dimensión:

| Dimensión | Criterio de aprobación |
|---|---|
| Exactitud | Todo el copy, cifras y nombres coinciden con la versión canónica |
| Legibilidad | Lectura clara al tamaño de publicación y sin texto sobre fondos ruidosos |
| Jerarquía | Título, tesis y secuencia se entienden inmediatamente |
| Composición | Balance, alineación, ritmo y punto focal sólidos |
| Área segura | Ningún elemento crítico invade aproximadamente el 10% exterior |
| Contraste | Texto y símbolos se distinguen de su fondo |
| Síntesis | No hay redundancia ni bloques prescindibles |
| Consistencia | Paleta, tipografía, iconografía y estilos son coherentes |
| Fidelidad | El diseño representa correctamente el contenido y la marca |
| Utilidad | La pieza funciona en el canal y formato solicitados |

Promedio mínimo: 9/10. Ninguna dimensión puede quedar por debajo de 8/10.

## Inspección obligatoria

1. Confirmar dimensiones y orientación con `python3 scripts/validate_infographic.py`, resolviendo la ruta desde el directorio del skill.
2. Inspeccionar la pieza completa.
3. Inspeccionar a resolución original cuando haya texto pequeño, logos o cifras.
4. Comparar palabra por palabra contra el copy canónico.
5. Revisar bordes, recortes, alineación, solapamientos, manos, rostros e íconos.
6. Simular lectura rápida: identificar título, idea principal y recorrido en menos de diez segundos.
7. Registrar mentalmente las puntuaciones antes de aprobar.
8. Confirmar que no se añadió pie, resumen, conclusión, «idea clave» ni consejo no solicitado.

## Recuperación

- Corregir una causa por iteración.
- Preservar explícitamente los elementos correctos.
- Si falla texto generado, cambiar a composición determinista.
- Si falla densidad, reducir copy antes de reducir tamaño.
- Si falla jerarquía, cambiar escala y posición antes de añadir color.
- Si falla identidad, volver a la referencia original; no seguir editando una derivación degradada.
