#!/usr/bin/env python3
"""Generate one episode voice track with ElevenLabs and resumable chunks."""

from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
from pathlib import Path

VOICE_ID = "x1DOrfLtuvhgvW0jYdsS"
MODEL_ID = "eleven_multilingual_v2"


def chunks(text: str, limit: int = 4200) -> list[str]:
    sentences = re.split(r"(?<=[.!?…])\s+", text.strip())
    result, current = [], ""
    for sentence in sentences:
        if len(sentence) > limit:
            raise ValueError("Una oración excede el límite; revisar el guion.")
        candidate = f"{current} {sentence}".strip()
        if len(candidate) > limit and current:
            result.append(current)
            current = sentence
        else:
            current = candidate
    if current:
        result.append(current)
    return result


def generate(api_key: str, text: str, output: Path) -> None:
    url = f"https://api.elevenlabs.io/v1/text-to-speech/{VOICE_ID}?output_format=mp3_44100_128"
    payload = {
        "text": text,
        "model_id": MODEL_ID,
        "voice_settings": {"stability": 0.5, "similarity_boost": 0.75},
    }
    for attempt in range(5):
        request = urllib.request.Request(
            url,
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "xi-api-key": api_key,
                "Accept": "audio/mpeg",
                "Content-Type": "application/json",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=180) as response:
                output.write_bytes(response.read())
                return
        except urllib.error.HTTPError as exc:
            detail = exc.read(300).decode("utf-8", errors="replace")
            if exc.code not in {408, 429, 500, 502, 503, 504}:
                raise RuntimeError(f"ElevenLabs HTTP {exc.code}: {detail}") from exc
            delay = int(exc.headers.get("Retry-After", 0)) or 2**attempt
            time.sleep(min(delay, 30))
        except urllib.error.URLError:
            time.sleep(min(2**attempt, 30))
    raise RuntimeError("ElevenLabs no respondió después de 5 intentos.")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("manifest", type=Path)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    api_key = os.getenv("ELEVENLABS_API_KEY")
    if not api_key:
        print("Falta ELEVENLABS_API_KEY.", file=sys.stderr)
        return 2
    manifest = json.loads(args.manifest.read_text(encoding="utf-8"))
    script_path = Path(manifest["files"]["script"])
    output = args.manifest.parent / "voice.mp3"
    if output.exists() and not args.force:
        print(json.dumps({"ok": True, "resumed": True, "output": str(output)}))
        return 0
    parts = chunks(script_path.read_text(encoding="utf-8"))
    with tempfile.TemporaryDirectory(prefix="ami-voice-") as temp_name:
        temp = Path(temp_name)
        files = []
        for index, part in enumerate(parts, 1):
            target = temp / f"chunk-{index:03d}.mp3"
            generate(api_key, part, target)
            files.append(target)
        concat = temp / "concat.txt"
        concat.write_text("".join(f"file '{p.as_posix()}'\n" for p in files), encoding="utf-8")
        subprocess.run(
            ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-f", "concat", "-safe", "0",
             "-i", str(concat), "-ar", "44100", "-b:a", "192k", str(output)],
            check=True,
        )
    manifest["files"]["voice"] = str(output.resolve())
    manifest["status"] = "voice-generated"
    args.manifest.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"ok": True, "chunks": len(parts), "output": str(output.resolve())}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
