# Contratos de agentes

## Paquete común

Proporcionar a cada agente: objetivo, modo, audiencia, geografía, fecha de corte, restricciones y entregable. No compartir borradores prematuros con búsqueda o análisis si pueden anclar la investigación.

Usar exactamente `APPROVE`, `REVISE` o `BLOCKED` en `STATUS`. No aceptar sinónimos, estados compuestos ni traducciones. Explicar matices en `OPEN_ISSUES`.

## Búsqueda

Entrada: tema, criterios editoriales, fecha de corte y política de fuentes.

Salida: cinco a diez hallazgos; registro con afirmación, dato, geografía, periodo, fuente, fecha, URL, confianza y limitación; contradicciones; vacíos; fuentes descartadas.

Prohibido: redactar, elegir título por intuición o usar snippets como fuente.

## Análisis

Entrada: registro de evidencia aprobado.

Salida: ángulo; hechos versus interpretación; implicaciones; tres a cinco acciones; trade-offs; riesgos; KPIs; outline; claims aprobados y prohibidos.

Prohibido: añadir hechos que no estén en el registro.

## Títulos y hooks

Entrada: ángulo, audiencia, keyword, evidencia y limitaciones.

Salida: cinco combinaciones de título y hook, cada una puntuada en claridad, especificidad, relevancia, credibilidad, SEO y curiosidad honesta; recomendación y trade-off.

Prohibido: prometer resultados, ocultar el tema o exagerar el alcance.

## Escritor

Entrada: registro congelado, análisis, outline y combinación elegida.

Salida: artículo, meta description, slug, CTA, fuentes y notas de vigencia.

Prohibido: investigar por su cuenta, inventar transiciones factuales, copiar estructura o presentar ejemplos ficticios como reales.

## Analizador de percepción

Entrada: borrador completo, promesa, audiencia y criterios.

Salida: puntuaciones 1–10 en claridad, credibilidad, relevancia, utilidad, diferenciación y acción; audiencia/mensaje percibidos; emoción; confianza; fricciones; banderas; veredicto; instrucciones al rol responsable.

Prohibido: reescribir silenciosamente o aprobar con bandera crítica.

Si falta el borrador íntegro, las fuentes o la promesa editorial, devolver `STATUS: BLOCKED`; no puntuar ni aprobar desde un resumen.

## Formato de traspaso

Cerrar cada entrega con:

```text
STATUS: APPROVE | REVISE | BLOCKED
CONFIDENCE: HIGH | MEDIUM | LOW
HANDOFF: <entregable estructurado>
OPEN_ISSUES: <vacíos o ninguno>
```

El orquestador debe rechazar entregables sin trazabilidad o fuera del rol.
