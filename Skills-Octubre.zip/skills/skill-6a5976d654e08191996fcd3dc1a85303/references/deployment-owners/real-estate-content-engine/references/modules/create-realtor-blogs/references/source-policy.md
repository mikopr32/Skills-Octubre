# Política de fuentes y verificación

## Jerarquía

### Nivel 1 — Originales y primarias

- Census Bureau, HUD, BLS, BEA, CFPB, Federal Reserve/FRED, FHFA y autoridades estatales.
- Freddie Mac, Fannie Mae, FHA, VA y USDA.
- NAR, asociaciones estatales/locales, NAHB y MLS accesibles.
- Documentación, newsroom, políticas y centros de transparencia oficiales de Meta, Google, YouTube, TikTok, LinkedIn, Instagram y proveedores de IA.
- Papers, datasets y reportes metodológicos originales.

### Nivel 2 — Investigación y periodismo sectorial

- Zillow Research/News, Redfin News/Data Center, Realtor.com Research y Trulia cuando exista trabajo original pertinente.
- ATTOM, CoreLogic/Cotality, ICE, MBA y proveedores reconocidos.
- HousingWire, Inman, RISMedia, RealTrends y publicaciones con autor, fecha y atribución.
- Medios económicos o tecnológicos reputados que enlacen la evidencia original.

### Nivel 3 — Solo descubrimiento

- Blogs de agencias, vendors y coaches.
- Newsletters, podcasts, videos y publicaciones sociales.
- Artículos SEO que resumen otras fuentes.

Usarlos para hallar preguntas o ángulos, no para sustentar cifras materiales si existe el original.

## Reglas por tema

### Mercado inmobiliario

- Anotar geografía, periodo, propiedad, métrica y metodología.
- No confundir precio de lista con venta, inventario con listings nuevos ni una tasa menor con affordability garantizada.
- Comparar solo métricas con definiciones compatibles.

### Noticias y regulación

- Buscar norma, comunicado, acuerdo, formulario o autoridad original.
- Distinguir propuesta, aprobación, fecha efectiva e implementación.
- Señalar cuándo corresponde consultar broker, asociación o abogado.

### Marketing y redes

- Confirmar funciones y restricciones en documentación oficial.
- No presentar rumores sobre algoritmos como hechos.
- Priorizar conversaciones, citas, leads calificados, costo por oportunidad y cierres atribuidos sobre views.

### Inteligencia artificial

- Verificar fecha, modelo, plan, región y disponibilidad.
- Distinguir anuncio, documentación y prueba independiente.
- Cubrir privacidad, exactitud, copyright, sesgo y Fair Housing cuando corresponda.

## Frescura y citas

- Priorizar el periodo solicitado y comprobar correcciones o actualizaciones.
- Citar el periodo del dato, no solo el año de publicación.
- Verificar herramientas y plataformas el mismo día cuando sea posible.
- Enlazar la página que respalda la afirmación, no resultados de búsqueda.
- Para hechos de alto impacto, exigir dos fuentes independientes y al menos una primaria.
- Sintetizar y parafrasear; evitar traducciones literales o pasajes extensos.

## Confianza

- **Alta:** fuente primaria, dato compatible y vigente.
- **Media:** investigación reconocida o dos fuentes secundarias concordantes.
- **Baja:** metodología incompleta o fuente indirecta única. No publicar como hecho.
