# Marco editorial

## Promesa

Ayudar al Realtor hispano a comprender un cambio, tomar una decisión y ejecutar una acción medible. No limitarse a traducir noticias en inglés.

## Estructura base

1. Título específico.
2. Introducción de 80–140 palabras: cambio, importancia y promesa.
3. Qué está ocurriendo: hechos, fechas y alcance.
4. Qué significa para Realtors hispanos: interpretación sin generalizar.
5. Impacto: leads, conversión, servicio, productividad, riesgo o posicionamiento.
6. Plan de acción: tres a cinco acciones ordenadas.
7. Cómo medirlo: uno a tres KPIs.
8. Riesgos o errores comunes.
9. Conclusión y CTA.

## SEO y AEO

- Asignar intención informativa, comparativa, operacional o local.
- Seleccionar keyword primaria natural y tres a seis conceptos relacionados.
- Responder la pregunta principal en las primeras 120 palabras.
- Usar H2 descriptivos que funcionen como respuestas independientes.
- Evitar repetición artificial de keywords.
- Proponer enlaces internos por tema o título, nunca URLs inventadas.
- Añadir FAQ solo si contiene preguntas distintas y útiles.

## Voz

- Español natural para profesionales en Estados Unidos; usar “tú” por defecto.
- Conservar lead, follow-up, CRM, listing, open house o broker cuando sean más reconocibles.
- Preferir ejemplos y verbos concretos.
- Evitar clichés, alarmismo, “secreto”, “revolucionario” y “garantizado”.
- Mantener párrafos de dos a cuatro oraciones.

## KPIs sugeridos

- Contenido: lectura, guardados, clics y conversaciones cualificadas.
- Lead generation: leads calificados, costo por lead, citas y costo por oportunidad.
- Follow-up: tiempo de respuesta, contacto a conversación, cita y contrato.
- IA: tiempo ahorrado, error, revisión humana y adopción.
- Marca: búsquedas, tráfico directo, menciones y oportunidades atribuidas.

## Percepción

Evaluar desde cinco lentes: Realtor hispano ocupado, profesional escéptico, principiante, experto y cliente/público externo. Determinar si entiende rápidamente por qué importa, confía en los datos, puede ejecutar, encuentra análisis original y evita interpretar promesas o generalizaciones.

Reportar audiencia percibida, mensaje principal, emoción dominante, nivel de confianza, acción probable, fricciones, frases dudosas y correcciones prioritarias.

## Derivados opcionales

Solo por solicitud: extracto, caption, email, guion HVC, carrusel, FAQs, prompt de imagen, versión inglesa o especificaciones CMS.
