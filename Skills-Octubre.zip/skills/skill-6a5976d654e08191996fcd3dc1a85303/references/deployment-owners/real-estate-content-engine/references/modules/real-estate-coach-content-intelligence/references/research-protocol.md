# Protocolo de investigación

## Índice

1. Jerarquía de fuentes
2. Diseño de muestra
3. Captura
4. Verificación
5. Síntesis

## 1. Jerarquía de fuentes

Priorizar:

1. Publicación, canal, sitio, podcast o página oficial del creador.
2. Datos visibles de la plataforma original.
3. Entrevistas, eventos y colaboraciones donde el creador habla directamente.
4. Estudios primarios de asociaciones, plataformas o instituciones.
5. Fuentes secundarias confiables para contexto.

Usar resultados de búsqueda y snippets solo para descubrimiento. No atribuir métricas o frases importantes sin abrir una fuente que las sostenga. Registrar fecha de consulta porque las métricas cambian.

## 2. Diseño de muestra

Combinar:

- piezas publicadas recientemente para medir la estrategia actual;
- piezas con desempeño alto para detectar patrones históricos;
- distintos formatos para no sesgar el análisis hacia video corto;
- cuentas grandes, medianas y emergentes;
- creadores directos, adyacentes y aspiracionales.

Cuando una plataforma ordene por popularidad, tomar también una muestra cronológica. Evitar seleccionar manualmente solo ejemplos que confirmen una hipótesis.

Ventanas sugeridas:

- Radar: últimos 30–90 días.
- Estándar: últimos 90–180 días.
- Profundo: 6–12 meses, con cortes trimestrales.

## 3. Captura

Registrar una fila por contenido usando el esquema de `scoring-and-schema.md`. Capturar el texto exacto del hook solo cuando sea breve y necesario; para el resto, parafrasear.

Codificar estas variables:

- tema: leads, prospección, conversión, marca, contenido, IA, CRM, disciplina, equipo, brokerage, finanzas, mercado u otro;
- formato: reel, video largo, carrusel, imagen, live, podcast, email, webinar u otro;
- mecanismo: lista, tutorial, opinión, historia, caso, reacción, entrevista, detrás de cámaras o reto;
- CTA: comentar, guardar, compartir, DM, descargar, registrarse, llamar, aplicar, unirse o ninguno;
- etapa: atraer, resolver, demostrar o invitar.

## 4. Verificación

Aplicar estas reglas:

- Confirmar que el perfil pertenece a la persona o empresa correcta.
- Separar fecha de publicación y fecha de consulta.
- Marcar números aproximados cuando la interfaz los redondee.
- No sumar métricas incompatibles entre plataformas.
- No inferir guardados, compartidos, DMs, leads o ventas cuando no sean públicos.
- Guardar URL directa por fila; si no existe una URL estable, describir la limitación.
- Citar al menos una evidencia por conclusión importante y dos cuando la conclusión sea transversal.

## 5. Síntesis

Buscar repetición y contraste. Una pieza aislada genera una hipótesis; varias piezas comparables sostienen un patrón. Presentar resultados con tamaño de muestra y cobertura.

Usar esta escala de confianza:

- **Alta:** patrón repetido y respaldado por varias fuentes directas.
- **Media:** señal consistente pero con muestra o acceso limitado.
- **Baja:** hipótesis útil que requiere prueba.
