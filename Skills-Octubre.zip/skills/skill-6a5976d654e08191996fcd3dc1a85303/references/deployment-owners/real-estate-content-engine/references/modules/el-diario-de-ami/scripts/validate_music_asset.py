#!/usr/bin/env python3
"""Validate the official music asset before production."""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("music", type=Path)
    parser.add_argument("--manifest", type=Path)
    args = parser.parse_args()
    if not args.music.is_file():
        raise FileNotFoundError(args.music)
    probe = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration,format_name",
         "-of", "json", str(args.music)],
        check=True, capture_output=True, text=True,
    )
    data = json.loads(probe.stdout)
    seconds = float(data["format"]["duration"])
    if seconds < 53:
        raise ValueError("La canción debe durar al menos 53 segundos.")
    digest = hashlib.sha256(args.music.read_bytes()).hexdigest()
    manifest_path = args.manifest
    if manifest_path is None and (args.music.parent / "music-manifest.json").exists():
        manifest_path = args.music.parent / "music-manifest.json"
    if manifest_path:
        expected = json.loads(manifest_path.read_text(encoding="utf-8"))
        if expected.get("sha256") and digest != expected["sha256"]:
            raise ValueError("La huella SHA-256 no coincide con la canción oficial.")
        if expected.get("size_bytes") and args.music.stat().st_size != expected["size_bytes"]:
            raise ValueError("El tamaño no coincide con la canción oficial.")
    print(json.dumps({"ok": True, "duration": seconds, "sha256": digest, "file": str(args.music.resolve())}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
