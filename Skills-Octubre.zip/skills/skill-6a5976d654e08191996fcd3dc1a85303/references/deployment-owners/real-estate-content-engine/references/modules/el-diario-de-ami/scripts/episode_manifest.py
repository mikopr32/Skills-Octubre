#!/usr/bin/env python3
"""Update episode metadata, assign weekday publish dates, and advance states."""

from __future__ import annotations

import argparse
import json
from datetime import date, datetime, time, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

STATES = [
    "received",
    "extracted",
    "voice-generated",
    "mixed",
    "quality-approved",
    "user-approved",
    "scheduled",
    "verified",
]


def load(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def save(path: Path, data: dict) -> None:
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def next_weekday(day: date) -> date:
    while day.weekday() >= 5:
        day += timedelta(days=1)
    return day


def assign(batch_path: Path, first_date: date) -> None:
    batch = load(batch_path)
    day = next_weekday(first_date)
    tz = ZoneInfo("America/New_York")
    for manifest_name in batch["episodes"]:
        path = Path(manifest_name)
        manifest = load(path)
        manifest["publish_at"] = datetime.combine(day, time(6, 0), tzinfo=tz).isoformat()
        save(path, manifest)
        day = next_weekday(day + timedelta(days=1))


def update(path: Path, metadata_path: Path) -> None:
    manifest = load(path)
    metadata = load(metadata_path)
    allowed = {
        "title",
        "spotify_summary",
        "instagram_copy",
        "artwork",
        "explicit",
        "promotional",
        "season",
        "episode_type",
    }
    manifest.update({k: v for k, v in metadata.items() if k in allowed})
    if "artwork" in metadata:
        manifest.setdefault("files", {})["artwork"] = metadata["artwork"]
    save(path, manifest)

def validate_verified_evidence(evidence: dict) -> None:
    required_true = {
        "artwork_visible",
        "title_visible",
        "description_visible",
        "episode_number_visible",
        "publish_at_visible",
        "status_visible",
    }
    missing = sorted(key for key in required_true if evidence.get(key) is not True)
    if evidence.get("show_id") != "44eP54c72vtJWibRBeXj57":
        missing.append("show_id")
    if missing:
        raise ValueError(
            "No se puede verificar: faltan comprobaciones visibles: "
            + ", ".join(missing)
        )


def set_status(path: Path, status: str, evidence_path: Path | None) -> None:
    if status not in STATES:
        raise ValueError(f"Estado inválido: {status}")
    manifest = load(path)
    current = manifest.get("status", "received")
    if STATES.index(status) > STATES.index(current) + 1:
        raise ValueError(f"No se puede saltar de {current} a {status}.")
    if status in {"scheduled", "verified"} and evidence_path is None:
        raise ValueError("La programación/verificación requiere evidencia.")
    evidence = load(evidence_path) if evidence_path else None
    if status == "verified":
        validate_verified_evidence(evidence or {})
    manifest["status"] = status
    if evidence_path:
        manifest.setdefault("evidence", {})[status] = evidence
    save(path, manifest)


def main() -> int:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    schedule = sub.add_parser("schedule")
    schedule.add_argument("batch", type=Path)
    schedule.add_argument("--first-date", required=True, type=date.fromisoformat)
    meta = sub.add_parser("metadata")
    meta.add_argument("manifest", type=Path)
    meta.add_argument("--from-json", required=True, type=Path)
    state = sub.add_parser("status")
    state.add_argument("manifest", type=Path)
    state.add_argument("state", choices=STATES)
    state.add_argument("--evidence-json", type=Path)
    args = parser.parse_args()
    if args.command == "schedule":
        assign(args.batch, args.first_date)
    elif args.command == "metadata":
        update(args.manifest, args.from_json)
    else:
        set_status(args.manifest, args.state, args.evidence_json)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
