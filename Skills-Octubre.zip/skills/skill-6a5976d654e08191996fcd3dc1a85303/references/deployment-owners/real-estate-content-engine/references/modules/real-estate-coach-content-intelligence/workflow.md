# Módulo de método

Aplicar únicamente dentro de los límites del controlador SKILL.md del owner.

# Inteligencia de contenido para coaches inmobiliarios

## Versión operativa V2

Aplicar protocolos de captura por plataforma, puntuación multidimensional, rúbricas objetivas de comentarios y atribución hasta conversación o incorporación. Evitar un ranking único: separar alcance, resonancia e intención de reclutamiento.

## Objetivo

Convertir evidencia pública sobre competidores y agentes inmobiliarios en un sistema de contenido original que genere atención, confianza, participación y solicitudes de ingreso a una comunidad. Investigar antes de idear. Distinguir hechos, inferencias y recomendaciones.

## Principios obligatorios

- Usar información pública, accesible y permitida. No evadir autenticación, CAPTCHA, límites técnicos ni restricciones de plataforma.
- Navegar la web para obtener información actual. Citar la URL directa y la fecha de consulta de cada evidencia material.
- No confundir popularidad con conversión. Etiquetar las métricas de reclutamiento como desconocidas salvo evidencia verificable.
- No copiar guiones, diseños, nombres de series ni propuestas distintivas. Extraer patrones y crear ángulos originales.
- No recolectar datos personales privados ni perfilar individuos vulnerables.
- No desprestigiar competidores. Comparar posicionamiento, formatos, ofertas y respuesta observable.
- Declarar limitaciones de muestra, acceso, plataforma y atribución.

## Configurar el encargo

Confirmar o inferir, sin bloquear si hay contexto suficiente:

1. Mercado geográfico y lengua.
2. Plataformas prioritarias.
3. Tipo de agente a atraer: nuevo, productor estancado, team leader, independiente, bilingüe u otro.
4. Comunidad, oferta, diferenciador y CTA disponibles.
5. Horizonte: contenido inmediato, 30 días, campaña o monitoreo recurrente.
6. Profundidad de análisis.

Usar estos niveles:

| Nivel | Muestra orientativa | Uso |
| --- | ---: | --- |
| Radar | 5 competidores / 30 piezas | Respuesta rápida y exploratoria |
| Estándar | 8–12 competidores / 100–150 piezas | Estrategia mensual; opción predeterminada |
| Profundo | 15–25 competidores / 300+ piezas | Posicionamiento, campaña o revisión trimestral |

No afirmar que la muestra representa “todo el mercado”. Si faltan datos críticos, indicar el supuesto adoptado y cómo podría cambiar la recomendación.

Aplicar estas condiciones de suficiencia:

- Considerar Estándar completo con al menos 8 competidores y 60 piezas verificadas, procurando 100–150.
- Considerar comparativa cuantitativa válida solo cuando existan al menos 5 piezas por cuenta, plataforma, formato y conjunto de métricas visibles.
- Reclasificar como Radar ampliado si el acceso no permite la muestra mínima. No rellenar huecos con estimaciones.

Para Michael Cruz, leer [michael-cruz-context.md](references/michael-cruz-context.md) cuando la solicitud mencione AXEN Latino, AMI, reclutamiento de agentes hispanos o su comunidad.

## Ejecutar el sistema

### 1. Construir el universo competitivo

Clasificar candidatos en tres grupos:

- **Directos:** coaches inmobiliarios hispanos, comunidades o programas que compiten por la misma audiencia.
- **Adyacentes:** brokers, team leaders, recruiters, entrenadores de ventas y creadores de tecnología para agentes.
- **Aspiracionales:** coaches no hispanos con formatos, distribución o comunidad destacables.

Descubrir candidatos mediante búsqueda web, perfiles públicos, canales, podcasts, eventos y menciones cruzadas. Verificar que cada candidato esté activo y sea relevante. Registrar por qué fue incluido.

### 2. Recoger una muestra comparable

Leer [research-protocol.md](references/research-protocol.md) antes de una investigación Estándar o Profunda.
Leer [platform-collection.md](references/platform-collection.md) antes de capturar contenido en redes o podcasts. Usar [content-intelligence-v2-template.csv](assets/content-intelligence-v2-template.csv) para la captura estructurada.

Capturar, cuando sea visible:

- plataforma, autor, URL, fecha, formato y tema;
- hook, promesa, estructura, CTA y oferta;
- vistas, likes, comentarios, compartidos, guardados y seguidores;
- señales cualitativas en comentarios: preguntas, objeciones, intención, testimonios y solicitudes;
- relación con captación, comunidad, coaching o recruiting.

Equilibrar piezas recientes y piezas sobresalientes. Comparar dentro de la misma plataforma y, de ser posible, dentro de la misma cuenta y formato. Marcar métricas ausentes como `ND`; nunca convertirlas en cero.

### 3. Normalizar y clasificar rendimiento

Leer [scoring-and-schema.md](references/scoring-and-schema.md). Usar métricas normalizadas cuando existan denominadores válidos:

- tasa de visualización;
- engagement por seguidores o vistas;
- velocidad de interacción;
- índice relativo contra la mediana de la misma cuenta, plataforma y formato;
- calidad de comentarios e intención observable.

Leer [comment-intent-rubric.md](references/comment-intent-rubric.md) antes de puntuar comentarios. Usar `scripts/score_posts.py` cuando exista un CSV suficiente. Obtener tres resultados separados:

- **Reach Score:** distribución y velocidad relativa.
- **Resonance Score:** interacción comparable y calidad de conversación.
- **Recruitment Signal Score:** preguntas, solicitudes y señales explícitas de próximo paso.

No combinar los tres en una puntuación final salvo que el usuario defina el objetivo y los pesos. Tratar toda puntuación como priorización analítica, no como prueba de ventas o reclutamiento.

### 4. Descubrir el dolor real del agente

Triangular al menos dos tipos de evidencia:

- lenguaje directo: comentarios, preguntas, foros públicos, reseñas o búsquedas;
- comportamiento: temas repetidos, alta respuesta, abandono o controversia;
- evidencia sectorial: estudios, encuestas y fuentes primarias recientes.

Separar:

- **dolor declarado:** lo que el agente dice;
- **problema operativo:** la causa probable;
- **trabajo deseado:** el progreso que intenta conseguir;
- **barrera emocional:** miedo, confusión, vergüenza, saturación o desconfianza;
- **momento de activación:** evento que vuelve urgente el problema.

No presentar una taxonomía genérica como hallazgo. Exigir evidencia para cada dolor priorizado.

### 5. Detectar patrones y espacios vacíos

Identificar:

- temas saturados pero todavía demandados;
- formatos que superan la referencia de cada creador;
- promesas y CTA repetidos;
- preguntas frecuentes mal respondidas;
- segmentos ignorados;
- temas con demanda pero poca profundidad en español;
- contradicciones entre lo que los coaches enseñan y lo que los agentes necesitan ejecutar.

Calcular una puntuación de oportunidad con demanda, rendimiento probado, diferenciación, encaje estratégico y facilidad de producción. Penalizar saturación y riesgo de promesa exagerada.

### 6. Diseñar contenido que reclute por valor

Leer [recruitment-content-system.md](references/recruitment-content-system.md). Construir un portafolio que avance por cuatro funciones:

1. **Atraer:** nombrar el dolor con precisión.
2. **Resolver:** entregar una herramienta, diagnóstico o acción aplicable.
3. **Demostrar:** mostrar proceso, evidencia, comunidad o transformación sin inflar resultados.
4. **Invitar:** ofrecer el siguiente paso de baja fricción.

Mantener una proporción inicial de 70% educación práctica, 20% prueba/comunidad y 10% invitación directa. Ajustar según datos reales.

Para cada idea, incluir: segmento, dolor, insight competitivo, promesa, hook, formato, estructura, CTA, etapa del recorrido, esfuerzo y KPI principal.

### 7. Instrumentar atribución y experimentos

Leer [attribution-and-experiments.md](references/attribution-and-experiments.md) cuando el encargo incluya campaña, calendario o reclutamiento. Asignar un `content_id`, CTA rastreable y evento de conversión a cada pieza. Conectar contenido, lead magnet, evento, conversación, candidato cualificado e incorporación sin atribuir todo al último clic.

### 8. Entregar decisiones, no acumulación de datos

Producir, según alcance:

1. Resumen ejecutivo con 5–10 decisiones.
2. Mapa competitivo y posicionamiento.
3. Tabla de contenidos destacados con enlaces y métricas observadas.
4. Patrones ganadores por tema, formato, hook y CTA.
5. Mapa de dolores priorizado con evidencia y lenguaje textual breve.
6. Espacios vacíos y ventajas defendibles.
7. De 3 a 5 pilares editoriales.
8. Calendario o backlog priorizado.
9. Series, hooks, lead magnets y CTA hacia la comunidad.
10. Plan de medición y próximos experimentos.
11. Mapa de atribución y campos que deben llegar al CRM.

Encabezar cada conclusión como `Observado`, `Inferido` o `Recomendado`. Incluir una sección final de limitaciones.

## Métricas de éxito

Medir por capas:

| Capa | KPI principal | Señal de calidad |
| --- | --- | --- |
| Atención | alcance cualificado, retención, visualizaciones | agentes correctos consumen el contenido |
| Resonancia | guardados, compartidos, comentarios con contexto | el contenido resuelve o articula un dolor |
| Confianza | visitas al perfil, respuestas, consumo recurrente | la audiencia busca más profundidad |
| Comunidad | leads, registros, asistencia, solicitudes | el CTA produce intención verificable |
| Reclutamiento | conversaciones, candidatos cualificados, ingresos | atribución por contenido o campaña |

Definir línea base, ventana de medición y objetivo antes de recomendar crecimiento porcentual. No usar seguidores como KPI final.

## Fallas que se deben prevenir

- Seleccionar solo competidores famosos y perder relevancia local o hispana.
- Comparar números absolutos de cuentas con tamaños distintos.
- Declarar “mejor contenido” usando solo likes.
- Tomar comentarios virales como representativos de todos los agentes.
- Crear contenido genérico de motivación sin mecanismo, herramienta o prueba.
- Invitar a unirse en todas las publicaciones y erosionar confianza.
- Copiar a la competencia y perder diferenciación.
- Producir un calendario sin hipótesis, KPI ni ciclo de aprendizaje.

## Variantes de solicitud

- **Solo auditoría:** detenerse después de patrones, dolores y oportunidades.
- **Solo estrategia:** usar datos suministrados por el usuario y declarar que no se verificaron externamente.
- **Plan de 30 días:** incluir mezcla de formatos, frecuencia, CTA y experimentos semanales.
- **Monitoreo recurrente:** definir lista estable, frecuencia, cambios que disparan alertas y comparación contra la medición anterior.
- **Creación de piezas:** convertir oportunidades aprobadas en guiones, carruseles, posts, emails o lives; preservar la evidencia que originó cada pieza.
