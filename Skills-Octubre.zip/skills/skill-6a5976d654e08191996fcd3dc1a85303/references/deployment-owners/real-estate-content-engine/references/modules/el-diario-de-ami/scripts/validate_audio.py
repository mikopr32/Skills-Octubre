#!/usr/bin/env python3
"""Run deterministic QA on one mixed episode and update its manifest."""

from __future__ import annotations

import argparse
import json
import re
import subprocess
from pathlib import Path


def probe(path: Path) -> dict:
    result = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries",
         "format=duration,bit_rate:stream=codec_name,sample_rate,channels", "-of", "json", str(path)],
        check=True, capture_output=True, text=True,
    )
    return json.loads(result.stdout)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("manifest", type=Path)
    args = parser.parse_args()
    manifest = json.loads(args.manifest.read_text(encoding="utf-8"))
    final = Path(manifest["files"]["final"])
    voice = Path(manifest["files"]["voice"])
    final_probe, voice_probe = probe(final), probe(voice)
    final_duration = float(final_probe["format"]["duration"])
    voice_duration = float(voice_probe["format"]["duration"])
    checks = {
        "decodable": True,
        "duration_over_30s": final_duration > 30,
        "duration_matches_voice_plus_30s": abs(final_duration - (voice_duration + 30)) <= 1.5,
        "sample_rate_44100": str(final_probe["streams"][0].get("sample_rate")) == "44100",
        "stereo": int(final_probe["streams"][0].get("channels", 0)) == 2,
        "codec_mp3": final_probe["streams"][0].get("codec_name") == "mp3",
    }
    loud = subprocess.run(
        ["ffmpeg", "-hide_banner", "-nostats", "-i", str(final), "-af",
         "loudnorm=I=-16:TP=-1.5:LRA=11:print_format=json", "-f", "null", "-"],
        capture_output=True, text=True,
    )
    match = re.search(r"\{\s*\"input_i\".*?\}", loud.stderr, re.DOTALL)
    loudness = json.loads(match.group(0)) if match else {}
    if loudness:
        integrated = float(loudness["input_i"])
        true_peak = float(loudness["input_tp"])
        checks["loudness_near_minus_16_lufs"] = -17.5 <= integrated <= -14.5
        checks["true_peak_safe"] = true_peak <= -1.0
    else:
        checks["loudness_measured"] = False
    qa = {
        "ok": all(checks.values()),
        "checks": checks,
        "final_duration": final_duration,
        "voice_duration": voice_duration,
        "loudness": loudness,
        "human_listen_required": True,
    }
    qa_path = args.manifest.parent / "qa.json"
    qa_path.write_text(json.dumps(qa, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    manifest["files"]["qa"] = str(qa_path.resolve())
    if qa["ok"]:
        manifest["status"] = "quality-approved"
    else:
        manifest["errors"].append("QA automático falló; revisar qa.json.")
    args.manifest.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(qa, ensure_ascii=False))
    return 0 if qa["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
