#!/usr/bin/env python3
"""Mix the official song with one voice track and loudness-normalize the result."""

from __future__ import annotations

import argparse
import json
import subprocess
import tempfile
from pathlib import Path


def duration(path: Path) -> float:
    result = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=nk=1:nw=1", str(path)],
        check=True, capture_output=True, text=True,
    )
    return float(result.stdout.strip())


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("manifest", type=Path)
    parser.add_argument("--music", required=True, type=Path)
    args = parser.parse_args()
    manifest = json.loads(args.manifest.read_text(encoding="utf-8"))
    voice = Path(manifest["files"]["voice"])
    if not voice.exists() or not args.music.exists():
        raise FileNotFoundError("Falta la voz o la canción oficial.")
    voice_seconds = duration(voice)
    output = args.manifest.parent / "final.mp3"
    with tempfile.TemporaryDirectory(prefix="ami-mix-") as temp_name:
        intermediate = Path(temp_name) / "mix.wav"
        background_end = 15 + voice_seconds
        filters = (
            "[1:a]atrim=0:15,asetpts=PTS-STARTPTS[intro];"
            f"[1:a]atrim=15:{background_end:.3f},asetpts=PTS-STARTPTS,volume=-35dB[bg];"
            "[0:a]aresample=44100,asetpts=PTS-STARTPTS[voice];"
            "[bg][voice]amix=inputs=2:duration=first:dropout_transition=0[body];"
            "[1:a]atrim=38:53,asetpts=PTS-STARTPTS,afade=t=out:st=12:d=3[outro];"
            "[intro][body][outro]concat=n=3:v=0:a=1[mix]"
        )
        subprocess.run(
            ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", str(voice),
             "-stream_loop", "-1", "-i", str(args.music), "-filter_complex", filters,
             "-map", "[mix]", "-t", f"{voice_seconds + 30:.3f}", "-c:a", "pcm_s24le", str(intermediate)],
            check=True,
        )
        subprocess.run(
            ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", str(intermediate),
             "-af", "loudnorm=I=-16:TP=-1.5:LRA=11", "-ar", "44100", "-ac", "2",
             "-c:a", "libmp3lame", "-b:a", "192k", str(output)],
            check=True,
        )
    manifest["files"]["final"] = str(output.resolve())
    manifest["status"] = "mixed"
    args.manifest.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"ok": True, "output": str(output.resolve())}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
