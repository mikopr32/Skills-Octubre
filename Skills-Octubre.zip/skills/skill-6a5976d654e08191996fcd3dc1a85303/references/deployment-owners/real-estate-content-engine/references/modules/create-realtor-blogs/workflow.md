# Módulo de método

Aplicar únicamente dentro de los límites del controlador SKILL.md del owner.

# Crear blogs para Realtors hispanos

## Objetivo

Convertir información reciente y verificable de Estados Unidos en contenido original, útil y publicable en español. Priorizar la consecuencia práctica para el Realtor sobre el simple resumen de noticias.

## Cargar referencias

- Leer `references/source-policy.md` antes de investigar o validar hechos.
- Leer `references/editorial-framework.md` antes de crear títulos, redactar o evaluar percepción.
- Leer `references/agent-contracts.md` antes de delegar trabajo.

## Determinar el modo

Clasificar el encargo como:

1. **Descubrimiento:** investigar y priorizar temas actuales.
2. **Artículo dirigido:** investigar y escribir sobre un tema, mercado o audiencia.
3. **Noticia a blog:** verificar un enlace o noticia y crear una pieza original.
4. **Actualización:** sustituir datos vencidos de un artículo existente.
5. **Plan editorial:** crear una serie o calendario con temas, intención, fuentes y CTA.
6. **Auditoría de percepción:** evaluar un borrador sin reescribirlo salvo autorización.
7. **Descubrimiento + artículo:** puntuar candidatos y escribir únicamente el tema ganador.

Extraer objetivo, audiencia, geografía, longitud, canal, keyword, voz, CTA, fecha de publicación y enlaces internos cuando estén disponibles. No bloquear por preferencias editoriales ausentes; usar los valores predeterminados. Preguntar solo si falta una decisión que cambie materialmente el resultado.

### Valores predeterminados

- Audiencia: Realtors hispanos que trabajan en Estados Unidos.
- Idioma: español claro y natural; conservar términos profesionales en inglés cuando ayuden.
- Geografía: Estados Unidos; declarar cuando un dato sea nacional.
- Longitud: 900–1,400 palabras.
- Objetivo: educar, generar autoridad y provocar una acción profesional.
- Voz: experta, directa, práctica y conversacional.
- CTA: aplicar una recomendación, responder una pregunta o solicitar orientación; no inventar contactos.

## Orquestación obligatoria

Actuar como editor jefe. Usar subagentes cuando estén disponibles y el entorno lo permita. No simular que se usaron agentes si no fue posible iniciarlos; ejecutar sus contratos secuencialmente en el agente principal y declarar la limitación solo si afecta el resultado.

La falta de concurrencia no impide completar el encargo: ejecutar los cinco roles secuencialmente, conservar cada handoff y no mezclar responsabilidades dentro de una misma fase.

Crear cinco roles con contexto mínimo y entregables contractuales:

1. **Agente de búsqueda:** descubrir fuentes y construir el registro de evidencia. No redactar.
2. **Agente de análisis:** convertir evidencia aprobada en ángulo, implicaciones, acciones, riesgos y KPIs. No añadir hechos nuevos sin fuente.
3. **Agente de títulos y hooks:** proponer y puntuar opciones basadas en el análisis aprobado. No usar clickbait ni afirmar más que la evidencia.
4. **Agente escritor:** redactar solo con el registro, análisis y título seleccionados. No investigar ni inventar datos durante la redacción.
5. **Agente analizador de percepción:** evaluar el borrador como lector, Realtor, editor de confianza y revisor de riesgo. No aprobar por cortesía.

### Secuencia

1. Ejecutar búsqueda.
2. Aplicar el gate de evidencia.
3. Ejecutar análisis.
4. Ejecutar títulos/hooks.
5. Ejecutar escritura.
6. Ejecutar percepción.
7. Devolver al rol responsable si falla un gate; permitir máximo dos ciclos completos.
8. Hacer una revisión editorial final en el orquestador.

No ejecutar análisis antes de disponer de evidencia verificable. Títulos y outline pueden avanzar en paralelo únicamente cuando reciben el mismo análisis congelado. Fijar el título antes de cerrar introducción, meta description y slug. Ejecutar percepción siempre después del borrador completo.

## Gates de control

### Gate 1 — Evidencia

Aprobar solo si cada afirmación material tiene fuente directa, fecha, periodo y geografía; las cifras sensibles tienen fuente primaria o dos fuentes independientes; se distinguen fechas; se descartan agregadores sin trazabilidad; y se separan hechos, inferencias e hipótesis.

### Gate 2 — Análisis

Aprobar solo si responde qué cambió, por qué importa, qué debe hacer el Realtor, qué no demuestra la evidencia y cómo medir la recomendación.

### Gate 3 — Título y hook

Aprobar opciones específicas, relevantes, coherentes con la intención de búsqueda y fieles a la evidencia. Rechazar alarmismo, promesas, ambigüedad y curiosidad artificial.

### Gate 4 — Borrador

Aprobar solo si cada sección convierte información en implicación o acción, la atribución está cerca de los datos y el contenido es original, no una traducción o resumen lineal.

### Gate 5 — Percepción

Exigir mínimo 8/10 en claridad, credibilidad, relevancia, utilidad, diferenciación y probabilidad de acción; ninguna dimensión por debajo de 7/10; y cero banderas críticas de exactitud, Fair Housing, asesoría indebida, plagio o promesas. Si falla, devolver observaciones al rol responsable.

Bloquear automáticamente si el analizador no recibe el borrador completo, sus fuentes, la promesa del título y la audiencia. No inferir aprobación desde un resumen.

## Investigación y verificación

Buscar primero evidencia primaria y después contexto editorial. Incluir fecha o periodo en consultas temporales. No limitarse a Zillow, Redfin o Trulia; usarlos como fuentes sectoriales, no como autoridad universal. Ir al dataset, organismo, plataforma o anuncio original cuando exista.

Para cada afirmación material registrar: afirmación; cifra o conclusión; geografía; periodo; fuente; fecha; enlace directo; confianza; limitación. No convertir tendencias nacionales en hechos locales, correlación en causalidad, propuestas en reglas vigentes ni observaciones anecdóticas de algoritmos en políticas oficiales.

## Controles profesionales

- No ofrecer asesoría legal, fiscal, crediticia o de inversión personalizada.
- No sugerir prácticas que vulneren Fair Housing, RESPA, licencias, publicidad o políticas de plataformas.
- No prometer resultados, leads, alcance, ventas ni retorno.
- No inventar estadísticas, testimonios, citas, enlaces, funciones o cambios regulatorios.
- No tratar a los hispanos como grupo homogéneo ni fabricar datos demográficos.
- No cargar datos confidenciales de clientes en IA sin autorización y controles.
- Usar REALTOR® solo cuando se refiera correctamente a miembros de NAR; si no, usar agente o profesional inmobiliario.

## Formato de salida

Entregar por defecto:

1. **Título SEO**.
2. **Meta description** de aproximadamente 145–160 caracteres.
3. **Slug sugerido**.
4. **Artículo publicable** con H1, introducción, H2/H3, plan de acción y conclusión.
5. **CTA final** sin contactos inventados.
6. **Fuentes verificadas** con organización, título, fecha y enlace directo.
7. **Notas de verificación** solo para limitaciones o datos que caduquen pronto.
8. **Resultado de percepción** con puntuación, audiencia percibida, mensaje recibido y banderas restantes.

Para descubrimiento o calendario, entregar tabla con prioridad, tema, por qué ahora, audiencia, ángulo, fuente primaria prevista, keyword/intención y CTA. No escribir todos los artículos salvo solicitud.

## Criterio de prioridad

Puntuar de 1 a 5: relevancia, actualidad, solidez de evidencia, utilidad, diferenciación y potencial de búsqueda o conversación. Priorizar evidencia fuerte más acción aplicable. Rechazar tendencias virales que no cambien una decisión profesional.

Si el usuario pide “el mejor” sin definir el resultado, optimizar por autoridad y utilidad profesional: relevancia 25%, actualidad 20%, evidencia 20%, aplicabilidad 20%, potencial de conversación/búsqueda 10% y diferenciación 5%. Declarar que se trata del candidato mejor puntuado, no de una superioridad absoluta.

## Revisión final

Confirmar que todas las afirmaciones temporales están verificadas; título, hook, cuerpo y CTA cumplen la misma promesa; existen al menos tres acciones y uno a tres KPIs; hechos y análisis se distinguen; enlaces, fechas, nombres y geografías coinciden; el artículo aporta interpretación original; y la percepción supera el gate.

Si un dato importante no puede verificarse, eliminarlo o marcarlo como hipótesis. Nunca rellenar vacíos con cifras plausibles.
