# Módulo de método

Aplicar únicamente dentro de los límites del controlador SKILL.md del owner.

# El Diario de AMI

Operar el podcast como un lote auditable e idempotente. No almacenar contraseñas, cookies ni claves en el skill, manifiestos o logs.

## Configuración fija

- Show: `El Diario de AMI: Acción Masiva al Éxito`
- Spotify: `https://open.spotify.com/show/44eP54c72vtJWibRBeXj57`
- Show ID obligatorio: `44eP54c72vtJWibRBeXj57`
- Identificación visual: seleccionar el show activo con carátula azul; nunca modificar la versión vieja
- Voice ID autorizado: `x1DOrfLtuvhgvW0jYdsS`
- Repositorio de producción: `mikopr32/Realtor-Codex-Skills`
- Secret de producción ya configurado: `ELEVENLABS_API_KEY` en GitHub Actions
- Publicación: lunes a viernes, 6:00 a. m., `America/New_York`
- Música: la misma canción oficial en todos los episodios
- Aprobación requerida: audio final del lote antes de cualquier carga o programación

## Flujo

1. Recibir el PDF/DOCX mensual y la fecha del primer episodio cuando no sea inequívoca.
2. Confirmar que existen `pdftotext`, `ffmpeg` y `ffprobe`. Crear un directorio de trabajo fuera del skill y ejecutar `scripts/extract_episodes.py`.
3. Revisar la separación, numeración, títulos y guiones. Corregir antes de gastar créditos.
4. Crear para cada episodio:
   - título natural, específico y con emojis relevantes;
   - descripción Spotify breve de 2–3 frases, con emojis, que anticipe el tema y beneficio sin spoilers ni revelar la `Tarea de hoy`;
   - copy de Instagram con hook, valor, CTA a escuchar y emojis;
   - carátula oficial del episodio o del show;
   - fecha/hora de publicación.
5. Guardar esos campos en los manifiestos con `scripts/episode_manifest.py`.
6. Usar primero el flujo seguro de GitHub Actions descrito en `references/github-audio-workflow.md`. El repositorio `mikopr32/Realtor-Codex-Skills` ya contiene el Repository Secret `ELEVENLABS_API_KEY`; no concluir que falta la clave solo porque no exista en el entorno local.
7. Ejecutar la generación mediante el workflow del repositorio. Si el workflow no existe o está incompleto, inspeccionarlo y prepararlo para usar `${{ secrets.ELEVENLABS_API_KEY }}` sin intentar leer ni revelar el valor. Ejecutar localmente `scripts/generate_voice.py` únicamente cuando la variable ya esté disponible de forma segura en ese entorno.
8. Ejecutar `scripts/mix_master_audio.py` y validar los resultados.
9. Ejecutar `scripts/validate_audio.py`. Corregir cualquier episodio fallido.
10. Presentar el lote final al usuario con títulos, fechas, audios, resúmenes y resultados de QA.
11. Esperar una aprobación explícita del audio final. No interpretar la aprobación del guion o del diseño del skill como aprobación de publicación.
12. Solo tras aprobación, leer `references/spotify-workflow.md`, usar `control-browser` y programar el mes completo en una sesión autenticada.
13. Revisar antes de programar: carátula, título, descripción, temporada, número, tipo, explicit/promotional y fecha/hora.
14. Verificar cada episodio en su página y en la lista de Spotify for Creators. Actualizar a `verified` únicamente cuando carátula, título, descripción, número y programación sean visibles y correctos. Nunca inventar URL, fecha o estado.

Estados permitidos:

`received → extracted → voice-generated → mixed → quality-approved → user-approved → scheduled → verified`

No saltar estados. En un reintento, inspeccionar el manifiesto y continuar desde el último artefacto válido; no duplicar episodios ya programados.

## Reglas editoriales

Leer `references/editorial-rules.md` antes de limpiar guiones o redactar metadatos. Conservar significado, citas y paréntesis hablados; retirar solo instrucciones de producción inequívocas.

## Audio

Leer `references/audio-specifications.md` antes de generar o mezclar.

- Usar de forma predeterminada `ELEVENLABS_API_KEY` mediante GitHub Actions en `mikopr32/Realtor-Codex-Skills`.
- No intentar leer el valor del secret: GitHub no lo expone. Confirmar su configuración por el nombre visible y comprobar su funcionamiento ejecutando el workflow.
- No volver a pedir al usuario que configure o comparta la clave mientras el secret exista. Pedir intervención solo si el repositorio no está accesible, el secret fue eliminado o el workflow falla específicamente por autenticación.
- Validar el archivo musical con `scripts/validate_music_asset.py`.
- Usar `assets/El_Diario_de_AMI.mp3` como pista oficial y comprobarla contra `assets/music-manifest.json`.
- Si falta o no coincide con su huella, detener la producción y pedir el original. No sustituirlo ni descargar música.
- Mantener la intro, ducking y outro definidos en la referencia.
- Procesar fallos por episodio y continuar el lote; registrar errores sin secretos.

## Spotify y acciones externas

La carga y programación son acciones externas con efecto real. Usar navegador únicamente cuando el usuario pida programar/publicar o apruebe inequívocamente el lote final. Permitir toma de control manual si aparece inicio de sesión o verificación. No aceptar credenciales por chat.

Programar todo el mes en una sola sesión cuando sea posible. Interpretar “6 a. m. ET” mediante `America/New_York`, respetando automáticamente EST/EDT.

La carátula y la descripción son campos obligatorios. Si Spotify no los muestra después de guardar, reabrir el episodio, corregirlos y volver a verificar sin alterar el audio ni la programación.

## Entrega del lote

Informar:

- episodios extraídos, producidos, aprobados, programados y fallidos;
- fecha/hora ET de cada episodio;
- resultado de QA;
- resumen Spotify y copy de Instagram;
- evidencia de programación obtenida de Spotify for Creators;
- confirmación visible de carátula, título, descripción, número y fecha/hora;
- incidencias y siguiente acción concreta.

No afirmar que un episodio está programado hasta verificarlo en la interfaz.

## Recursos

- `scripts/extract_episodes.py`: extraer y separar PDF, DOCX o TXT.
- `scripts/episode_manifest.py`: completar metadatos, fechas, estados y aprobación.
- `scripts/generate_voice.py`: generar voz segmentada con reintentos.
- `scripts/mix_master_audio.py`: mezclar canción, voz y master.
- `scripts/validate_audio.py`: validar audio y registrar QA.
- `scripts/validate_music_asset.py`: verificar que la pista oficial existe y es utilizable.
- `references/editorial-rules.md`: limpieza y copy.
- `references/audio-specifications.md`: parámetros de producción.
- `references/github-audio-workflow.md`: uso seguro del secret y generación mediante GitHub Actions.
- `references/spotify-workflow.md`: programación y verificación.
- `assets/El_Diario_de_AMI.mp3`: canción maestra oficial.
- `assets/music-manifest.json`: identidad esperada del activo musical.
