# Generación segura con GitHub Actions

## Configuración conocida

- Repositorio: `mikopr32/Realtor-Codex-Skills`
- Secret existente: `ELEVENLABS_API_KEY`
- Ubicación: Settings → Secrets and variables → Actions → Repository secrets
- Voice ID: `x1DOrfLtuvhgvW0jYdsS`

Tratar esta configuración como persistente. No pedir nuevamente la clave ni afirmar que falta porque el entorno local no contenga la variable.

## Procedimiento

1. Usar la integración de GitHub para inspeccionar los workflows y archivos de producción del repositorio.
2. Ejecutar una acción de solo lectura antes de cualquier futura automatización o ejecución dependiente de GitHub.
3. Localizar el workflow de generación de El Diario de AMI.
4. Confirmar que el workflow inyecta el secreto únicamente así:

   `ELEVENLABS_API_KEY: ${{ secrets.ELEVENLABS_API_KEY }}`

5. No imprimir variables de entorno, respuestas de autenticación, encabezados ni comandos con trazas que puedan exponer secretos.
6. Ejecutar el workflow con el manifiesto o lote aprobado y seguir su estado hasta completar.
7. Descargar y validar los artefactos de audio producidos antes de presentarlos al usuario.

## Si el workflow no existe

Preparar o corregir un workflow `workflow_dispatch` que:

- reciba una referencia segura al lote, no el contenido del secret;
- instale las dependencias necesarias;
- ejecute los scripts oficiales del skill;
- use el Repository Secret existente;
- publique audios, manifiestos y resultados de QA como artefactos;
- evite registrar secretos.

No pedir al usuario que vuelva a crear `ELEVENLABS_API_KEY`.

## Bloqueos válidos

Solicitar intervención únicamente cuando se haya comprobado uno de estos casos:

- no hay acceso al repositorio;
- el nombre `ELEVENLABS_API_KEY` ya no aparece entre los Repository Secrets;
- GitHub Actions está deshabilitado;
- el workflow devuelve un error explícito de autenticación o cuota;
- GitHub exige una aprobación manual que solo el usuario puede conceder.

Informar el error exacto y la única acción necesaria. No convertir la ausencia de una variable local en un bloqueo.
