#!/usr/bin/env python3
"""Compute separate reach, resonance, and recruitment-signal scores."""

from __future__ import annotations

import argparse
import csv
import math
import statistics
from collections import defaultdict
from pathlib import Path

NUMERIC = (
    "followers", "views", "likes", "comments", "shares", "saves", "age_days",
    "comments_sampled", "comment_quality", "recruitment_intent", "questions_count",
    "resource_requests", "community_questions", "reported_actions",
)
ENGAGEMENT = ("likes", "comments", "shares", "saves")


def number(value: object) -> float | None:
    if value is None or not str(value).strip():
        return None
    try:
        result = float(str(value))
    except ValueError:
        return None
    return result if math.isfinite(result) and result >= 0 else None


def ratio(a: float | None, b: float | None) -> float | None:
    return a / b if a is not None and b is not None and b > 0 else None


def weighted(parts: list[tuple[float | None, float]]) -> float | None:
    valid = [(value, weight) for value, weight in parts if value is not None]
    total_weight = sum(weight for _, weight in valid)
    if not total_weight:
        return None
    return round(sum(float(value) * weight for value, weight in valid) / total_weight, 2)


def relative_score(value: float | None, baseline: float | None) -> float | None:
    index = ratio(value, baseline)
    return round(min(index, 3) / 3 * 100, 2) if index is not None else None


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_csv", type=Path)
    parser.add_argument("output_csv", type=Path)
    args = parser.parse_args()

    with args.input_csv.open(newline="", encoding="utf-8-sig") as handle:
        rows = list(csv.DictReader(handle))
    if not rows:
        raise SystemExit("Input CSV has no rows")

    reach_groups: dict[tuple[str, str, str], list[float]] = defaultdict(list)
    resonance_groups: dict[tuple[str, str, str, str], list[float]] = defaultdict(list)

    for row in rows:
        for field in NUMERIC:
            row[field] = number(row.get(field))
        visible = [field for field in ENGAGEMENT if row[field] is not None]
        row["metric_signature"] = "+".join(visible) if visible else "none"
        row["engagement_total"] = sum(float(row[field]) for field in visible) if visible else None
        row["reach_metric"] = ratio(row["views"], row["followers"])
        if row["reach_metric"] is None:
            row["reach_metric"] = row["views"]
        row["resonance_metric"] = ratio(row["engagement_total"], row["views"])
        if row["resonance_metric"] is None:
            row["resonance_metric"] = ratio(row["engagement_total"], row["followers"])

        reach_key = (str(row.get("competitor", "")), str(row.get("platform", "")), str(row.get("format", "")))
        resonance_key = reach_key + (str(row["metric_signature"]),)
        if row["reach_metric"] is not None:
            reach_groups[reach_key].append(float(row["reach_metric"]))
        if row["resonance_metric"] is not None:
            resonance_groups[resonance_key].append(float(row["resonance_metric"]))

    reach_medians = {k: statistics.median(v) for k, v in reach_groups.items() if len(v) >= 5}
    resonance_medians = {k: statistics.median(v) for k, v in resonance_groups.items() if len(v) >= 5}

    for row in rows:
        reach_key = (str(row.get("competitor", "")), str(row.get("platform", "")), str(row.get("format", "")))
        resonance_key = reach_key + (str(row["metric_signature"]),)
        row["reach_score"] = relative_score(row["reach_metric"], reach_medians.get(reach_key))
        relative_resonance = relative_score(row["resonance_metric"], resonance_medians.get(resonance_key))
        quality_score = float(row["comment_quality"]) / 5 * 100 if row["comment_quality"] is not None else None
        row["resonance_score"] = weighted([(relative_resonance, 0.70), (quality_score, 0.30)])

        sampled = row["comments_sampled"]
        intent_score = float(row["recruitment_intent"]) / 5 * 100 if row["recruitment_intent"] is not None else None
        resource_rate = ratio(row["resource_requests"], sampled)
        community_rate = ratio(row["community_questions"], sampled)
        row["recruitment_signal_score"] = weighted([
            (intent_score, 0.50),
            (min(resource_rate * 500, 100) if resource_rate is not None else None, 0.25),
            (min(community_rate * 500, 100) if community_rate is not None else None, 0.25),
        ])

        score_count = sum(row[name] is not None for name in ("reach_score", "resonance_score", "recruitment_signal_score"))
        if sampled is not None and sampled < 5:
            row["confidence"] = "low"
        elif score_count == 3 and sampled is not None and sampled >= 10:
            row["confidence"] = "high"
        elif score_count >= 2:
            row["confidence"] = "medium"
        else:
            row["confidence"] = "low"

    fields = list(rows[0].keys())
    with args.output_csv.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
