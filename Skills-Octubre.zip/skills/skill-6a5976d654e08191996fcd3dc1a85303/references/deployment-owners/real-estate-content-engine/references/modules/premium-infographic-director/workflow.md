# Módulo de método

Aplicar únicamente dentro de los límites del controlador SKILL.md del owner.

# Premium Infographic Director

## Misión

Transformar información en una pieza visual premium, clara y publicable. Priorizar comprensión, exactitud, jerarquía y espacio en blanco sobre cantidad. Producir el arte final cuando el usuario pida crear o generar; no detenerse en un prompt salvo que solicite únicamente planificación o prompt.

## Enrutamiento obligatorio

1. Leer y aplicar `imagegen` antes de generar o editar imágenes rasterizadas.
2. Inspeccionar con `view_image` toda referencia local antes de editarla y todo archivo final compuesto antes de aprobarlo.
3. Usar composición determinista —SVG, HTML/CSS, presentación o documento— para texto, cifras, tablas, logos y alineación cuando la exactitud importe. Usar generación raster para la imagen central, ilustraciones, fondos o conceptos visuales.
4. Leer `Presentations`, `pdf` o `documents` cuando el usuario pida ese formato o sea el medio de composición elegido.
5. Guardar entregables reutilizables mediante `openai-library:library`, salvo imágenes devueltas directamente por la herramienta nativa de generación, que ya siguen su propio flujo de guardado.
6. Investigar solo cuando el usuario lo solicite, proporcione enlaces o el contenido dependa de hechos actuales, especializados o verificables. Mantener las fuentes fuera del arte si el diseño prohíbe pie de página.

## Seleccionar el modo

- **Producción — predeterminado:** usar cuando el usuario diga crear, diseñar, generar, hacer o corregir. Entregar la pieza final, no solo una descripción.
- **Blueprint:** usar cuando pida concepto, estructura, dirección, wireframe o prompt. Entregar especificación y prompt sin generar la pieza.
- **Auditoría:** usar cuando pida evaluar una infografía existente. Diagnosticar y priorizar correcciones; no reemplazarla salvo autorización.
- **Adaptación:** usar cuando exista una pieza maestra y se solicite otro formato. Reorganizar; no limitarse a recortar.

## Confirmar el formato

Si el usuario ya indicó formato, proporción o destino, usarlo sin volver a preguntar.

Si falta, detener la producción final y preguntar exactamente:

> ¿Deseas crear esta pieza como Flyer A4 o para Instagram/Facebook?

Ofrecer:

1. **Flyer A4:** 2480 × 3508 px, vertical.
2. **Instagram/Facebook:** 1080 × 1350 px, vertical 4:5.

Preferir opciones seleccionables cuando estén disponibles. No pedir otros datos salvo que sean realmente bloqueantes. Si falta información mejorable, declarar supuestos breves y avanzar.

## Intake mínimo

Extraer:

- Tema u objetivo.
- Contenido fuente o indicación de desarrollarlo.
- Formato.
- Audiencia y canal, si se conocen.
- Marca, paleta, logo o referencia visual, si existen.
- Texto, nombres, cifras y fechas que deban ser exactos.

Priorizar la marca aportada. Si no existe, elegir una paleta temática profesional de máximo tres colores principales y un acento.

## Flujo de trabajo

### 1. Normalizar y verificar

- Separar hechos, inferencias y decisiones creativas.
- Conservar literalmente nombres, cifras, precios, fechas, porcentajes y frases marcadas como exactas.
- No inventar datos ausentes. Investigar los hechos cambiantes o marcarlos como no verificados.
- Mantener un registro interno de afirmaciones y fuentes. Mostrar fuentes fuera de la imagen solo cuando se haya investigado.

### 2. Comprimir el contenido

Leer [content-compression.md](references/content-compression.md). Convertir la información en una tesis visual y de cuatro a siete unidades informativas. Eliminar repetición, prosa introductoria, conclusión, recomendaciones no solicitadas y detalles que no cambien la comprensión.

Si el contenido esencial no cabe con legibilidad, proponer una serie o un documento más largo; nunca reducir el texto hasta hacerlo ilegible.

### 3. Seleccionar el layout

Leer [layout-systems.md](references/layout-systems.md). Usar **imagen central + información alrededor** como patrón preferido para beneficios, características, curiosidades, anatomías y resúmenes simples. Permitir otro layout cuando la estructura semántica lo exija.

### 4. Definir la dirección visual

Establecer:

- Título principal arriba, salvo que un layout justifique otra jerarquía.
- Imagen o visual dominante con función explicativa, no decorativa.
- Tipografía con máximo dos familias y tres niveles principales.
- Íconos minimalistas y consistentes solo cuando aceleren comprensión.
- Área segura aproximada de 10%: calcular laterales sobre el ancho y bordes superior/inferior sobre la altura. Ningún texto, logo, ícono o dato crítico puede invadirla.
- Espacio en blanco intencional; no rellenar huecos por decoración.

Evitar exceso de cajas, sombras, degradados, íconos, colores y bloques. No incluir pie de página, resumen final, conclusión, bloque «idea clave», frase motivacional ni consejo extra salvo que el usuario lo aporte como contenido obligatorio o lo solicite explícitamente. No repetir la tesis al final.

### 5. Elegir la ruta de producción

**Ruta raster nativa:** usar cuando la pieza sea visual-first, tenga aproximadamente 35 palabras visibles o menos y la generación directa pueda conservarlas con fiabilidad. Incluir todo texto obligatorio de forma literal en el prompt y verificarlo después.

**Ruta híbrida — preferida para piezas profesionales:** generar la imagen central, fondo o ilustraciones sin texto; después componer títulos, cifras, íconos, logos y cuerpo de manera determinista. Usar siempre esta ruta cuando haya nombres, datos, múltiples bloques, branding estricto o riesgo reputacional por errores tipográficos.

No aceptar texto incorrecto generado dentro de una imagen. No usar un raster con errores como base final si reconstruir el texto de forma determinista resuelve el problema.

### 6. Construir el prompt de imagen

Usar la taxonomía y el esquema de `imagegen`. Especificar uso `infographic-diagram`, formato exacto, jerarquía, visual dominante, composición, paleta, texto literal, área segura, restricciones y elementos prohibidos. No sobrecargar el prompt con instrucciones duplicadas.

### 7. Validar y corregir

Leer [qa-rubric.md](references/qa-rubric.md). Ejecutar `python3 scripts/validate_infographic.py` sobre todo archivo final local, resolviendo la ruta desde el directorio del skill. Inspeccionar visualmente la pieza completa y, cuando sea necesario, a resolución original.

Comparar el texto visible contra el copy aprobado. Aplicar una corrección dirigida por iteración, preservando lo que ya funciona. Realizar hasta dos correcciones automáticas; si el defecto persiste, cambiar a ruta híbrida o informar el bloqueo con precisión.

## Contrato de salida

### Blueprint

Entregar:

1. Formato seleccionado.
2. Título principal.
3. Tesis y concepto visual.
4. Imagen o visual dominante sugerido.
5. Copy final por bloque.
6. Paleta con HEX y función.
7. Tipografía sugerida.
8. Distribución visual.
9. Prompt final listo para producción. Si corresponde la ruta híbrida, separar el prompt del activo visual —sin texto— de la especificación de composición determinista; no pedir a un generador raster que componga copy extenso.

### Producción

Entregar la infografía final. Añadir únicamente una nota breve con formato, ruta utilizada —raster o híbrida— y cualquier fuente externa empleada. No repetir todo el contenido en la respuesta.

### Auditoría

Entregar puntuación global, fallos observables, correcciones priorizadas por impacto y recomendación de reconstruir o editar.

## Métricas de éxito

- Promedio QA ≥ 9/10 y ninguna dimensión < 8/10.
- 100% de nombres, cifras, fechas y texto obligatorio correctos.
- 100% de archivos con dimensiones y orientación correctas.
- Cero elementos críticos fuera del área segura.
- Entre cuatro y siete unidades informativas, salvo excepción justificada.
- Comprensión de la idea principal en menos de diez segundos.
- Consistencia visual entre adaptaciones de formato.
- Máximo dos rondas de corrección antes de cambiar de ruta.

## Condiciones de falla

- Si el copy no cabe, reducir contenido o dividir la pieza; no sacrificar legibilidad.
- Si el texto raster falla, reconstruirlo determinísticamente.
- Si la fuente es contradictoria, detener las afirmaciones afectadas y pedir confirmación.
- Si una referencia de marca es insuficiente, conservar lo verificable y declarar el supuesto.
- Si el diseño luce genérico, revisar tesis, audiencia y visual dominante antes de añadir decoración.
- Si una adaptación pierde jerarquía, recomponer desde la cuadrícula del formato destino.
