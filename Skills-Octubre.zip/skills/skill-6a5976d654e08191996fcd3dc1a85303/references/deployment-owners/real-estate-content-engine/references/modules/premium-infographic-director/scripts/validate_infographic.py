#!/usr/bin/env python3
"""Validate basic technical properties of a final infographic image."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from PIL import Image


PRESETS = {
    "a4": (2480, 3508),
    "social-4x5": (1080, 1350),
}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("image", type=Path)
    parser.add_argument("--preset", choices=sorted(PRESETS))
    parser.add_argument("--expect-width", type=int)
    parser.add_argument("--expect-height", type=int)
    args = parser.parse_args()

    if not args.image.is_file():
        parser.error(f"image not found: {args.image}")

    with Image.open(args.image) as image:
        width, height = image.size
        mode = image.mode
        image_format = image.format

    expected = PRESETS.get(args.preset) if args.preset else None
    if args.expect_width or args.expect_height:
        if not (args.expect_width and args.expect_height):
            parser.error("use --expect-width and --expect-height together")
        expected = (args.expect_width, args.expect_height)

    problems: list[str] = []
    if expected and (width, height) != expected:
        problems.append(
            f"expected {expected[0]}x{expected[1]}, got {width}x{height}"
        )
    if width >= height:
        problems.append("expected a vertical image")
    if mode not in {"RGB", "RGBA"}:
        problems.append(f"unexpected color mode: {mode}")

    result = {
        "file": str(args.image),
        "format": image_format,
        "width": width,
        "height": height,
        "mode": mode,
        "expected": expected,
        "valid": not problems,
        "problems": problems,
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if not problems else 1


if __name__ == "__main__":
    sys.exit(main())
