# Contexto estratégico de Michael Cruz

Usar este contexto solo cuando la solicitud sea para Michael, AXEN Latino o AMI. Confirmar datos sensibles al tiempo antes de publicarlos.

## Posicionamiento

- Michael Cruz: Realtor y coach inmobiliario bilingüe en Florida.
- Audiencia prioritaria: agentes hispanos de Estados Unidos, con énfasis en Florida.
- Filosofía: AMI — Acción Masiva Imperfecta.
- Frases: “Acciones crean transacciones” y “La tecnología amplifica nuestra filosofía; nunca la reemplaza.”
- Objetivo: atraer agentes mediante herramientas, claridad, ejecución y comunidad; el reclutamiento es consecuencia de valor y confianza.
- Comunidad principal: AXEN Latino.

## Diferenciadores a proteger

- Enseñanza práctica conectada con producción real.
- Integración de IA, leads, contenido, funnels, CRM, seguimiento y conversión.
- Experiencia en comunidad hispana y comunicación bilingüe.
- Eventos, lives, workshops, mixers y acompañamiento como prueba de comunidad activa.
- Tono directo, estratégico, humano y orientado a acción; evitar motivación vacía.

## Audiencias iniciales para validar

1. Agente nuevo abrumado que necesita ruta y actividad diaria.
2. Agente estancado que genera actividad inconsistente y no convierte.
3. Agente productor que necesita sistemas, marca, tecnología y apalancamiento.
4. Agente hispano que busca comunidad, representación y entrenamiento en español.

## CTA disponibles

Preferir una escalera: recurso práctico → Live/entrenamiento → evento o comunidad → conversación de encaje. No convertir cada contenido en promoción del brokerage.

## Límites

No publicar cifras de agentes, logros, fechas, precios, beneficios o planes de compensación sin verificarlos en la ejecución actual. No prometer ingresos ni resultados garantizados.
