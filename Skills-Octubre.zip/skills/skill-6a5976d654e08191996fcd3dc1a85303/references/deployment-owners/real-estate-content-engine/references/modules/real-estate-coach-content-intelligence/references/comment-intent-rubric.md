# Rúbrica de comentarios e intención

## Muestreo

Leer hasta 20 comentarios relevantes por pieza prioritaria, o todos cuando haya menos. Excluir bots, spam, emojis aislados y comentarios del propio creador. Registrar `comments_sampled`.

## Calidad de conversación: 0–5

| Nivel | Evidencia dominante |
| ---: | --- |
| 0 | Sin comentarios útiles o solo spam/emojis |
| 1 | Aprobación superficial sin contexto |
| 2 | Identificación con el problema o experiencia breve |
| 3 | Preguntas específicas, objeciones o discusión sustantiva |
| 4 | Solicitud de explicación, plantilla, ejemplo o seguimiento |
| 5 | Conversación extensa, aplicación reportada o resultado concreto |

## Intención de reclutamiento/comunidad: 0–5

| Nivel | Evidencia dominante |
| ---: | --- |
| 0 | Ninguna señal |
| 1 | Curiosidad general por el creador |
| 2 | Pregunta por recurso, clase o contenido relacionado |
| 3 | Solicitud de DM, enlace, entrenamiento o evento |
| 4 | Pregunta por comunidad, mentoría, equipo, brokerage o acompañamiento |
| 5 | Intención explícita de conversar, aplicar, asistir o incorporarse |

## Contadores objetivos

Registrar, cuando sea posible:

- `questions_count`: preguntas específicas del tema;
- `resource_requests`: solicitudes de guía, plantilla, enlace o clase;
- `community_questions`: preguntas sobre comunidad, coaching, equipo o brokerage;
- `reported_actions`: personas que dicen haber aplicado la recomendación;
- `negative_substantive`: objeciones o críticas con contexto.

No asumir que un DM ocurrió porque el CTA lo solicitó. Puntuar evidencia visible. Si se muestrean menos de cinco comentarios, etiquetar la confianza como baja.
