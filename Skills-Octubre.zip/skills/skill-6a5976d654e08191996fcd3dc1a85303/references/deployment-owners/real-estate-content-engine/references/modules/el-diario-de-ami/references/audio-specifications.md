# Especificaciones de audio

## Fuente y voz

- Voice ID: `x1DOrfLtuvhgvW0jYdsS`
- Modelo predeterminado: `eleven_multilingual_v2`
- Formato de generación: MP3 44.1 kHz
- Dividir por límites de oración; nunca cortar una palabra.
- Reintentar errores transitorios con espera exponencial y respetar `Retry-After`.

## Mezcla oficial

- Intro: primeros 15 segundos de la canción al nivel original.
- Voz: comenzar en 00:15.
- Fondo durante voz: canción en loop con reducción de 35 dB.
- Outro: sección 00:38–00:53 de la canción al nivel original.
- Fade-out del outro: últimos 3 segundos.
- No recortar la narración ni superponer el outro con palabras habladas.

## Master

- Loudness integrado objetivo: -16 LUFS.
- True peak máximo: -1.5 dBTP.
- Rango de loudness objetivo: 11 LU.
- Salida: MP3 estéreo, 44.1 kHz, 192 kbps.

## QA obligatorio

- Archivo decodificable y duración mayor a 30 segundos.
- Narración presente, sin truncamiento aparente.
- Intro cercana a 15 segundos y outro cercano a 15 segundos.
- Sin clipping detectado; true peak dentro del objetivo.
- Diferencia de duración compatible con `voz + 30 segundos`.
- Escucha humana por muestreo del inicio, transición a voz, mitad y cierre. La validación automática no sustituye la aprobación del usuario.
