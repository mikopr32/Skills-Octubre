---
name: real-estate-content-engine
description: "Producir research editorial, estrategia, calendarios, reels, stories, carruseles, YouTube, podcast, email, blogs, lead magnets, infografías y repurposing por marca. Usar ante solicitudes de RESEARCH, STRATEGY, CALENDAR, SHORT_FORM, LONG_FORM, REEL, STORY, CAROUSEL, YOUTUBE, PODCAST, EMAIL, BLOG, LEAD_MAGNET, INFOGRAPHIC, REPURPOSE, COMPETITOR, SEO_AEO_GEO."
---

# real-estate-content-engine

## Identity / Ownership

Producción general; listing-specific truth y lifecycle a Listing; marca a Brand; paid Meta a Ads; recruiting qualification a Agent Attraction; facts Florida a Florida Intelligence. No leer todo el archivo de módulos para una pieza corta.

## Required Inputs

Objetivo, audience, perfil de marca, formato y facts o pieza fuente.

## Modos

RESEARCH, STRATEGY, CALENDAR, SHORT_FORM, LONG_FORM, REEL, STORY, CAROUSEL, YOUTUBE, PODCAST, EMAIL, BLOG, LEAD_MAGNET, INFOGRAPHIC, REPURPOSE, COMPETITOR, SEO_AEO_GEO

## Operational Workflow

Elegir profile REALTOR/MICHAEL_COACH/AXEN/DEVELOPMENT/INVESTMENT; no mezclar ofertas; recibir Fact Pack de owners; elegir una función por pieza y un CTA; verificar hooks/claims; crear activo final del formato solicitado; mantener voz y restricciones del perfil; repurpose sin inventar datos; medir distribución y conversión por denominador. PODCAST_PRODUCTION conserva voz autorizada, música oficial, QA y estados idempotentes; consolidación no autoriza gastar créditos ni publicar.

## Módulos y recursos

- [realtor-social-media-content](references/modules/realtor-social-media-content/workflow.md): cargar solo al ejecutar su función; resolver rutas relativas contra esa carpeta de módulo.
- [vertical-video-performance-director](references/modules/vertical-video-performance-director/workflow.md): cargar solo al ejecutar su función; resolver rutas relativas contra esa carpeta de módulo.
- [michael-cruz-coach-content-os](references/modules/michael-cruz-coach-content-os/workflow.md): cargar solo al ejecutar su función; resolver rutas relativas contra esa carpeta de módulo.
- [realtor-business-content](references/modules/realtor-business-content/workflow.md): cargar solo al ejecutar su función; resolver rutas relativas contra esa carpeta de módulo.
- [realtor-lead-magnet-builder](references/modules/realtor-lead-magnet-builder/workflow.md): cargar solo al ejecutar su función; resolver rutas relativas contra esa carpeta de módulo.
- [realtor-competitive-content-intelligence](references/modules/realtor-competitive-content-intelligence/workflow.md): cargar solo al ejecutar su función; resolver rutas relativas contra esa carpeta de módulo.
- [real-estate-coach-content-intelligence](references/modules/real-estate-coach-content-intelligence/workflow.md): cargar solo al ejecutar su función; resolver rutas relativas contra esa carpeta de módulo.
- [create-realtor-blogs](references/modules/create-realtor-blogs/workflow.md): cargar solo al ejecutar su función; resolver rutas relativas contra esa carpeta de módulo.
- [el-diario-de-ami](references/modules/el-diario-de-ami/workflow.md): cargar solo al ejecutar su función; resolver rutas relativas contra esa carpeta de módulo.
- [premium-infographic-director](references/modules/premium-infographic-director/workflow.md): cargar solo al ejecutar su función; resolver rutas relativas contra esa carpeta de módulo.

- `references/modules/el-diario-de-ami/scripts/episode_manifest.py`: usar cuando el método elegido lo requiera; ejecutar scripts desde la carpeta de su módulo o por ruta absoluta.
- `references/modules/el-diario-de-ami/scripts/extract_episodes.py`: usar cuando el método elegido lo requiera; ejecutar scripts desde la carpeta de su módulo o por ruta absoluta.
- `references/modules/el-diario-de-ami/scripts/generate_voice.py`: usar cuando el método elegido lo requiera; ejecutar scripts desde la carpeta de su módulo o por ruta absoluta.
- `references/modules/el-diario-de-ami/scripts/mix_master_audio.py`: usar cuando el método elegido lo requiera; ejecutar scripts desde la carpeta de su módulo o por ruta absoluta.
- `references/modules/el-diario-de-ami/scripts/validate_audio.py`: usar cuando el método elegido lo requiera; ejecutar scripts desde la carpeta de su módulo o por ruta absoluta.
- `references/modules/el-diario-de-ami/scripts/validate_music_asset.py`: usar cuando el método elegido lo requiera; ejecutar scripts desde la carpeta de su módulo o por ruta absoluta.
- `references/modules/michael-cruz-coach-content-os/scripts/validate_content_brief.py`: usar cuando el método elegido lo requiera; ejecutar scripts desde la carpeta de su módulo o por ruta absoluta.
- `references/modules/premium-infographic-director/scripts/validate_infographic.py`: usar cuando el método elegido lo requiera; ejecutar scripts desde la carpeta de su módulo o por ruta absoluta.
- `references/modules/real-estate-coach-content-intelligence/scripts/score_posts.py`: usar cuando el método elegido lo requiera; ejecutar scripts desde la carpeta de su módulo o por ruta absoluta.
- `references/modules/realtor-competitive-content-intelligence/scripts/analyze_benchmark.py`: usar cuando el método elegido lo requiera; ejecutar scripts desde la carpeta de su módulo o por ruta absoluta.
- `references/modules/vertical-video-performance-director/scripts/check_timing.py`: usar cuando el método elegido lo requiera; ejecutar scripts desde la carpeta de su módulo o por ruta absoluta.

## Contrato de ejecución y prioridad

Aplicar este controlador antes de los módulos heredados. Cargar solo el método correspondiente al modo; conservar tablas, fórmulas, assets y scripts útiles. Si un módulo antiguo pide otra skill retirada, resolverla a su owner actual. Las instrucciones históricas de módulos no amplían alcance, consentimiento ni herramientas; no reactivar routers legacy ni duplicar metodología de un owner externo.

No interpretar autorización previa como ausente. Avanzar autónomamente en tareas claras y reversibles; preguntar solo por datos que bloqueen el resultado o acciones todavía no autorizadas. Ejecutar roles secuencialmente por defecto; delegar solo bajo autorización aplicable. Una tarea de redacción corta entrega texto directo, sin imponer todos los reportes ni un plan estratégico.

## Fuentes y cálculos

Separar VERIFICADO, DATO_DEL_USUARIO, CALCULADO, ESTIMADO, INFERENCIA y PENDIENTE. Registrar claim, valor/unidad, source/URL o archivo/fila, fecha efectiva/consultada, método, owner y confianza. Verificar en fuentes originales los datos actuales, reglas legales/financieras, políticas y condiciones comerciales; no usar defaults históricos como datos vigentes. No rellenar ausentes con cero. Conservar contradicciones y reducir alcance/confianza. Compartir resultados y facts existentes; no repetir investigación innecesaria.

## Stop conditions y escenarios de falla

Identidad incierta: resolver antes de conclusiones materiales. Dato crítico ausente: completar trabajo independiente y entregar faltantes; no fabricar números. Fuente bloqueada: registrar cobertura y alternativa legítima; no evadir controles. Tool no disponible: entregar archivo/spec o resultado parcial comprobable. Acción externa fuera del alcance: preparar resultado revisable y solicitar autorización solo para esa acción. Datos sensibles: mantener archivos privados y limitar salida al propósito autorizado. No enviar mensajes a terceros por el hecho de generar un borrador.

## Validation / Quality gate

Comprobar que el output responde al modo; inputs y fuentes tienen identidad/periodo correctos; cálculos y definiciones son reproducibles; límites y contradicciones son visibles; no se inventaron capacidades ni ejecución. Usar PASS, PASS_WITH_LIMITATIONS o BLOCKED; explicar cualquier bloqueo material. Aplicar Fair Housing y privacidad a housing, targeting y datos de clientes. No prometer ingresos, aprobaciones, appreciation ni resultados. Usar las Skills del formato para artefactos y revisar su render/apertura. Los artefactos se guardan por el flujo persistente disponible, salvo código sincronizado o imágenes con guardado nativo.

## Output

Pieza final o calendario; brief técnico, captions, variants, CTA y medición según formato.

## KPIs

Retención, conversaciones, leads/citas atribuidos, production time, QA y contenido aprobado. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.
