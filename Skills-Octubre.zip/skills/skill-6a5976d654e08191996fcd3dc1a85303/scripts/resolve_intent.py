#!/usr/bin/env python3
"""Resolve an explicit normalized intent or a historical skill alias."""
import argparse,json,sys
from pathlib import Path
def resolve(intent,registry,aliases):
    exact=[r for r in registry['routes'] if r['intent']==intent]
    if len(exact)==1:return exact[0]
    if intent in aliases:
        owner=aliases[intent]
        return {'intent':intent,'primary':owner,'supports':[],'fit':'alias' if owner else 'archived','note':'Read owner to select mode; this is not natural-language classification.'}
    return {'intent':intent,'primary':None,'supports':[],'fit':'none','note':'Classify the user decision semantically; do not guess an absent skill.'}
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--intent',required=True);p.add_argument('--registry',required=True);p.add_argument('--aliases',required=True);a=p.parse_args();r=resolve(a.intent,json.loads(Path(a.registry).read_text()),json.loads(Path(a.aliases).read_text()));print(json.dumps(r,indent=2));sys.exit(0 if r['primary'] else 1)
