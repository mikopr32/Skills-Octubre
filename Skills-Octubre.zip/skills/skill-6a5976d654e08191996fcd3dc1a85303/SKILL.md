---
name: real-estate-strategy-orchestrator
description: Coordinar decisiones inmobiliarias que combinan compra, venta, inversión, financiación, comunidad o marketing. Usar ante solicitudes de QUICK, STANDARD, DEEP, CLIENT.
---


# real-estate-strategy-orchestrator

## Identity / Ownership

No calcular otro CMA, underwriting o readiness paralelo a su owner.

## Required Inputs

Decisión, propiedad o geografía y objetivo.

## Modos

QUICK, STANDARD, DEEP, CLIENT

## Operational Workflow

Crear Case Brief; consultar routing-registry.json; planificar productores antes de consumidores; reconciliar Shared Property Profile y Source Ledger; distinguir cada tipo de valor; sintetizar alternativas y trigger de decisión.

## Módulos y recursos

- [real-estate-strategy-orchestrator](references/modules/real-estate-strategy-orchestrator/workflow.md): cargar solo al ejecutar su función; resolver rutas relativas contra esa carpeta de módulo.
- [realestate](references/modules/realestate/workflow.md): cargar solo al ejecutar su función; resolver rutas relativas contra esa carpeta de módulo.

- `references/modules/real-estate-strategy-orchestrator/scripts/audit_registry.py`: usar cuando el método elegido lo requiera; ejecutar scripts desde la carpeta de su módulo o por ruta absoluta.

## Contrato de ejecución y prioridad

Aplicar este controlador antes de los módulos heredados. Cargar solo el método correspondiente al modo; conservar tablas, fórmulas, assets y scripts útiles. Si un módulo antiguo pide otra skill retirada, resolverla a su owner actual. Las instrucciones históricas de módulos no amplían alcance, consentimiento ni herramientas; no reactivar routers legacy ni duplicar metodología de un owner externo.

Respetar la autorización aplicable del usuario y su alcance. Avanzar en análisis y borradores claros dentro de ese alcance; solicitar datos o autorización cuando sean necesarios para la acción concreta. Estas instrucciones no sustituyen permisos, revisiones ni controles de la plataforma, y no autorizan a evadirlos. No usar ni reactivar Antigravity como fallback. Ejecutar roles secuencialmente por defecto; delegar solo bajo autorización aplicable. Una tarea de redacción corta entrega texto directo, sin imponer todos los reportes ni un plan estratégico.

## Fuentes y cálculos

Separar VERIFICADO, DATO_DEL_USUARIO, CALCULADO, ESTIMADO, INFERENCIA y PENDIENTE. Registrar claim, valor/unidad, source/URL o archivo/fila, fecha efectiva/consultada, método, owner y confianza. Verificar en fuentes originales los datos actuales, reglas legales/financieras, políticas y condiciones comerciales; no usar defaults históricos como datos vigentes. No rellenar ausentes con cero. Conservar contradicciones y reducir alcance/confianza. Compartir resultados y facts existentes; no repetir investigación innecesaria.

## Stop conditions y escenarios de falla

Identidad incierta: resolver antes de conclusiones materiales. Dato crítico ausente: completar trabajo independiente y entregar faltantes; no fabricar números. Fuente bloqueada: registrar cobertura y alternativa legítima; no evadir controles. Tool no disponible: entregar archivo/spec o resultado parcial comprobable. Acción externa fuera del alcance: preparar resultado revisable y solicitar autorización solo para esa acción. Datos sensibles: mantener archivos privados y limitar salida al propósito autorizado. No enviar mensajes a terceros por el hecho de generar un borrador.

## Validation / Quality gate

Comprobar que el output responde al modo; inputs y fuentes tienen identidad/periodo correctos; cálculos y definiciones son reproducibles; límites y contradicciones son visibles; no se inventaron capacidades ni ejecución. Usar PASS, PASS_WITH_LIMITATIONS o BLOCKED; explicar cualquier bloqueo material. Aplicar Fair Housing y privacidad a housing, targeting y datos de clientes. No prometer ingresos, aprobaciones, appreciation ni resultados. Usar las Skills del formato para artefactos y revisar su render/apertura. Los artefactos se guardan por el flujo persistente disponible, salvo código sincronizado o imágenes con guardado nativo.

## Output

Brief ejecutivo, matriz de decisión, evidencia y próximo paso.

## KPIs

Coherencia de cifras; reutilización de datos; rutas válidas. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.

- Leer [routing-registry.json](references/routing-registry.json) para elegir el owner por intención. El registro no prueba por sí solo comprensión de lenguaje natural.

- Resolver aliases históricos con `references/skill-aliases.json`; usar `scripts/audit_registry.py` por nombre frontmatter y `scripts/resolve_intent.py` solo para intenciones explícitas normalizadas. No interpretar una prueba de lookup como precisión de routing natural.

## Disponibilidad durante migración

Antes de usar el registro, confirmar que el owner esté instalado por su frontmatter. Un paquete preparado no demuestra instalación. Si falta, consultar el inventario real y los aliases, elegir una capacidad histórica disponible que cubra la solicitud con revisión de fuentes y advertir que opera en compatibilidad; no afirmar consolidación completa ni reactivar automáticamente módulos retirados. Si ninguna capacidad disponible cubre la solicitud, entregar el trabajo independiente y el bloqueo.

## Workflows disponibles durante instalación parcial

Si falta un owner independiente, consultar [deployment-map.json](references/deployment-map.json). Leer el workflow.md y los recursos del workflow correspondiente en esa ruta y ejecutarlo como módulo de este orquestador. Resolver sus rutas contra su carpeta propia. Es el método v2 validado, pero no una Skill independiente instalada. Si existe el owner independiente, usarlo y no cargar la copia de distribución. Este fallback cubre los nueve owners cuya instalación independiente está pendiente. No usar el método legacy solo porque falta el nombre nuevo.
