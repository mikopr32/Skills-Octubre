#!/usr/bin/env python3
"""Fixed-rate arithmetic. Inputs are scenarios, never underwriting approval."""
import argparse, json, math

def payment(principal, annual_rate, months):
    if not all(math.isfinite(v) for v in (principal,annual_rate,months)) or principal<0 or annual_rate<0 or months<=0 or int(months)!=months:
        raise ValueError('Require finite nonnegative principal/rate and positive integer months')
    if annual_rate==0: return principal/months
    rate=annual_rate/12
    return principal*rate/(-math.expm1(-months*math.log1p(rate)))

def balance(principal, annual_rate, months, paid_months):
    if paid_months<0 or paid_months>months or int(paid_months)!=paid_months:
        raise ValueError('Paid months must be an integer within term')
    pmt=payment(principal,annual_rate,months)
    if annual_rate==0: return max(0,principal-pmt*paid_months)
    rate=annual_rate/12
    # Remaining-payment present value avoids subtracting nearly equal terms.
    return pmt*(-math.expm1(-(months-paid_months)*math.log1p(rate)))/rate

def calculate(principal,annual_rate,months,monthly_costs=None):
    pi=payment(principal,annual_rate,months)
    costs=monthly_costs or {}
    if any(v is not None and (not math.isfinite(v) or v<0) for v in costs.values()):
        raise ValueError('Costs must be nonnegative finite numbers or null')
    required={'tax','insurance','hoa','cdd','mortgage_insurance','flood'}
    missing=sorted(k for k in required if costs.get(k) is None)
    total=None if missing else pi+sum(costs[k] for k in required)
    return {'principal_interest':round(pi,2),'monthly_total':None if total is None else round(total,2),'pending_costs':missing,'term_months':months,'rate_decimal':annual_rate,'approval':False}

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--principal',required=True,type=float);p.add_argument('--annual-rate-percent',required=True,type=float);p.add_argument('--months',required=True,type=int);p.add_argument('--monthly-costs-json')
    a=p.parse_args()
    print(json.dumps(calculate(a.principal,a.annual_rate_percent/100,a.months,json.loads(a.monthly_costs_json) if a.monthly_costs_json else None),indent=2))
