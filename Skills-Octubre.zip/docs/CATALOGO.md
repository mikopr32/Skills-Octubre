# Catálogo de Skills instaladas

Corte: 3 de octubre de 2026, hora de Nueva York. Inventario de Skills personales activas; excluye paquetes desinstalados, módulos internos como instalaciones independientes y Skills de sistema/plugins.

| Skill instalada | Para qué usarla | Guía |
|---|---|---|
| Antigravity Orchestrator v2 (2 copias) | Elegir una ruta especializada cuando la solicitud es ambigua o multidisciplinaria. | [Uso y resultados](skills/antigravity-orchestrator-v2.md) |
| Brand Architect | Definir posicionamiento, identidad visual o mejorar perfiles de marca. | [Uso y resultados](skills/brand-architect.md) |
| Buyer Strategy And Readiness | Preparar compradores y comparar pagos, capacidad y alternativas de financiación. | [Uso y resultados](skills/buyer-strategy-and-readiness.md) |
| Codex Capability Discovery | Comprobar capacidades instaladas antes de añadir otra Skill. | [Uso y resultados](skills/codex-capability-discovery.md) |
| Codex Prompt Architect | Convertir una instrucción ambigua en un prompt utilizable y evaluable. | [Uso y resultados](skills/codex-prompt-architect.md) |
| Codex Skill System Architect | Crear o reparar paquetes de Skills y delimitar responsabilidades. | [Uso y resultados](skills/codex-skill-system-architect.md) |
| Community Intelligence | Investigar costos, asociación, reglas y servicios de una comunidad. | [Uso y resultados](skills/community-intelligence.md) |
| Deep Cma Hybrid Valuation | Estimar valor de mercado y sustentar una estrategia de precio. | [Uso y resultados](skills/deep-cma-hybrid-valuation.md) |
| Dscr Loan Underwriter | Evaluar cobertura de deuda y límites condicionados de financiación DSCR. | [Uso y resultados](skills/dscr-loan-underwriter.md) |
| Florida Market Intelligence | Verificar noticias, proyectos de infraestructura y catalizadores de Florida. | [Uso y resultados](skills/florida-market-intelligence.md) |
| Florida Offer System | Auditar intake y preparar una oferta residencial de Florida para revisión del agente. | [Uso y resultados](skills/florida-offer-system.md) |
| Funnel Architect | Diseñar el recorrido de captación, calificación, seguimiento y cita. | [Uso y resultados](skills/funnel-architect.md) |
| Google Business Profile Intelligence | Auditar presencia local y rendimiento de Google Business Profile. | [Uso y resultados](skills/google-business-profile-intelligence.md) |
| International Investor Intelligence | Investigar demanda internacional y diseñar adquisición basada en evidencia. | [Uso y resultados](skills/international-investor-intelligence.md) |
| Landing Page Builder | Construir o reparar una página concreta de captación. | [Uso y resultados](skills/landing-page-builder.md) |
| Listing Intelligence Launch System | Gestionar un listing desde intake y lanzamiento hasta seguimiento y relanzamiento. | [Uso y resultados](skills/listing-intelligence-launch-system.md) |
| Manychat Automation Operator | Diseñar, revisar e implementar flows de ManyChat con integraciones verificables. | [Uso y resultados](skills/manychat-automation-operator.md) |
| Meta Housing Engine | Investigar anuncios y diseñar o auditar campañas pagadas de vivienda. | [Uso y resultados](skills/meta-housing-engine.md) |
| New Construction Intelligence | Investigar builders, comunidades, inventario e incentivos de obra nueva. | [Uso y resultados](skills/new-construction-intelligence.md) |
| Real Estate Content Engine | Producir contenido por marca y formato, reutilizando facts verificados. | [Uso y resultados](skills/real-estate-content-engine.md) |
| Real Estate Script Engine | Redactar conversaciones y seguimiento para compradores, vendedores e inversionistas. | [Uso y resultados](skills/real-estate-script-engine.md) |
| Real Estate Strategy Orchestrator | Coordinar una decisión inmobiliaria que requiere varias especialidades. | [Uso y resultados](skills/real-estate-strategy-orchestrator.md) |
| Realestate Analyze | Evaluar una propiedad rápidamente, en profundidad o frente a alternativas. | [Uso y resultados](skills/realestate-analyze.md) |
| Realestate Commercial | Analizar activos comerciales y multifamily de cinco o más unidades. | [Uso y resultados](skills/realestate-commercial.md) |
| Realestate Comps | Construir un conjunto de comparables antes de valorar una propiedad. | [Uso y resultados](skills/realestate-comps.md) |
| Realestate Invest | Modelar inversión residencial, renta, BRRRR, flip o terrenos. | [Uso y resultados](skills/realestate-invest.md) |
| Real Estate Listing Copy | Redactar descripción de una propiedad; versión anterior todavía instalada. | [Uso y resultados](skills/realestate-listing.md) |
| Realestate Market | Analizar oferta, demanda y cambios de un mercado delimitado. | [Uso y resultados](skills/realestate-market.md) |
| Neighborhood Analysis | Analizar entorno de una dirección; versión anterior todavía instalada. | [Uso y resultados](skills/realestate-neighborhood.md) |
| Realestate Report Pdf | Convertir un análisis ya auditado en un PDF para cliente o revisión técnica. | [Uso y resultados](skills/realestate-report-pdf.md) |
| Realestate Screen | Descubrir y filtrar candidatos conforme a un buy box. | [Uso y resultados](skills/realestate-screen.md) |
| Reddit Community Digest | Resumir publicaciones públicas de Reddit con ranking y periodo definidos. | [Uso y resultados](skills/reddit-community-digest.md) |
| Seller Opportunity Intelligence | Priorizar propietarios y oportunidades seller mediante evidencia patrimonial y señales de propiedad. | [Uso y resultados](skills/seller-opportunity-intelligence.md) |
