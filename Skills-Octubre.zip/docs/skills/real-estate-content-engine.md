# Real Estate Content Engine

**Nombre técnico:** `real-estate-content-engine`  
**Estado:** Instalada.

## Cuándo usarla

Producir contenido por marca y formato, reutilizando facts verificados.

## Qué darle

Objetivo, audience, perfil de marca, formato y facts o pieza fuente.

## Cómo usarla

Selecciona esta Skill con @ o invócala por nombre. Adjunta los archivos, concreta el objetivo y especifica el modo/formato. Una Skill no aporta acceso a cuentas ni herramientas por sí sola.

**Modos:** RESEARCH, STRATEGY, CALENDAR, SHORT_FORM, LONG_FORM, REEL, STORY, CAROUSEL, YOUTUBE, PODCAST, EMAIL, BLOG, LEAD_MAGNET, INFOGRAPHIC, REPURPOSE, COMPETITOR, SEO_AEO_GEO

### Ejemplo listo para adaptar

> @Real Estate Content Engine: Perfil DEVELOPMENT, modo REEL. Con los facts adjuntos, crea caption de máximo 90 palabras y guion de unos 30 segundos para [proyecto], CTA [acción]. Conserva proyecciones y pendientes; no mezcles coaching ni reclutamiento.

## Qué consigues

Pieza final o calendario; brief técnico, captions, variants, CTA y medición según formato.

## Cómo evaluar el resultado

Retención, conversaciones, leads/citas atribuidos, production time, QA y contenido aprobado. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.

## Límites prácticos

Los resultados dependen de la información y herramientas disponibles. Datos faltantes permanecen pendientes; una estimación o simulación no acredita verificación. Un borrador no acredita envío, implementación ni publicación. Autoriza expresamente acciones externas y gasto cuando correspondan.

## Paquetes respaldados

- [skill-6ac14d98a234819181cb5bc7cc674c3e](../../skills/skill-6ac14d98a234819181cb5bc7cc674c3e/SKILL.md) — SHA-256 `6871215e57d620f439f68525312059ff1d7e29b8e2873eb0323d1ae5dde30c4f`.
