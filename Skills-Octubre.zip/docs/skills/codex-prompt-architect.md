# Codex Prompt Architect

**Nombre técnico:** `codex-prompt-architect`  
**Estado:** Instalada.

## Cuándo usarla

Convertir una instrucción ambigua en un prompt utilizable y evaluable.

## Qué darle

Objetivo, prompt existente si hay y ejemplo de resultado.

## Cómo usarla

Selecciona esta Skill con @ o invócala por nombre. Adjunta los archivos, concreta el objetivo y especifica el modo/formato. Una Skill no aporta acceso a cuentas ni herramientas por sí sola.

**Modos:** CREATE, REPAIR, EVALUATE

### Ejemplo listo para adaptar

> @Codex Prompt Architect: Modo REPAIR. Mejora el prompt adjunto para [objetivo]. Define inputs, resultado, fuentes, límites y dos casos de evaluación. Devuelve el prompt completo.

## Qué consigues

Prompt listo para usar y criterios de evaluación.

## Cómo evaluar el resultado

Cumplimiento de instrucciones y correcciones por tarea. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.

## Límites prácticos

Los resultados dependen de la información y herramientas disponibles. Datos faltantes permanecen pendientes; una estimación o simulación no acredita verificación. Un borrador no acredita envío, implementación ni publicación. Autoriza expresamente acciones externas y gasto cuando correspondan.

## Paquetes respaldados

- [skill-6a5976084bc481918a5c3d224b2210e9](../../skills/skill-6a5976084bc481918a5c3d224b2210e9/SKILL.md) — SHA-256 `b81b71a480038bfe43dacc7b1cb1f58adbadb58b05014f057ed7edb701f6f18f`.
