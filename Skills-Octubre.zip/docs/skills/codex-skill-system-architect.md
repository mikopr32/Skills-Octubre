# Codex Skill System Architect

**Nombre técnico:** `codex-skill-system-architect`  
**Estado:** Instalada.

## Cuándo usarla

Crear o reparar paquetes de Skills y delimitar responsabilidades.

## Qué darle

Objetivo, inventario actual y casos representativos.

## Cómo usarla

Selecciona esta Skill con @ o invócala por nombre. Adjunta los archivos, concreta el objetivo y especifica el modo/formato. Una Skill no aporta acceso a cuentas ni herramientas por sí sola.

**Modos:** CREATE, CONSOLIDATE, REPAIR, EVAL

### Ejemplo listo para adaptar

> @Codex Skill System Architect: Modo REPAIR. Revisa la Skill adjunta y el fallo observado [descripción]. Comprueba si existe un owner adecuado, propone la corrección mínima y valida recursos y casos de uso.

## Qué consigues

Paquete validado; mapa de ownership; evidencia de pruebas.

## Cómo evaluar el resultado

Enlaces válidos; cobertura funcional; regresiones y routing. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.

## Límites prácticos

Los resultados dependen de la información y herramientas disponibles. Datos faltantes permanecen pendientes; una estimación o simulación no acredita verificación. Un borrador no acredita envío, implementación ni publicación. Autoriza expresamente acciones externas y gasto cuando correspondan.

## Paquetes respaldados

- [skill-6a59761261808191b057256994b950d9](../../skills/skill-6a59761261808191b057256994b950d9/SKILL.md) — SHA-256 `6baead8d621eec445b8037bd0652bdeee8ef19d46d9732f06e714bdae99dff6c`.
