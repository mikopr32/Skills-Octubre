# Google Business Profile Intelligence

**Nombre técnico:** `google-business-profile-intelligence`  
**Estado:** Instalada.

## Cuándo usarla

Auditar presencia local y rendimiento de Google Business Profile.

## Qué darle

Negocio y perfil identificado; acceso autorizado si se requiere escritura.

## Cómo usarla

Selecciona esta Skill con @ o invócala por nombre. Adjunta los archivos, concreta el objetivo y especifica el modo/formato. Una Skill no aporta acceso a cuentas ni herramientas por sí sola.

**Modos:** ELIGIBILITY, AUDIT, OPTIMIZE, REVIEWS, PERFORMANCE

### Ejemplo listo para adaptar

> @Google Business Profile Intelligence: Modo AUDIT. Revisa [negocio y URL del perfil] con los datos adjuntos. Verifica elegibilidad, nombre, dirección/teléfono, categorías y oportunidades; entrega prioridades y métricas. No cambies el perfil.

## Qué consigues

Audit, riesgos verificados, recomendaciones y plan medible.

## Cómo evaluar el resultado

Profile interactions, calls/appointments, NAP consistency y policy issues. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.

## Límites prácticos

Los resultados dependen de la información y herramientas disponibles. Datos faltantes permanecen pendientes; una estimación o simulación no acredita verificación. Un borrador no acredita envío, implementación ni publicación. Autoriza expresamente acciones externas y gasto cuando correspondan.

## Paquetes respaldados

- [skill-6a59764c6c4c8191ac1975600cd95b8e](../../skills/skill-6a59764c6c4c8191ac1975600cd95b8e/SKILL.md) — SHA-256 `523a210c6ee0bf5ad4d6083e64909d939e695e2df9f6f52bd5d7aa515cc9f310`.
