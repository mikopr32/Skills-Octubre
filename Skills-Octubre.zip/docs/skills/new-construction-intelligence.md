# New Construction Intelligence

**Nombre técnico:** `new-construction-intelligence`  
**Estado:** Instalada.

## Cuándo usarla

Investigar builders, comunidades, inventario e incentivos de obra nueva.

## Qué darle

Ciudad o builder/comunidad inequívocos.

## Cómo usarla

Selecciona esta Skill con @ o invócala por nombre. Adjunta los archivos, concreta el objetivo y especifica el modo/formato. Una Skill no aporta acceso a cuentas ni herramientas por sí sola.

**Modos:** BUILDER, COMMUNITY, CITY, INVENTORY, QUICK_MOVE_INS, INCENTIVES, COMPETITION, BUYER_STRATEGY, SALES_STRATEGY, UPDATE

### Ejemplo listo para adaptar

> @New Construction Intelligence: Modo CITY. Investiga nueva construcción en [ciudad], rango [precio] y entrega [plazo]. Separa modelos de inventario disponible y quick move-ins; registra incentivos con términos, fuentes oficiales y fecha de consulta.

## Qué consigues

Tablas de builders, modelos, QMI, incentivos, costos, fuentes y verification queue.

## Cómo evaluar el resultado

Cobertura oficial, vigencia de inventario y términos de incentivos. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.

## Límites prácticos

Los resultados dependen de la información y herramientas disponibles. Datos faltantes permanecen pendientes; una estimación o simulación no acredita verificación. Un borrador no acredita envío, implementación ni publicación. Autoriza expresamente acciones externas y gasto cuando correspondan.

## Paquetes respaldados

- [skill-6a5976a69a308191bac767a70af15b4c](../../skills/skill-6a5976a69a308191bac767a70af15b4c/SKILL.md) — SHA-256 `d531b4149fcdfbfd2f28730bba61c1523f1659a3877fc4151bda0c07f6c55114`.
