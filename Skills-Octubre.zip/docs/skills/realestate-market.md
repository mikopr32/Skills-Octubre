# Realestate Market

**Nombre técnico:** `realestate-market`  
**Estado:** Instalada.

## Cuándo usarla

Analizar oferta, demanda y cambios de un mercado delimitado.

## Qué darle

Geografía, segmento y periodo.

## Cómo usarla

Selecciona esta Skill con @ o invócala por nombre. Adjunta los archivos, concreta el objetivo y especifica el modo/formato. Una Skill no aporta acceso a cuentas ni herramientas por sí sola.

**Modos:** STATS, SUPPLY_DEMAND, BUYER_DEMAND, CHANGE

### Ejemplo listo para adaptar

> @Realestate Market: Modo SUPPLY_DEMAND. Analiza [geografía], segmento [tipo y precio] y periodo [fechas] con datos MLS adjuntos o fuentes disponibles. Entrega inventario, ventas, DOM y absorción con definiciones, muestra y fuentes.

## Qué consigues

Tabla de mercado, tendencias, metodología y fuentes.

## Cómo evaluar el resultado

Cobertura, actualidad, muestra y comparabilidad. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.

## Límites prácticos

Los resultados dependen de la información y herramientas disponibles. Datos faltantes permanecen pendientes; una estimación o simulación no acredita verificación. Un borrador no acredita envío, implementación ni publicación. Autoriza expresamente acciones externas y gasto cuando correspondan.

## Paquetes respaldados

- [skill-6a59775675b08191a434069db6716112](../../skills/skill-6a59775675b08191a434069db6716112/SKILL.md) — SHA-256 `581f2602cb3db0f0d37d68447c472996619f917ea04f0b31524fe72137136259`.
