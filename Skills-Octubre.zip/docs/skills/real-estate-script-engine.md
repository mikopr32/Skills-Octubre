# Real Estate Script Engine

**Nombre técnico:** `real-estate-script-engine`  
**Estado:** Instalada.

## Cuándo usarla

Redactar conversaciones y seguimiento para compradores, vendedores e inversionistas.

## Qué darle

Audience, stage, canal, objetivo; facts y preferencias de contacto disponibles.

## Cómo usarla

Selecciona esta Skill con @ o invócala por nombre. Adjunta los archivos, concreta el objetivo y especifica el modo/formato. Una Skill no aporta acceso a cuentas ni herramientas por sí sola.

**Modos:** CALL, VOICEMAIL, SMS, WHATSAPP, EMAIL, DM, VIDEO; FOLLOW_UP, OBJECTION, REACTIVATE, REFERRAL

### Ejemplo listo para adaptar

> @Real Estate Script Engine: Modo SMS y FOLLOW_UP. Redacta un mensaje para [tipo de lead, etapa y objetivo] con los facts adjuntos. Incluye CTA, variables y qué hacer ante opt-out. No inventes compradores ni envíes el mensaje.

## Qué consigues

Texto o secuencia con campos, ramas, CTA y stop rules.

## Cómo evaluar el resultado

Reply rate, qualified conversations, appointment/show, opt-outs y errores de personalización. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.

## Límites prácticos

Los resultados dependen de la información y herramientas disponibles. Datos faltantes permanecen pendientes; una estimación o simulación no acredita verificación. Un borrador no acredita envío, implementación ni publicación. Autoriza expresamente acciones externas y gasto cuando correspondan.

## Paquetes respaldados

- [skill-6ac149e141188191ac15ff029a8febe4](../../skills/skill-6ac149e141188191ac15ff029a8febe4/SKILL.md) — SHA-256 `4fe561bc6ac71e36dd50dea517634a9820d6f6dc0f66127058f43310544fee4d`.
