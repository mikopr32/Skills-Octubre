# Realestate Analyze

**Nombre técnico:** `realestate-analyze`  
**Estado:** Instalada.

## Cuándo usarla

Evaluar una propiedad rápidamente, en profundidad o frente a alternativas.

## Qué darle

Dirección inequívoca; dos o más para comparar; decisión del usuario.

## Cómo usarla

Selecciona esta Skill con @ o invócala por nombre. Adjunta los archivos, concreta el objetivo y especifica el modo/formato. Una Skill no aporta acceso a cuentas ni herramientas por sí sola.

**Modos:** QUICK, FULL, COMPARE, CLIENT

### Ejemplo listo para adaptar

> @Realestate Analyze: Modo COMPARE. Compara las propiedades A y B adjuntas con la misma rúbrica para [decisión]. Calcula solo con datos disponibles y conserva equity, gastos o cash flow pendientes cuando falten sus inputs.

## Qué consigues

Perfil, hallazgos, riesgos, comparación y recomendación condicionada.

## Cómo evaluar el resultado

Campos verificados, comparabilidad y limitaciones visibles. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.

## Límites prácticos

Los resultados dependen de la información y herramientas disponibles. Datos faltantes permanecen pendientes; una estimación o simulación no acredita verificación. Un borrador no acredita envío, implementación ni publicación. Autoriza expresamente acciones externas y gasto cuando correspondan.

## Paquetes respaldados

- [skill-6a5976f5cfd48191ae9a5bb6deebbcde](../../skills/skill-6a5976f5cfd48191ae9a5bb6deebbcde/SKILL.md) — SHA-256 `a0005403888943b1303d4cc038267a08e366f969917cb3c498399e70ee34682d`.
