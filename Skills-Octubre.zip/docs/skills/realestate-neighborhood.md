# Neighborhood Analysis

**Nombre técnico:** `realestate-neighborhood`  
**Estado:** Anterior aún instalada; preferir `community-intelligence`.

## Cuándo usarla

Analizar entorno de una dirección; versión anterior todavía instalada.

## Qué darle

Dirección exacta y preguntas concretas sobre el entorno.

## Cómo usarla

Selecciona esta Skill con @ o invócala por nombre. Adjunta los archivos, concreta el objetivo y especifica el modo/formato. Una Skill no aporta acceso a cuentas ni herramientas por sí sola.

**Modos:** Indicar la función y el formato en lenguaje natural.

### Ejemplo listo para adaptar

> @Neighborhood Analysis: Para nuevas tareas, utiliza Community Intelligence en NEIGHBORHOOD con [dirección]. Solicita servicios, conectividad, riesgos y fuentes; evita usar escuelas, crime o demografía para determinar valor o recomendar perfiles de compradores.

## Qué consigues

Informe descriptivo del entorno; preferir el controlador consolidado para tareas reales.

## Cómo evaluar el resultado

Cumplimiento del pedido, cobertura de fuentes y ausencia de datos inventados.

## Límites prácticos

Los resultados dependen de la información y herramientas disponibles. Datos faltantes permanecen pendientes; una estimación o simulación no acredita verificación. Un borrador no acredita envío, implementación ni publicación. Autoriza expresamente acciones externas y gasto cuando correspondan.

## Paquetes respaldados

- [skill-6a597771501c8191ad13f0b0cec1281c](../../skills/skill-6a597771501c8191ad13f0b0cec1281c/SKILL.md) — SHA-256 `3259c39907233054b814ac37bba9768cf1872b31b0b4720c7f394669dd609aec`.

El método histórico incluye scoring de escuelas, crime y demografía. La alternativa consolidada evita convertir esos datos en una conclusión sobre valor o idoneidad de compradores. Este respaldo conserva el original; no certifica su metodología.
