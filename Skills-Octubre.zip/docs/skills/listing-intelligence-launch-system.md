# Listing Intelligence Launch System

**Nombre técnico:** `listing-intelligence-launch-system`  
**Estado:** Instalada.

## Cuándo usarla

Gestionar un listing desde intake y lanzamiento hasta seguimiento y relanzamiento.

## Qué darle

Propiedad inequívoca y modo; facts suficientes para cada claim público.

## Cómo usarla

Selecciona esta Skill con @ o invócala por nombre. Adjunta los archivos, concreta el objetivo y especifica el modo/formato. Una Skill no aporta acceso a cuentas ni herramientas por sí sola.

**Modos:** INTAKE, CMA, LISTING_APPOINTMENT, PRE_MARKET, LAUNCH, PROPERTY_COPY, OPEN_HOUSE, MONITOR, OPTIMIZE, PRICE_ADJUSTMENT, STALE, RELAUNCH, SELLER_UPDATE, CONTENT_10X

### Ejemplo listo para adaptar

> @Listing Intelligence Launch System: Modo LAUNCH. Para [propiedad], usa la ficha verificada adjunta. Entrega estrategia, calendario de lanzamiento, copy, checklist y KPIs. Identifica claims pendientes y prepara materiales sin publicar.

## Qué consigues

Entregables del modo, seller strategy, launch calendar, KPI y claim ledger.

## Cómo evaluar el resultado

Showings, showing-to-offer, DOM, tracción por etapa, claims verificados y neto solo con datos. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.

## Límites prácticos

Los resultados dependen de la información y herramientas disponibles. Datos faltantes permanecen pendientes; una estimación o simulación no acredita verificación. Un borrador no acredita envío, implementación ni publicación. Autoriza expresamente acciones externas y gasto cuando correspondan.

## Paquetes respaldados

- [skill-6a5976604de08191a3c1e1ed74037dd1](../../skills/skill-6a5976604de08191a3c1e1ed74037dd1/SKILL.md) — SHA-256 `3d120a95b9ccb9185b04b46066b5653ff3b211f83b000e94f90f18a97d0f6586`.
