# Community Intelligence

**Nombre técnico:** `community-intelligence`  
**Estado:** Instalada.

## Cuándo usarla

Investigar costos, asociación, reglas y servicios de una comunidad.

## Qué darle

Identidad de comunidad y ubicación.

## Cómo usarla

Selecciona esta Skill con @ o invócala por nombre. Adjunta los archivos, concreta el objetivo y especifica el modo/formato. Una Skill no aporta acceso a cuentas ni herramientas por sí sola.

**Modos:** COMMUNITY, NEIGHBORHOOD, HOA_CDD, RENTAL_RULES, ONE_SHEET

### Ejemplo listo para adaptar

> @Community Intelligence: Modo HOA_CDD y RENTAL_RULES. Analiza [comunidad y dirección] con los documentos adjuntos. Confirma importe, frecuencia y vigencia de HOA, master/sub HOA, CDD y restricciones privadas y públicas de renta. Entrega fuentes, contradicciones y pendientes.

## Qué consigues

Dossier, costos con frecuencia, reglas, fuentes y pendientes.

## Cómo evaluar el resultado

Costos y restricciones verificados; contradicciones abiertas. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.

## Límites prácticos

Los resultados dependen de la información y herramientas disponibles. Datos faltantes permanecen pendientes; una estimación o simulación no acredita verificación. Un borrador no acredita envío, implementación ni publicación. Autoriza expresamente acciones externas y gasto cuando correspondan.

## Paquetes respaldados

- [skill-6a59789944a88191b98756960110450a](../../skills/skill-6a59789944a88191b98756960110450a/SKILL.md) — SHA-256 `55e727984613d041aa0243edbee11cfa1346fb29c5e9befe00b72cbfafe0cf58`.
