# Realestate Commercial

**Nombre técnico:** `realestate-commercial`  
**Estado:** Instalada.

## Cuándo usarla

Analizar activos comerciales y multifamily de cinco o más unidades.

## Qué darle

Activo, rent roll/operating statements cuando existan, estrategia y horizonte.

## Cómo usarla

Selecciona esta Skill con @ o invócala por nombre. Adjunta los archivos, concreta el objetivo y especifica el modo/formato. Una Skill no aporta acceso a cuentas ni herramientas por sí sola.

**Modos:** NOI, CAP, LEASE, VALUE_ADD, EXIT

### Ejemplo listo para adaptar

> @Realestate Commercial: Modo NOI y VALUE_ADD. Analiza [activo] usando rent roll, leases y operating statements adjuntos. Reconcila NOI, evalúa escenarios y sensibilidad, y entrega riesgos y checklist de due diligence.

## Qué consigues

Underwriting comercial, escenarios y checklist.

## Cómo evaluar el resultado

NOI conciliado, cobertura de leases y sensibilidad. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.

## Límites prácticos

Los resultados dependen de la información y herramientas disponibles. Datos faltantes permanecen pendientes; una estimación o simulación no acredita verificación. Un borrador no acredita envío, implementación ni publicación. Autoriza expresamente acciones externas y gasto cuando correspondan.

## Paquetes respaldados

- [skill-6a597700cb5c8191a9f29e343edc6488](../../skills/skill-6a597700cb5c8191a9f29e343edc6488/SKILL.md) — SHA-256 `0c79b4f80652e7b40518ec6e13e99e0750746dcfac7dda21540b5033b962ed15`.
