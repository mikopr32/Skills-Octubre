# Deep Cma Hybrid Valuation

**Nombre técnico:** `deep-cma-hybrid-valuation`  
**Estado:** Instalada.

## Cuándo usarla

Estimar valor de mercado y sustentar una estrategia de precio.

## Qué darle

Propiedad, specs y comps o acceso autorizado a fuentes; fecha de valoración.

## Cómo usarla

Selecciona esta Skill con @ o invócala por nombre. Adjunta los archivos, concreta el objetivo y especifica el modo/formato. Una Skill no aporta acceso a cuentas ni herramientas por sí sola.

**Modos:** CMA, HYBRID, PRICING, AUDIT

### Ejemplo listo para adaptar

> @Deep Cma Hybrid Valuation: Modo CMA. Valora [propiedad] a fecha [fecha] con características y comparables adjuntos. Explica selección, ajustes y reconciliación; entrega rango sustentado, confianza y faltantes.

## Qué consigues

Rango de valor, comps, ajustes, reconciliación, fuentes y pricing handoff.

## Cómo evaluar el resultado

Calidad de comps, trazabilidad de ajustes, cobertura y error observado posterior. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.

## Límites prácticos

Los resultados dependen de la información y herramientas disponibles. Datos faltantes permanecen pendientes; una estimación o simulación no acredita verificación. Un borrador no acredita envío, implementación ni publicación. Autoriza expresamente acciones externas y gasto cuando correspondan.

## Paquetes respaldados

- [skill-6a597622bba0819194ec2cc8c115ed18](../../skills/skill-6a597622bba0819194ec2cc8c115ed18/SKILL.md) — SHA-256 `79a152382f9799dc4f431afa25225acf8bcd17cc036a42e84e0c17cc6cbae1aa`.
