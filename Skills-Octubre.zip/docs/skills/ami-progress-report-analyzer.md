# AMI Progress Report Analyzer

**Nombre técnico:** `ami-progress-report-analyzer`  
**Estado:** Anterior aún instalada; preferir `ami-real-estate-coach`.

## Cuándo usarla

Analizar exportaciones del formulario AMI; versión anterior todavía instalada.

## Qué darle

XLSX/CSV del formulario AMI, periodo y metas.

## Cómo usarla

Selecciona esta Skill con @ o invócala por nombre. Adjunta los archivos, concreta el objetivo y especifica el modo/formato. Una Skill no aporta acceso a cuentas ni herramientas por sí sola.

**Modos:** Indicar la función y el formato en lenguaje natural.

### Ejemplo listo para adaptar

> @AMI Progress Report Analyzer: Analiza el XLSX adjunto de Evaluación de Progreso y Evolución para [periodo]. Reconcila filas y entrega reporte ejecutivo y reportes 1-1 privados, sin convertir blancos en cero. Para nuevas tareas, usa AMI Real Estate Coach.

## Qué consigues

Reporte ejecutivo privado y reportes 1-1 personalizados con plan de acción.

## Cómo evaluar el resultado

Cumplimiento del pedido, cobertura de fuentes y ausencia de datos inventados.

## Límites prácticos

Los resultados dependen de la información y herramientas disponibles. Datos faltantes permanecen pendientes; una estimación o simulación no acredita verificación. Un borrador no acredita envío, implementación ni publicación. Autoriza expresamente acciones externas y gasto cuando correspondan.

## Paquetes respaldados

- [skill-6a7905213a9481918d51c02785172669](../../skills/skill-6a7905213a9481918d51c02785172669/SKILL.md) — SHA-256 `fb65ce462f91b574ae8bca06ac7055cc7aa4e9e4b6d911ec05961705c16e334f`.
