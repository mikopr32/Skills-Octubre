# Florida Market Intelligence

**Nombre técnico:** `florida-market-intelligence`  
**Estado:** Instalada.

## Cuándo usarla

Verificar noticias, proyectos de infraestructura y catalizadores de Florida.

## Qué darle

Geografía y periodo o tema. Aceptar ejercicios ficticios identificados y respetar una instrucción de no consultar internet; los datos del ejercicio permanecen DATO_DEL_USUARIO.

## Cómo usarla

Selecciona esta Skill con @ o invócala por nombre. Adjunta los archivos, concreta el objetivo y especifica el modo/formato. Una Skill no aporta acceso a cuentas ni herramientas por sí sola.

**Modos:** GROWTH, INFRASTRUCTURE, DEVELOPMENTS, NEWS, REGULATION, MIGRATION, CONTENT_BRIEF

### Ejemplo listo para adaptar

> @Florida Market Intelligence: Modo INFRASTRUCTURE. Investiga [proyecto y localidad] para [periodo] en fuentes oficiales. Distingue propuesta, aprobación, fondos, permisos y ejecución; entrega Fact Pack y qué puede comunicarse sin prometer apreciación.

## Qué consigues

Registro de catalizadores, estado, fechas, fuentes y brief.

## Cómo evaluar el resultado

Proyectos verificados, fuentes primarias y datos vencidos. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.

## Límites prácticos

Los resultados dependen de la información y herramientas disponibles. Datos faltantes permanecen pendientes; una estimación o simulación no acredita verificación. Un borrador no acredita envío, implementación ni publicación. Autoriza expresamente acciones externas y gasto cuando correspondan.

## Paquetes respaldados

- [skill-6ac1439f81a48191a406d791ca543c8f](../../skills/skill-6ac1439f81a48191a406d791ca543c8f/SKILL.md) — SHA-256 `f5e9a2e4e76bab9e9312195e40575da3ee0b0c2d07f753e419870857916bb7da`.
