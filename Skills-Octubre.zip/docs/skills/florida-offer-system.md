# Florida Offer System

**Nombre técnico:** `florida-offer-system`  
**Estado:** Instalada.

## Cuándo usarla

Auditar intake y preparar una oferta residencial de Florida para revisión del agente.

## Qué darle

Agent Profile y términos confirmados de propiedad/partes/precio/financing/deposit/escrow/fechas/inspección/occupancy/expiration/riders.

## Cómo usarla

Selecciona esta Skill con @ o invócala por nombre. Adjunta los archivos, concreta el objetivo y especifica el modo/formato. Una Skill no aporta acceso a cuentas ni herramientas por sí sola.

**Modos:** AUDIT, PREPARE, SKYSLOPE, DOCUMENT_RULES, QA, READY_FOR_REVIEW

### Ejemplo listo para adaptar

> @Florida Offer System: Modo AUDIT. Revisa el intake y documentos adjuntos de [propiedad]. Identifica ambigüedades, términos críticos y formularios candidatos. No inventes fechas ni términos y no declares READY_FOR_AGENT_REVIEW hasta completar QA.

## Qué consigues

Offer object, document checklist, missing terms, field audit y READY_FOR_AGENT_REVIEW solo tras QA completo.

## Cómo evaluar el resultado

Critical fields matched, required documents present, mismatches abiertos y 0 envío/firma automatizados. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.

## Límites prácticos

Los resultados dependen de la información y herramientas disponibles. Datos faltantes permanecen pendientes; una estimación o simulación no acredita verificación. Un borrador no acredita envío, implementación ni publicación. Autoriza expresamente acciones externas y gasto cuando correspondan.

## Paquetes respaldados

- [skill-6ac14c004f608191962cd5aad42a3a72](../../skills/skill-6ac14c004f608191962cd5aad42a3a72/SKILL.md) — SHA-256 `25cb2c2d2c0c03defe6a075c3ed42e8b8043c127d3f74f4c47ad423e2c0629f7`.
