# Reddit Community Digest

**Nombre técnico:** `reddit-community-digest`  
**Estado:** Instalada.

## Cuándo usarla

Resumir publicaciones públicas de Reddit con ranking y periodo definidos.

## Qué darle

Subreddit público, ranking, periodo, número de posts y formato.

## Cómo usarla

Selecciona esta Skill con @ o invócala por nombre. Adjunta los archivos, concreta el objetivo y especifica el modo/formato. Una Skill no aporta acceso a cuentas ni herramientas por sí sola.

**Modos:** Indicar la función y el formato en lenguaje natural.

### Ejemplo listo para adaptar

> @Reddit Community Digest: Resume los cinco posts top de la semana de r/[comunidad]. Registra fuente, hora de consulta, score observado, comentarios, enlaces, temas y limitaciones. No perfiles autores ni reconstruyas contenido borrado.

## Qué consigues

Digest de posts con enlaces, métricas observadas, timestamp, temas y cobertura.

## Cómo evaluar el resultado

Cumplimiento del pedido, cobertura de fuentes y ausencia de datos inventados.

## Límites prácticos

Los resultados dependen de la información y herramientas disponibles. Datos faltantes permanecen pendientes; una estimación o simulación no acredita verificación. Un borrador no acredita envío, implementación ni publicación. Autoriza expresamente acciones externas y gasto cuando correspondan.

## Paquetes respaldados

- [skill-6a5979cac39881918744d18bf0f49ce0](../../skills/skill-6a5979cac39881918744d18bf0f49ce0/SKILL.md) — SHA-256 `8bc3ae72190e149ed174ce8e63450cb85ed072b800dcd8d0a7d01b8c908dccd9`.
