# Seller Opportunity Intelligence

**Nombre técnico:** `seller-opportunity-intelligence`  
**Estado:** Instalada.

## Cuándo usarla

Priorizar propietarios y oportunidades seller mediante evidencia patrimonial y señales de propiedad.

## Qué darle

EQUITY_FARMING: Fetch completo y sold MLS 12 meses de la misma subdivisión. FSBO: geografía. DISTRESS: condado inequívoco. Aceptar ejercicios ficticios y trabajar sin internet cuando se solicite; mantener sus datos como DATO_DEL_USUARIO.

## Cómo usarla

Selecciona esta Skill con @ o invócala por nombre. Adjunta los archivos, concreta el objetivo y especifica el modo/formato. Una Skill no aporta acceso a cuentas ni herramientas por sí sola.

**Modos:** EQUITY_FARMING, FSBO, EXPIRED, ABSENTEE, LONG_TERM_OWNER, DISTRESS, INVESTOR_OWNER, LEAD_LIST

### Ejemplo listo para adaptar

> @Seller Opportunity Intelligence: Modo EQUITY_FARMING. Analiza el Fetch completo y las ventas MLS de los últimos 12 meses de la misma subdivisión adjuntos. Prioriza propietarios, sustenta valor preliminar y separa diferencia frente a compra, equity y neto. No inventes balances ni descartes por falta de teléfono.

## Qué consigues

Lista priorizada privada, original rows reconciliation, valor preliminar, diferencia de compra, signals, score, confidence, exclusions y verificación pendiente.

## Cómo evaluar el resultado

Cobertura de propietarios, valor evaluable, datos verificados, falsos positivos, oportunidad-a-cita y costo por caso. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.

## Límites prácticos

Los resultados dependen de la información y herramientas disponibles. Datos faltantes permanecen pendientes; una estimación o simulación no acredita verificación. Un borrador no acredita envío, implementación ni publicación. Autoriza expresamente acciones externas y gasto cuando correspondan.

## Paquetes respaldados

- [skill-6ac147341764819184021e69ac85b6ad](../../skills/skill-6ac147341764819184021e69ac85b6ad/SKILL.md) — SHA-256 `cece55c9320ff29ca8e529b03266b8f9fe50fa72f60bf1219ff70bcb305c7321`.
