# Manychat Automation Operator

**Nombre técnico:** `manychat-automation-operator`  
**Estado:** Instalada.

## Cuándo usarla

Diseñar, revisar e implementar flows de ManyChat con integraciones verificables.

## Qué darle

Funnel handoff, trigger/canal, fields, CRM target y autorización.

## Cómo usarla

Selecciona esta Skill con @ o invócala por nombre. Adjunta los archivos, concreta el objetivo y especifica el modo/formato. Una Skill no aporta acceso a cuentas ni herramientas por sí sola.

**Modos:** BUILD, AUDIT, OPTIMIZE, QA

### Ejemplo listo para adaptar

> @Manychat Automation Operator: Modo BUILD. Diseña un flow para el trigger [palabra/canal], usando el handoff de funnel adjunto. Entrega ramas, fields, tags, opt-out, payload hacia [CRM] y pruebas. No declares integración realizada sin comprobarla.

## Qué consigues

Flow spec, field/tag map, integration payload y QA.

## Cómo evaluar el resultado

Trigger-to-lead, branch failures, opt-outs, payload success y conversiones. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.

## Límites prácticos

Los resultados dependen de la información y herramientas disponibles. Datos faltantes permanecen pendientes; una estimación o simulación no acredita verificación. Un borrador no acredita envío, implementación ni publicación. Autoriza expresamente acciones externas y gasto cuando correspondan.

## Paquetes respaldados

- [skill-6a66424a16c48191823307b6b91635c5](../../skills/skill-6a66424a16c48191823307b6b91635c5/SKILL.md) — SHA-256 `cd44ef252a148e200904a554e2ab9b299e35a6525245124bfe1f62966569bccd`.
