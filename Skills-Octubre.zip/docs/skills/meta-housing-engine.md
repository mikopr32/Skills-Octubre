# Meta Housing Engine

**Nombre técnico:** `meta-housing-engine`  
**Estado:** Instalada.

## Cuándo usarla

Investigar anuncios y diseñar o auditar campañas pagadas de vivienda.

## Qué darle

Mercado/offer y objetivo; budget y acceso si se solicita ejecución.

## Cómo usarla

Selecciona esta Skill con @ o invócala por nombre. Adjunta los archivos, concreta el objetivo y especifica el modo/formato. Una Skill no aporta acceso a cuentas ni herramientas por sí sola.

**Modos:** RESEARCH, COMPETITIVE, CAMPAIGN_BUILD, CREATIVE, INSTANT_FORM, CRM, TRACKING, OPTIMIZE, QA, GOOGLE_SEARCH_COMPAT

### Ejemplo listo para adaptar

> @Meta Housing Engine: Modo CAMPAIGN_BUILD. Prepara campaña para [oferta y mercado] con presupuesto autorizado [dato], baseline [dato] y facts adjuntos. Entrega copy, creative brief, formulario, tracking y QA de políticas. No publiques ni actives gasto.

## Qué consigues

Campaign kit, policy/claim ledger, form, creative brief, tracking y test plan.

## Cómo evaluar el resultado

CPL, qualified-lead cost, appointment/show, adquisición y política QA; métricas públicas no equivalen a ROI. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.

## Límites prácticos

Los resultados dependen de la información y herramientas disponibles. Datos faltantes permanecen pendientes; una estimación o simulación no acredita verificación. Un borrador no acredita envío, implementación ni publicación. Autoriza expresamente acciones externas y gasto cuando correspondan.

## Paquetes respaldados

- [skill-6ac14f8fe2e48191a1a870afd07e7130](../../skills/skill-6ac14f8fe2e48191a1a870afd07e7130/SKILL.md) — SHA-256 `bf08cbfe48be3a41be9b74fe56b3c761299985746669c38dc273a6478c970cbf`.
