# Real Estate Listing Copy

**Nombre técnico:** `realestate-listing`  
**Estado:** Anterior aún instalada; preferir `listing-intelligence-launch-system`.

## Cuándo usarla

Redactar descripción de una propiedad; versión anterior todavía instalada.

## Qué darle

Dirección, características verificadas, precio, formato y límite de caracteres.

## Cómo usarla

Selecciona esta Skill con @ o invócala por nombre. Adjunta los archivos, concreta el objetivo y especifica el modo/formato. Una Skill no aporta acceso a cuentas ni herramientas por sí sola.

**Modos:** Indicar la función y el formato en lenguaje natural.

### Ejemplo listo para adaptar

> @Real Estate Listing Copy: Con la ficha verificada adjunta, redacta la descripción MLS de [propiedad] dentro del límite [caracteres]. No añadas amenities o permisos desconocidos. Para nuevas tareas, usa Listing Intelligence Launch System en PROPERTY_COPY.

## Qué consigues

Descripción MLS, headlines, highlights y variantes de copy.

## Cómo evaluar el resultado

Cumplimiento del pedido, cobertura de fuentes y ausencia de datos inventados.

## Límites prácticos

Los resultados dependen de la información y herramientas disponibles. Datos faltantes permanecen pendientes; una estimación o simulación no acredita verificación. Un borrador no acredita envío, implementación ni publicación. Autoriza expresamente acciones externas y gasto cuando correspondan.

## Paquetes respaldados

- [skill-6a59774969348191872d62c6b104ea56](../../skills/skill-6a59774969348191872d62c6b104ea56/SKILL.md) — SHA-256 `b1f4979a82c224f16fad3d1f1d44fd4a92cea0216f0afcf222d0e20e6396ce3d`.
