# Dscr Loan Underwriter

**Nombre técnico:** `dscr-loan-underwriter`  
**Estado:** Instalada.

## Cuándo usarla

Evaluar cobertura de deuda y límites condicionados de financiación DSCR.

## Qué darle

Renta documentada, gastos y propuesta de financiación.

## Cómo usarla

Selecciona esta Skill con @ o invócala por nombre. Adjunta los archivos, concreta el objetivo y especifica el modo/formato. Una Skill no aporta acceso a cuentas ni herramientas por sí sola.

**Modos:** RESIDENTIAL_DSCR, NOI_DSCR, LOAN_LIMIT, SENSITIVITY

### Ejemplo listo para adaptar

> @Dscr Loan Underwriter: Modo RESIDENTIAL_DSCR. Usa renta, gastos y propuesta del lender adjuntos. Indica la definición de DSCR aplicada, calcula cobertura y sensibilidad a tasa y renta; no afirmes aprobación.

## Qué consigues

DSCR, fórmula, inputs, ceiling condicionado y pendientes del lender.

## Cómo evaluar el resultado

DSCR reproducible, coverage y sensibilidad a tasa/renta. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.

## Límites prácticos

Los resultados dependen de la información y herramientas disponibles. Datos faltantes permanecen pendientes; una estimación o simulación no acredita verificación. Un borrador no acredita envío, implementación ni publicación. Autoriza expresamente acciones externas y gasto cuando correspondan.

## Paquetes respaldados

- [skill-6a59762c51d08191ba252e72ed06f6a5](../../skills/skill-6a59762c51d08191ba252e72ed06f6a5/SKILL.md) — SHA-256 `c03eca39c3bea34bbf094ef72dd055bd1b944b088e0a720772c7ef7694013dc8`.
