# Brand Architect

**Nombre técnico:** `brand-architect`  
**Estado:** Instalada.

## Cuándo usarla

Definir posicionamiento, identidad visual o mejorar perfiles de marca.

## Qué darle

Marca, audience/oferta y activos autorizados disponibles.

## Cómo usarla

Selecciona esta Skill con @ o invócala por nombre. Adjunta los archivos, concreta el objetivo y especifica el modo/formato. Una Skill no aporta acceso a cuentas ni herramientas por sí sola.

**Modos:** CREATE, PERSONAL, BUSINESS, REBRAND, LUXURY, SOCIAL_AUDIT, CONSISTENCY, POSITIONING, VISUAL_SYSTEM, BRAND_BOARD

### Ejemplo listo para adaptar

> @Brand Architect: Modo SOCIAL_AUDIT. Audita la marca [nombre] con los perfiles y activos adjuntos. Entrega hallazgos, posicionamiento recomendado y acciones priorizadas. Separa Michael Cruz Homes, AMI y AXEN.

## Qué consigues

Posicionamiento, sistema visual, brand board/kit o auditoría con acciones.

## Cómo evaluar el resultado

Consistencia, diferenciación, legibilidad, profile-to-action y QA visual. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.

## Límites prácticos

Los resultados dependen de la información y herramientas disponibles. Datos faltantes permanecen pendientes; una estimación o simulación no acredita verificación. Un borrador no acredita envío, implementación ni publicación. Autoriza expresamente acciones externas y gasto cuando correspondan.

## Paquetes respaldados

- [skill-6ac11503208c81918a0604c23bf914fc](../../skills/skill-6ac11503208c81918a0604c23bf914fc/SKILL.md) — SHA-256 `06c8a9d836006bae03be1a0d8f2cb8738569e2e9a887cb4a22635ff6ae4d60a9`.
