# Antigravity Orchestrator v2

**Nombre técnico:** `antigravity-orchestrator-v2`  
**Estado:** Dos copias instaladas con el mismo nombre; no equivalen a dos capacidades distintas.

## Cuándo usarla

Elegir una ruta especializada cuando la solicitud es ambigua o multidisciplinaria.

## Qué darle

Objetivo, datos disponibles, restricciones y resultado deseado.

## Cómo usarla

Selecciona esta Skill con @ o invócala por nombre. Adjunta los archivos, concreta el objetivo y especifica el modo/formato. Una Skill no aporta acceso a cuentas ni herramientas por sí sola.

**Modos:** Indicar la función y el formato en lenguaje natural.

### Ejemplo listo para adaptar

> @Antigravity Orchestrator v2: Para [objetivo], identifica la Skill instalada más adecuada y ejecuta el flujo mínimo. Verifica que exista, evita investigar lo mismo dos veces y no uses subagentes salvo autorización explícita.

## Qué consigues

Selección de Skill, ejecución del método adecuado y síntesis con evidencia y límites.

## Cómo evaluar el resultado

Cumplimiento del pedido, cobertura de fuentes y ausencia de datos inventados.

## Límites prácticos

Los resultados dependen de la información y herramientas disponibles. Datos faltantes permanecen pendientes; una estimación o simulación no acredita verificación. Un borrador no acredita envío, implementación ni publicación. Autoriza expresamente acciones externas y gasto cuando correspondan.

## Paquetes respaldados

- [skill-6a5975ee4b8081919a4f1e6be00f4f7c](../../skills/skill-6a5975ee4b8081919a4f1e6be00f4f7c/SKILL.md) — SHA-256 `2f216faf007602b7bb8f7a46b48d25d0a6d083af8fba9d1f4413d76de1521465`.
- [skill-6a5977e27ffc8191b4536877edfffae4](../../skills/skill-6a5977e27ffc8191b4536877edfffae4/SKILL.md) — SHA-256 `2f216faf007602b7bb8f7a46b48d25d0a6d083af8fba9d1f4413d76de1521465`.

Estas copias conservan rutas históricas que pueden citar Skills retiradas. No se recomienda añadir este router a una tarea clara de una sola Skill. No se ha modificado ni desinstalado durante este inventario.
