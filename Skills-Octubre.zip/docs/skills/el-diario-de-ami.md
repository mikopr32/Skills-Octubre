# El Diario de AMI

**Nombre técnico:** `el-diario-de-ami`  
**Estado:** Instalada.

## Cuándo usarla

Producir el podcast específico El Diario de AMI conservando voz, música y calendario.

## Qué darle

PDF/DOCX mensual, episodios y calendario; voz y música autorizadas, credenciales/accesos y aprobación para producción o publicación.

## Cómo usarla

Selecciona esta Skill con @ o invócala por nombre. Adjunta los archivos, concreta el objetivo y especifica el modo/formato. Una Skill no aporta acceso a cuentas ni herramientas por sí sola.

**Modos:** Indicar la función y el formato en lenguaje natural.

### Ejemplo listo para adaptar

> @El Diario de AMI: Con el DOCX mensual adjunto, separa los episodios de El Diario de AMI, normaliza guiones y prepara títulos, resúmenes y manifest. En esta fase no generes voz, gastes créditos ni publiques; lista requisitos para la producción de audio.

## Qué consigues

Guiones normalizados, manifest, audio cuando herramientas y autorización permiten, metadatos y calendario revisable. Publicación solo con acceso y aprobación.

## Cómo evaluar el resultado

Cumplimiento del pedido, cobertura de fuentes y ausencia de datos inventados.

## Límites prácticos

Los resultados dependen de la información y herramientas disponibles. Datos faltantes permanecen pendientes; una estimación o simulación no acredita verificación. Un borrador no acredita envío, implementación ni publicación. Autoriza expresamente acciones externas y gasto cuando correspondan.

## Paquetes respaldados

- [skill-6a6a3f705a5881919c975b3cb3df0790](../../skills/skill-6a6a3f705a5881919c975b3cb3df0790/SKILL.md) — SHA-256 `eba402edf73c916b5c56a5e08fbccf7688b59a8b1e9e8cd8e141ab2a90e07d8e`.
