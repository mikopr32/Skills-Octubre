# Meeting Notes And Actions

**Nombre técnico:** `meeting-notes-and-actions`  
**Estado:** Instalada.

## Cuándo usarla

Transformar notas de reuniones en acuerdos y ejecución trazable.

## Qué darle

Notas o transcripción fuente.

## Cómo usarla

Selecciona esta Skill con @ o invócala por nombre. Adjunta los archivos, concreta el objetivo y especifica el modo/formato. Una Skill no aporta acceso a cuentas ni herramientas por sí sola.

**Modos:** NOTES, ACTIONS, FOLLOW_UP

### Ejemplo listo para adaptar

> @Meeting Notes And Actions: Modo ACTIONS. Convierte la transcripción adjunta en minuta y tabla de acuerdos, responsables, fechas y pendientes. No inventes responsables ni envíes seguimiento.

## Qué consigues

Minuta y tabla de acciones.

## Cómo evaluar el resultado

Acciones con responsable y fecha; pendientes resueltos. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.

## Límites prácticos

Los resultados dependen de la información y herramientas disponibles. Datos faltantes permanecen pendientes; una estimación o simulación no acredita verificación. Un borrador no acredita envío, implementación ni publicación. Autoriza expresamente acciones externas y gasto cuando correspondan.

## Paquetes respaldados

- [skill-6a59767b102081919bb00b234c393497](../../skills/skill-6a59767b102081919bb00b234c393497/SKILL.md) — SHA-256 `d1601cbc0039c7cbc24850d46d05131810430e0ef453372f481d90c95a19c117`.
