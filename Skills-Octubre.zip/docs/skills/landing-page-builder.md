# Landing Page Builder

**Nombre técnico:** `landing-page-builder`  
**Estado:** Instalada.

## Cuándo usarla

Construir o reparar una página concreta de captación.

## Qué darle

Brief de funnel/oferta, facts, CTA y plataforma.

## Cómo usarla

Selecciona esta Skill con @ o invócala por nombre. Adjunta los archivos, concreta el objetivo y especifica el modo/formato. Una Skill no aporta acceso a cuentas ni herramientas por sí sola.

**Modos:** BUILD, AUDIT, REPAIR

### Ejemplo listo para adaptar

> @Landing Page Builder: Modo BUILD. Usa el brief de funnel, facts y marca adjuntos para una landing en [plataforma]. Define copy, CTA, formulario, consentimiento, tracking y QA móvil. Indica qué implementación es posible con el acceso disponible.

## Qué consigues

Página verificable, form contract y resultado de QA.

## Cómo evaluar el resultado

Form completion, CTA clicks, capture success y mobile QA. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.

## Límites prácticos

Los resultados dependen de la información y herramientas disponibles. Datos faltantes permanecen pendientes; una estimación o simulación no acredita verificación. Un borrador no acredita envío, implementación ni publicación. Autoriza expresamente acciones externas y gasto cuando correspondan.

## Paquetes respaldados

- [skill-6a6680d26b148191b672b27d219fdb67](../../skills/skill-6a6680d26b148191b672b27d219fdb67/SKILL.md) — SHA-256 `8dddb01ab025c04a10183111f2e0c4e6fd8ee462eac04ea4aba8b56e3927b618`.
