# Realestate Screen

**Nombre técnico:** `realestate-screen`  
**Estado:** Instalada.

## Cuándo usarla

Descubrir y filtrar candidatos conforme a un buy box.

## Qué darle

Ubicación y criterios; criterios ausentes como hipótesis explícitas.

## Cómo usarla

Selecciona esta Skill con @ o invócala por nombre. Adjunta los archivos, concreta el objetivo y especifica el modo/formato. Una Skill no aporta acceso a cuentas ni herramientas por sí sola.

**Modos:** CASH_FLOW, APPRECIATION, BRRRR, FIRST_BUYER, STR, CUSTOM

### Ejemplo listo para adaptar

> @Realestate Screen: Modo CUSTOM. Busca candidatos en [ubicación] con precio [rango], tipo [tipo], estrategia [objetivo] y criterios adjuntos. Entrega shortlist, fuentes, fit, descartes, duplicados y cobertura; no inventes propiedades.

## Qué consigues

Candidatos, criterios, fuentes, descartes y cobertura.

## Cómo evaluar el resultado

Fit verificable, duplicados, cobertura y falsos positivos. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.

## Límites prácticos

Los resultados dependen de la información y herramientas disponibles. Datos faltantes permanecen pendientes; una estimación o simulación no acredita verificación. Un borrador no acredita envío, implementación ni publicación. Autoriza expresamente acciones externas y gasto cuando correspondan.

## Paquetes respaldados

- [skill-6a5978ededb88191a68feb4b3ebf6a46](../../skills/skill-6a5978ededb88191a68feb4b3ebf6a46/SKILL.md) — SHA-256 `1c498f3142eb608bbe31372fadabaf6bd3ec41812d52abe14082691486781379`.
