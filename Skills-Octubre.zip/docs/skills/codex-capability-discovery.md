# Codex Capability Discovery

**Nombre técnico:** `codex-capability-discovery`  
**Estado:** Instalada.

## Cuándo usarla

Comprobar capacidades instaladas antes de añadir otra Skill.

## Qué darle

Solicitud o raíz de Skills accesible.

## Cómo usarla

Selecciona esta Skill con @ o invócala por nombre. Adjunta los archivos, concreta el objetivo y especifica el modo/formato. Una Skill no aporta acceso a cuentas ni herramientas por sí sola.

**Modos:** INVENTORY, GAP, OVERLAP

### Ejemplo listo para adaptar

> @Codex Capability Discovery: Modo INVENTORY. Revisa las Skills personales instaladas. Excluye uninstalled y módulos internos; muestra duplicados, solapamientos y capacidades que faltan para [objetivo].

## Qué consigues

Inventario verificable; capacidades faltantes y owner sugerido.

## Cómo evaluar el resultado

Cobertura de inventario, duplicados por nombre y falsas brechas. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.

## Límites prácticos

Los resultados dependen de la información y herramientas disponibles. Datos faltantes permanecen pendientes; una estimación o simulación no acredita verificación. Un borrador no acredita envío, implementación ni publicación. Autoriza expresamente acciones externas y gasto cuando correspondan.

## Paquetes respaldados

- [skill-6a5975ffd76881919bdb04f58a3220a5](../../skills/skill-6a5975ffd76881919bdb04f58a3220a5/SKILL.md) — SHA-256 `14e0e9875d0d3221ac3b90c0297ea2e72bef3abe0c35771a027e7f2135e2364e`.
