# International Investor Intelligence

**Nombre técnico:** `international-investor-intelligence`  
**Estado:** Instalada.

## Cuándo usarla

Investigar demanda internacional y diseñar adquisición basada en evidencia.

## Qué darle

Geografía de destino y objetivo; asset class/ticket si están definidos. Aceptar simulaciones identificadas y respetar una instrucción de no consultar internet: los datos aportados siguen DATO_DEL_USUARIO.

## Cómo usarla

Selecciona esta Skill con @ o invócala por nombre. Adjunta los archivos, concreta el objetivo y especifica el modo/formato. Una Skill no aporta acceso a cuentas ni herramientas por sí sola.

**Modos:** MARKET_MAP, INVESTOR_PROFILE, PSYCHOLOGY, CHANNELS, PARTNERS, ACQUISITION_SYSTEM

### Ejemplo listo para adaptar

> @International Investor Intelligence: Modo MARKET_MAP y CHANNELS. Investiga inversionistas internacionales hacia [geografía], para [tipos de activos y ticket]. Distingue datos estatales y locales, fuente y periodo; propone canales y piloto sin atribuir rasgos por nacionalidad.

## Qué consigues

Mapa de evidencia, perfiles hipotéticos, canales verificables, propuesta y piloto 30/60/90 cuando se pide sistema.

## Cómo evaluar el resultado

Conversaciones calificadas, proof coverage, appointments, inversión/horas por cliente y conversión por cohorte. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.

## Límites prácticos

Los resultados dependen de la información y herramientas disponibles. Datos faltantes permanecen pendientes; una estimación o simulación no acredita verificación. Un borrador no acredita envío, implementación ni publicación. Autoriza expresamente acciones externas y gasto cuando correspondan.

## Paquetes respaldados

- [skill-6ac1452e0cb48191ab52a461dbdd5d8f](../../skills/skill-6ac1452e0cb48191ab52a461dbdd5d8f/SKILL.md) — SHA-256 `b9b7a9a35435c53cf8cc939d5a80a934d9bdaf8eb0f2b498acc665abc89a5843`.
