# Funnel Architect

**Nombre técnico:** `funnel-architect`  
**Estado:** Instalada.

## Cuándo usarla

Diseñar el recorrido de captación, calificación, seguimiento y cita.

## Qué darle

Audiencia, oferta y resultado; capacidad y baseline cuando existan.

## Cómo usarla

Selecciona esta Skill con @ o invócala por nombre. Adjunta los archivos, concreta el objetivo y especifica el modo/formato. Una Skill no aporta acceso a cuentas ni herramientas por sí sola.

**Modos:** CREATE, AUDIT, OPTIMIZE

### Ejemplo listo para adaptar

> @Funnel Architect: Modo CREATE. Diseña el funnel para [audiencia] y [oferta], con capacidad [dato] y baseline adjunto. Define etapas, handoffs, responsables, campos, KPIs y experimento inicial; no configures herramientas ni actives gasto.

## Qué consigues

Funnel map, input/output contracts, responsables, KPI y experiments.

## Cómo evaluar el resultado

Conversiones por etapa, tiempo de respuesta, show y costo por resultado. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.

## Límites prácticos

Los resultados dependen de la información y herramientas disponibles. Datos faltantes permanecen pendientes; una estimación o simulación no acredita verificación. Un borrador no acredita envío, implementación ni publicación. Autoriza expresamente acciones externas y gasto cuando correspondan.

## Paquetes respaldados

- [skill-6a668082da0c81919bfe40034185e601](../../skills/skill-6a668082da0c81919bfe40034185e601/SKILL.md) — SHA-256 `a82f571c66072b17649f46fdcd126f606a235c19c70dd842aeeb737b3d71317f`.
