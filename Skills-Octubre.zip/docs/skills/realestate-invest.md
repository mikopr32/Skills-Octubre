# Realestate Invest

**Nombre técnico:** `realestate-invest`  
**Estado:** Instalada.

## Cuándo usarla

Modelar inversión residencial, renta, BRRRR, flip o terrenos.

## Qué darle

Propiedad o shortlist, estrategia y datos financieros disponibles.

## Cómo usarla

Selecciona esta Skill con @ o invócala por nombre. Adjunta los archivos, concreta el objetivo y especifica el modo/formato. Una Skill no aporta acceso a cuentas ni herramientas por sí sola.

**Modos:** BUY_HOLD, RENTAL, BRRRR, FIX_FLIP, OPPORTUNITY, LAND, EXIT, SCENARIOS

### Ejemplo listo para adaptar

> @Realestate Invest: Modo RENTAL. Evalúa [propiedad] con renta, gastos, reservas y financiación adjuntos. Calcula cash flow, NOI, cap rate y cash-on-cash solo si existen sus inputs; entrega escenario base y downside con supuestos visibles.

## Qué consigues

Underwriting, cash flow, retornos, MAO condicionado, riesgos y salida.

## Cómo evaluar el resultado

Break-even, CoC, cap/NOI, ROI/MAO, downside y confianza. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.

## Límites prácticos

Los resultados dependen de la información y herramientas disponibles. Datos faltantes permanecen pendientes; una estimación o simulación no acredita verificación. Un borrador no acredita envío, implementación ni publicación. Autoriza expresamente acciones externas y gasto cuando correspondan.

## Paquetes respaldados

- [skill-6a59773b14cc81919da60721ea231153](../../skills/skill-6a59773b14cc81919da60721ea231153/SKILL.md) — SHA-256 `2bf55b0b6c64a9e6652c9398fabcaf988bc5c9373272e1ac0886bb76fd4e6942`.
