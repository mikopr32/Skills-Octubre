# Ami Real Estate Coach

**Nombre técnico:** `ami-real-estate-coach`  
**Estado:** Instalada.

## Cuándo usarla

Diagnosticar ejecución comercial y preparar coaching individual o de equipo.

## Qué darle

Objetivo, periodo, baseline y actividad disponible; aceptar formulario AMI XLSX/CSV.

## Cómo usarla

Selecciona esta Skill con @ o invócala por nombre. Adjunta los archivos, concreta el objetivo y especifica el modo/formato. Una Skill no aporta acceso a cuentas ni herramientas por sí sola.

**Modos:** DIAGNOSE, PROGRESS_REPORT, ONE_TO_ONE, PLAN_90, WEEKLY_REVIEW

### Ejemplo listo para adaptar

> @Ami Real Estate Coach: Modo PROGRESS_REPORT. Analiza el XLSX adjunto del formulario AMI para [periodo]. Entrega resumen privado del equipo y reporte 1-1 por agente con evidencia, tres KPIs y compromiso para los próximos siete días.

## Qué consigues

Reporte ejecutivo de equipo, 1-1 privado, plan con acciones/owners/fechas/KPIs y failure triggers.

## Cómo evaluar el resultado

Actividad ejecutada, conversiones del funnel, pipeline, progreso contra meta propia y seguimiento. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.

## Límites prácticos

Los resultados dependen de la información y herramientas disponibles. Datos faltantes permanecen pendientes; una estimación o simulación no acredita verificación. Un borrador no acredita envío, implementación ni publicación. Autoriza expresamente acciones externas y gasto cuando correspondan.

## Paquetes respaldados

- [skill-6ac114dd52fc8191ba906e25dccdf684](../../skills/skill-6ac114dd52fc8191ba906e25dccdf684/SKILL.md) — SHA-256 `ad2d8cb96df7a60703bdee33f6c91ad8bd0a81a9e1bfe17190cc764e98126093`.
