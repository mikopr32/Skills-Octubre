# Realestate Comps

**Nombre técnico:** `realestate-comps`  
**Estado:** Instalada.

## Cuándo usarla

Construir un conjunto de comparables antes de valorar una propiedad.

## Qué darle

Subject, geografía, tipo y ventana temporal.

## Cómo usarla

Selecciona esta Skill con @ o invócala por nombre. Adjunta los archivos, concreta el objetivo y especifica el modo/formato. Una Skill no aporta acceso a cuentas ni herramientas por sí sola.

**Modos:** SOLD, ACTIVE, PENDING, COMP_SET

### Ejemplo listo para adaptar

> @Realestate Comps: Modo COMP_SET. Para [subject], tipo [tipo], geografía [área] y ventana [periodo], selecciona comparables vendidos, activos y pendientes de los datos adjuntos. Justifica aceptados y descartados sin confundir asking price con venta cerrada.

## Qué consigues

Comp set y rúbrica de selección.

## Cómo evaluar el resultado

Comparables aceptados, cobertura y antigüedad. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.

## Límites prácticos

Los resultados dependen de la información y herramientas disponibles. Datos faltantes permanecen pendientes; una estimación o simulación no acredita verificación. Un borrador no acredita envío, implementación ni publicación. Autoriza expresamente acciones externas y gasto cuando correspondan.

## Paquetes respaldados

- [skill-6a59771dcd88819195d491f109f36958](../../skills/skill-6a59771dcd88819195d491f109f36958/SKILL.md) — SHA-256 `68725416aa7ac486f7459bb003aba5d74b8865f616164562615463e504205dda`.
