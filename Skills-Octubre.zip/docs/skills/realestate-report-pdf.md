# Realestate Report Pdf

**Nombre técnico:** `realestate-report-pdf`  
**Estado:** Instalada.

## Cuándo usarla

Convertir un análisis ya auditado en un PDF para cliente o revisión técnica.

## Qué darle

Análisis fuente, audiencia y formato.

## Cómo usarla

Selecciona esta Skill con @ o invócala por nombre. Adjunta los archivos, concreta el objetivo y especifica el modo/formato. Una Skill no aporta acceso a cuentas ni herramientas por sí sola.

**Modos:** CLIENT, TECHNICAL, COMBINED

### Ejemplo listo para adaptar

> @Realestate Report Pdf: Modo CLIENT. Convierte el análisis adjunto en PDF para [audiencia]. Conserva cifras, fuentes y limitaciones; verifica que las tablas y páginas sean legibles y no presentes el formato como nueva verificación de datos.

## Qué consigues

PDF final y trazabilidad del análisis fuente.

## Cómo evaluar el resultado

Páginas legibles, tablas completas y claims sin cambios. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.

## Límites prácticos

Los resultados dependen de la información y herramientas disponibles. Datos faltantes permanecen pendientes; una estimación o simulación no acredita verificación. Un borrador no acredita envío, implementación ni publicación. Autoriza expresamente acciones externas y gasto cuando correspondan.

## Paquetes respaldados

- [skill-6a5977bf3ab481918f4f6186e0f37ef5](../../skills/skill-6a5977bf3ab481918f4f6186e0f37ef5/SKILL.md) — SHA-256 `f3010af2e7339b4209641474ffb1e68730e85c1c8dc6f2bf461d5977e49cc286`.
