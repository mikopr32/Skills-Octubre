# Buyer Strategy And Readiness

**Nombre técnico:** `buyer-strategy-and-readiness`  
**Estado:** Instalada.

## Cuándo usarla

Preparar compradores y comparar pagos, capacidad y alternativas de financiación.

## Qué darle

Ubicación u objetivo; precio/loan terms para cálculo; income/debts/assets solo para readiness personalizado.

## Cómo usarla

Selecciona esta Skill con @ o invócala por nombre. Adjunta los archivos, concreta el objetivo y especifica el modo/formato. Una Skill no aporta acceso a cuentas ni herramientas por sí sola.

**Modos:** MARKET_STRATEGY, CALCULATE, READINESS, LOAN_PATHS, RENT_VS_BUY, REFINANCE

### Ejemplo listo para adaptar

> @Buyer Strategy And Readiness: Modo CALCULATE. Con precio [valor], down payment [valor], tasa [valor], plazo [valor], taxes, seguro y HOA adjuntos, calcula el pago completo y escenarios. Conserva pendientes los gastos ausentes; no supongas aprobación.

## Qué consigues

Readiness brief, escenarios de pago y cash to close, fuentes y faltantes.

## Cómo evaluar el resultado

Payment íntegro, DTI condicionado, documentos completos y próximos pasos. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.

- Usar `scripts/mortgage_math.py` para cálculo reproducible. Leer sus limitaciones antes de interpretar resultados.

## Límites prácticos

Los resultados dependen de la información y herramientas disponibles. Datos faltantes permanecen pendientes; una estimación o simulación no acredita verificación. Un borrador no acredita envío, implementación ni publicación. Autoriza expresamente acciones externas y gasto cuando correspondan.

## Paquetes respaldados

- [skill-6ac11527e9548191bc444e6257f966f4](../../skills/skill-6ac11527e9548191bc444e6257f966f4/SKILL.md) — SHA-256 `9f45866bad6489c59a842f7ed85ba3e79cc54ca121396ff4045010336f4069c9`.
