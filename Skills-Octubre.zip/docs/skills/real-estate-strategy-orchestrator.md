# Real Estate Strategy Orchestrator

**Nombre técnico:** `real-estate-strategy-orchestrator`  
**Estado:** Instalada.

## Cuándo usarla

Coordinar una decisión inmobiliaria que requiere varias especialidades.

## Qué darle

Decisión, propiedad o geografía y objetivo.

## Cómo usarla

Selecciona esta Skill con @ o invócala por nombre. Adjunta los archivos, concreta el objetivo y especifica el modo/formato. Una Skill no aporta acceso a cuentas ni herramientas por sí sola.

**Modos:** QUICK, STANDARD, DEEP, CLIENT

### Ejemplo listo para adaptar

> @Real Estate Strategy Orchestrator: Modo STANDARD. Compara las propiedades adjuntas para [objetivo]. Coordina análisis, inversión y comunidad según corresponda, reutiliza facts y entrega matriz de decisión, cálculos permitidos, incertidumbres y próximo paso.

## Qué consigues

Brief ejecutivo, matriz de decisión, evidencia y próximo paso.

## Cómo evaluar el resultado

Coherencia de cifras; reutilización de datos; rutas válidas. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.

## Límites prácticos

Los resultados dependen de la información y herramientas disponibles. Datos faltantes permanecen pendientes; una estimación o simulación no acredita verificación. Un borrador no acredita envío, implementación ni publicación. Autoriza expresamente acciones externas y gasto cuando correspondan.

## Paquetes respaldados

- [skill-6a5976d654e08191996fcd3dc1a85303](../../skills/skill-6a5976d654e08191996fcd3dc1a85303/SKILL.md) — SHA-256 `fbeb671e85fe050cfd45eccc9d39d7f2442c598ed740e45913db68b151b82fff`.
