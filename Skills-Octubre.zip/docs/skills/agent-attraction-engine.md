# Agent Attraction Engine

**Nombre técnico:** `agent-attraction-engine`  
**Estado:** Instalada.

## Cuándo usarla

Atraer, calificar y activar agentes para AXEN Realty Latino.

## Qué darle

Comunidad AXEN Realty Latino; segmento, oferta/beneficios confirmados y capacidad disponibles.

## Cómo usarla

Selecciona esta Skill con @ o invócala por nombre. Adjunta los archivos, concreta el objetivo y especifica el modo/formato. Una Skill no aporta acceso a cuentas ni herramientas por sí sola.

**Modos:** BRAIN_AUDIT, IAP, POSITIONING, OFFER, QUALIFY, PRESENT, FOLLOW_UP, ONBOARD, ACTIVATE, FUNNEL_AUDIT

### Ejemplo listo para adaptar

> @Agent Attraction Engine: Modo IAP. Define el perfil de agentes experimentados y líderes con equipos para AXEN Realty Latino a nivel nacional. Usa los beneficios confirmados que adjunto, distingue afiliación al brokerage de participación en la comunidad y entrega criterios de calificación y activación.

## Qué consigues

IAP operativo, diagnóstico, oferta, pipeline, onboarding, métricas y siguiente experimento.

## Cómo evaluar el resultado

Qualified conversations, show rate, nuevas incorporaciones brokerage separadas de miembros Latino, activation30, retention90, tiempo/costo por activado. Registrar periodo y denominador. No fijar metas o resultados sin baseline o instrucción explícita.

## Límites prácticos

Los resultados dependen de la información y herramientas disponibles. Datos faltantes permanecen pendientes; una estimación o simulación no acredita verificación. Un borrador no acredita envío, implementación ni publicación. Autoriza expresamente acciones externas y gasto cuando correspondan.

## Paquetes respaldados

- [skill-6ac114bb9394819197c6f452296bbcdd](../../skills/skill-6ac114bb9394819197c6f452296bbcdd/SKILL.md) — SHA-256 `e7d97b9c1d428cff4920e16a909b779ed74a5f163c9a28d75122cd09522d56b1`.
